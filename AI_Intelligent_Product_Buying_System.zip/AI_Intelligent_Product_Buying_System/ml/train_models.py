"""Machine Learning training pipeline for Product Clustering and Feature Modeling.
Trains K-Means Clustering on normalized multi-dimensional product attributes
and saves the trained models and scalers to ml/models/ directory.
"""
import sys
import pickle
import sqlite3
import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.neighbors import NearestNeighbors

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from config import Config

def train_and_save_models(db_path=Config.DATABASE_PATH, models_dir=Config.ML_MODELS_DIR):
    """Loads products from database, normalizes features, trains K-Means & KNN, and persists artifacts."""
    print("=" * 60)
    print("STARTING MACHINE LEARNING TRAINING PIPELINE")
    print("=" * 60)

    models_dir.mkdir(parents=True, exist_ok=True)

    # 1. Fetch products from SQLite
    conn = sqlite3.connect(db_path)
    query = """
    SELECT product_id, name, brand, category, price, mrp,
           ram_gb, storage_gb, display_size, rating, review_count
    FROM products;
    """
    df = pd.read_sql_query(query, conn)
    conn.close()

    if df.empty:
        raise ValueError("No products found in database to train ML models!")

    print(f"Loaded {len(df)} products for ML feature engineering.")

    # 2. Feature Engineering & Preprocessing
    # Transform skewed features (review_count, price) with log1p
    df["log_price"] = np.log1p(df["price"])
    df["log_reviews"] = np.log1p(df["review_count"])
    df["discount_ratio"] = ((df["mrp"] - df["price"]) / df["mrp"]).clip(0, 1)

    feature_cols = [
        "log_price", "rating", "log_reviews",
        "ram_gb", "storage_gb", "display_size", "discount_ratio"
    ]

    X = df[feature_cols].values

    # 3. Feature Scaling
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # 4. K-Means Clustering
    # K=4 to represent: Budget, Value, Performance, Premium
    k = 4
    kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
    clusters = kmeans.fit_predict(X_scaled)
    df["cluster"] = clusters

    # 5. Centroid Interpretation
    # Inspect centroids to dynamically name clusters based on empirical metrics
    cluster_profiles = {}
    for c_id in range(k):
        sub = df[df["cluster"] == c_id]
        avg_price = sub["price"].mean()
        avg_ram = sub["ram_gb"].mean()
        avg_rating = sub["rating"].mean()
        cluster_profiles[c_id] = {
            "avg_price": avg_price,
            "avg_ram": avg_ram,
            "avg_rating": avg_rating,
            "size": len(sub)
        }

    # Sort cluster IDs by price to map into human-meaningful segments
    sorted_clusters = sorted(cluster_profiles.keys(), key=lambda c: cluster_profiles[c]["avg_price"])
    cluster_names = {}
    segment_labels = [
        "Budget-Friendly (Accessible Value)",
        "Balanced Everyday (Smart Value)",
        "High Performance (Power User)",
        "Flagship / Ultra Premium"
    ]
    for idx, c_id in enumerate(sorted_clusters):
        cluster_names[c_id] = segment_labels[idx]

    df["cluster_name"] = df["cluster"].map(cluster_names)

    print("\nCluster Centroid Characterization:")
    for c_id, profile in cluster_profiles.items():
        name = cluster_names[c_id]
        print(f"  Cluster {c_id} [{name}]: Size={profile['size']} | Avg Price=₹{profile['avg_price']:,.0f} | Avg RAM={profile['avg_ram']:.1f}GB | Avg Rating={profile['avg_rating']:.2f}")

    # 6. Nearest Neighbors Model for Content-Based Similarity / Alternative Finding
    knn = NearestNeighbors(n_neighbors=min(6, len(df)), metric="euclidean")
    knn.fit(X_scaled)

    # 7. Persist Models
    artifacts = {
        "kmeans": kmeans,
        "scaler": scaler,
        "knn": knn,
        "feature_cols": feature_cols,
        "cluster_names": cluster_names,
        "cluster_profiles": cluster_profiles,
        "product_ids": df["product_id"].tolist(),
        "product_clusters": dict(zip(df["product_id"], df["cluster_name"]))
    }

    model_file = models_dir / "ml_artifacts.pkl"
    with open(model_file, "wb") as f:
        pickle.dump(artifacts, f)

    # Also save separate files for modular access
    with open(models_dir / "kmeans_model.pkl", "wb") as f:
        pickle.dump(kmeans, f)
    with open(models_dir / "scaler.pkl", "wb") as f:
        pickle.dump(scaler, f)
    with open(models_dir / "knn_model.pkl", "wb") as f:
        pickle.dump(knn, f)

    print(f"\nML artifacts successfully saved to {models_dir}")
    print("=" * 60)
    return artifacts

if __name__ == "__main__":
    train_and_save_models()
