"""Packages the complete project into AI_Intelligent_Product_Buying_System.zip."""
import os
import zipfile
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
OUTPUT_ZIP = BASE_DIR.parent / "AI_Intelligent_Product_Buying_System.zip"

def package_zip():
    print(f"Packaging project from {BASE_DIR} into {OUTPUT_ZIP}...")
    file_count = 0

    with zipfile.ZipFile(OUTPUT_ZIP, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(BASE_DIR):
            # Exclude unwanted directories
            dirs[:] = [d for d in dirs if d not in [
                "__pycache__", ".pytest_cache", "venv", ".venv", "env", "node_modules", ".git"
            ]]
            for file in files:
                if file.endswith((".pyc", ".pyo", ".DS_Store", ".zip")):
                    continue
                file_path = Path(root) / file
                archive_name = Path("AI_Intelligent_Product_Buying_System") / file_path.relative_to(BASE_DIR)
                zf.write(file_path, archive_name)
                file_count += 1

    zip_size_mb = OUTPUT_ZIP.stat().st_size / (1024 * 1024)
    print(f"Successfully packaged {file_count} files into {OUTPUT_ZIP} ({zip_size_mb:.2f} MB)")
    return OUTPUT_ZIP

if __name__ == "__main__":
    package_zip()
