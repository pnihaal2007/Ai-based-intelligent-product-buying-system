"""Demo dataset generator for the AI-Based Intelligent Product Buying Decision System.
Generates comprehensive, realistic datasets in Indian Rupees (₹ INR) across 6 categories:
Laptops, Smartphones, Headphones, Smartwatches, Televisions, Tablets.
Also generates multi-platform listings, synthetic users, and user search history.
"""
import os
import csv
import json
import random
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"

def generate_datasets():
    """Generates products.csv, platform_listings.csv, users.csv, searches.csv"""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    random.seed(42)

    # 1. Base Product Templates per Category
    raw_products = []
    prod_id = 1001

    # --- LAPTOPS (Targeting different budgets ₹35k - ₹2.5L, uses: Programming, Gaming, ML, Office, College) ---
    laptop_templates = [
        # Budget & Student Laptops (₹30,000 - ₹55,000)
        ("Lenovo IdeaPad Slim 3", "Lenovo", "82H803EFIN", "Core i3 11th Gen / 8GB / 512GB SSD / Intel UHD", 37990, 48990, "Intel Core i3 1115G4", "Intel UHD Graphics", 8, 512, 15.6, 45, 1, 4.2, 850, 12, "FHD Anti-Glare, Rapid Charge, 1.65 kg", "Everyday student work, Office productivity, Web browsing"),
        ("HP 15s Ryzen 3", "HP", "15s-eq2143AU", "Ryzen 3 5300U / 8GB / 512GB SSD / Vega 6", 36990, 47875, "AMD Ryzen 3 5300U", "AMD Radeon Graphics", 8, 512, 15.6, 41, 1, 4.1, 1120, 12, "Micro-edge FHD, Fast charge, 1.69 kg", "Office tasks, light multitasking, college assignments"),
        ("Acer Aspire Lite", "Acer", "AL15-51", "Core i3 12th Gen / 8GB / 512GB SSD / UHD", 32990, 45990, "Intel Core i3 1215U", "Intel UHD Graphics", 8, 512, 15.6, 36, 1, 4.0, 640, 12, "Slim bezel FHD, Steel gray metal body, 1.59 kg", "Budget coding, college note taking"),
        ("ASUS Vivobook 15", "ASUS", "X1502ZA-EJ381WS", "Core i5 12th Gen / 8GB / 512GB SSD / Iris Xe", 46990, 62990, "Intel Core i5 1235U", "Intel Iris Xe", 8, 512, 15.6, 42, 1, 4.3, 1420, 12, "180-degree lay-flat hinge, Privacy shutter, 1.7 kg", "Programming, College, Office, Web development"),
        ("Lenovo IdeaPad Slim 5", "Lenovo", "82XF0038IN", "Ryzen 5 7530U / 16GB / 512GB SSD / Vega 7", 54990, 74990, "AMD Ryzen 5 7530U", "AMD Radeon Graphics", 16, 512, 14.0, 56.6, 2, 4.4, 890, 24, "OLED 2.8K 100% DCI-P3, Backlit keyboard, 1.46 kg", "Coding, Data Analysis, Content creation, Portability"),
        ("Dell Inspiron 3520", "Dell", "IN3520X839W", "Core i5 12th Gen / 16GB / 512GB SSD / Iris Xe", 51990, 67890, "Intel Core i5 1235U", "Intel Iris Xe", 16, 512, 15.6, 41, 1, 4.2, 780, 12, "120Hz FHD WVA display, ExpressCharge, 1.65 kg", "Programming, office work, daily productivity"),

        # Mid-Range Coding & Entry Gaming (₹55,000 - ₹75,000)
        ("HP Victus Gaming 15", "HP", "15-fa0070TX", "Core i5 12th Gen / 16GB / 512GB SSD / RTX 3050 4GB", 64990, 81990, "Intel Core i5 12450H", "NVIDIA RTX 3050 (4GB GDDR6)", 16, 512, 15.6, 70, 1, 4.3, 2350, 12, "144Hz FHD IPS, Omen Gaming Hub, 2.29 kg", "Programming, Machine Learning basics, 1080p Gaming"),
        ("Lenovo LOQ 15", "Lenovo", "15IAX9", "Core i5 12450HX / 16GB / 512GB SSD / RTX 3050 6GB", 66990, 84990, "Intel Core i5 12450HX", "NVIDIA RTX 3050 (6GB GDDR6)", 16, 512, 15.6, 60, 1, 4.4, 1890, 12, "144Hz G-Sync, Lenovo AI Engine+ LA1 chip, 2.38 kg", "Coding, ML training, Gaming, CAD modeling"),
        ("Acer Nitro V 15", "Acer", "ANV15-51", "Core i5 13420H / 16GB / 512GB SSD / RTX 4050 6GB", 73990, 92990, "Intel Core i5 13420H", "NVIDIA RTX 4050 (6GB GDDR6)", 16, 512, 15.6, 57, 1, 4.4, 1650, 12, "144Hz FHD, Dual-fan cooling, Gen4 SSD, 2.1 kg", "High-performance coding, ML models, AAA gaming"),
        ("ASUS TUF Gaming F15", "ASUS", "FX506HE-HN382W", "Core i5 11400H / 16GB / 512GB SSD / RTX 3050Ti", 59990, 76990, "Intel Core i5 11400H", "NVIDIA RTX 3050 Ti (4GB GDDR6)", 16, 512, 15.6, 48, 1, 4.3, 3120, 12, "Military-grade durability MIL-STD-810H, 144Hz, 2.3 kg", "Programming, moderate gaming, college technical use"),
        ("MSI GF63 Thin", "MSI", "12UCX-1094IN", "Core i5 12450H / 8GB / 512GB SSD / RTX 2050 4GB", 48990, 62990, "Intel Core i5 12450H", "NVIDIA RTX 2050 (4GB GDDR6)", 8, 512, 15.6, 51, 1, 4.0, 930, 24, "Thin & light gaming chassis 1.86 kg, Cooler Boost", "Entry-level gaming, programming, budget editing"),

        # High-Performance Programming, Machine Learning & Serious Gaming (₹75,000 - ₹1,30,000)
        ("ASUS TUF Gaming A15", "ASUS", "FA507NU-LP084W", "Ryzen 7 7735HS / 16GB / 512GB SSD / RTX 4050 6GB", 78990, 99990, "AMD Ryzen 7 7735HS", "NVIDIA RTX 4050 (6GB GDDR6, 140W TGP)", 16, 512, 15.6, 90, 1, 4.5, 2450, 12, "144Hz 100% sRGB, 90Wh battery (great battery for gaming), MUX Switch", "Machine Learning, Deep Learning, Programming, AAA Gaming"),
        ("Lenovo Legion Slim 5", "Lenovo", "16APH8", "Ryzen 7 7840HS / 16GB / 1TB SSD / RTX 4060 8GB", 109990, 138990, "AMD Ryzen 7 7840HS", "NVIDIA RTX 4060 (8GB GDDR6)", 16, 1024, 16.0, 80, 2, 4.6, 1140, 36, "WQXGA 165Hz 100% sRGB, AI Engine, Legion Coldfront 5.0, 2.3 kg", "Heavy Machine Learning, CUDA development, 1440p Gaming, 3D Rendering"),
        ("HP OMEN 16", "HP", "16-xf0059AX", "Ryzen 7 7840HS / 16GB / 1TB SSD / RTX 4060 8GB", 112990, 142990, "AMD Ryzen 7 7840HS", "NVIDIA RTX 4060 (8GB GDDR6)", 16, 1024, 16.1, 83, 1, 4.5, 870, 12, "165Hz QHD display, Omen Tempest cooling, RGB keyboard", "Data Science, ML training, Game development, Video production"),
        ("Acer Predator Helios Neo 16", "Acer", "PHN16-71", "Core i7 13700HX / 16GB / 1TB SSD / RTX 4060 8GB", 119990, 149990, "Intel Core i7 13700HX", "NVIDIA RTX 4060 (8GB GDDR6, 140W)", 16, 1024, 16.0, 90, 1, 4.6, 1320, 24, "WQXGA 165Hz IPS 500 nits, Liquid Metal thermal grease, 2.6 kg", "Intensive Machine Learning, Deep Neural Nets, VR, Hardcore Gaming"),
        ("Dell G15 5530", "Dell", "G15-5530-R2702", "Core i7 13650HX / 16GB / 1TB SSD / RTX 4050 6GB", 89990, 114990, "Intel Core i7 13650HX", "NVIDIA RTX 4050 (6GB GDDR6)", 16, 1024, 15.6, 86, 1, 4.3, 910, 12, "Alienware-inspired thermal cooling, 120Hz FHD, 2.8 kg", "Engineering software, ML tasks, Gaming, Programming"),

        # Ultra-portable & Premium Laptops (₹70,000 - ₹2,00,000)
        ("Apple MacBook Air M2", "Apple", "MLY33HN/A", "Apple M2 / 8GB / 256GB SSD / 8-core GPU", 84990, 99900, "Apple M2 (8-core CPU)", "Apple 8-core GPU", 8, 256, 13.6, 52.6, 2, 4.8, 4800, 12, "Liquid Retina 500 nits, 18-hour battery, MagSafe 3, Silent fanless, 1.24 kg", "College, Web & App Programming, Office, Outstanding Battery & Portability"),
        ("Apple MacBook Air M2 16GB", "Apple", "Z15S00000", "Apple M2 / 16GB / 512GB SSD / 10-core GPU", 119990, 139900, "Apple M2 (8-core CPU)", "Apple 10-core GPU", 16, 512, 13.6, 52.6, 2, 4.9, 2100, 12, "16GB unified memory, Liquid Retina, 18hr battery, 1.24 kg", "Mobile app dev (iOS/Android), Docker, Full-stack coding, Portability"),
        ("Apple MacBook Air M3", "Apple", "MRXV3HN/A", "Apple M3 / 16GB / 512GB SSD / 10-core GPU", 134990, 154900, "Apple M3 (8-core CPU, Hardware Ray Tracing)", "Apple 10-core GPU", 16, 512, 13.6, 52.6, 2, 4.9, 1800, 12, "Dual external monitor support, AV1 decode, 18hr battery, 1.24 kg", "Software engineering, Data science on Mac, Ultimate battery & speed"),
        ("ASUS Zenbook 14 OLED", "ASUS", "UX3405MA-QD552WS", "Intel Core Ultra 7 155H / 16GB / 1TB SSD / Intel Arc", 99990, 124990, "Intel Core Ultra 7 155H (with NPU)", "Intel Arc Graphics", 16, 1024, 14.0, 75, 2, 4.6, 620, 12, "3K 120Hz OLED, Intel AI Boost NPU, 1.2 kg all-metal chassis", "On-device AI coding, Ultra-portable programming, Premium productivity"),
    ]

    for item in laptop_templates:
        raw_products.append({
            "product_id": prod_id,
            "name": item[0],
            "brand": item[1],
            "category": "Laptops",
            "model_number": item[2],
            "variant": item[3],
            "price": item[4],
            "mrp": item[5],
            "processor": item[6],
            "gpu": item[7],
            "ram_gb": item[8],
            "storage_gb": item[9],
            "display_size": item[10],
            "battery_spec": f"{item[11]}Wh",
            "camera_spec": "720p HD Webcam" if item[12] == 1 else "1080p FHD Webcam",
            "connectivity": "Wi-Fi 6, Bluetooth 5.2, USB Type-C, HDMI",
            "rating": item[13],
            "review_count": item[14],
            "warranty_months": item[15],
            "highlights": item[16],
            "intended_use": item[17],
            "image_url": f"/static/images/placeholders/laptop.svg"
        })
        prod_id += 1

    # --- SMARTPHONES (Targeting ₹10k - ₹1.5L, uses: Camera, Gaming, Battery, Daily, Flagship) ---
    phone_templates = [
        # Budget Under ₹15,000
        ("Samsung Galaxy M14 5G", "Samsung", "SM-M146B", "6GB RAM / 128GB Storage / Berry Blue", 11990, 17990, "Exynos 1330 5nm", "Mali-G68", 6, 128, 6.6, "6000mAh", "50MP + 2MP + 2MP", 4.1, 8400, 12, "Massive 6000mAh battery, 5G 13 bands, 90Hz FHD+", "Long battery life, daily social media, reliable brand"),
        ("Motorola G34 5G", "Motorola", "XT2363-2", "8GB RAM / 128GB Storage / Ocean Green", 11999, 14999, "Snapdragon 695 5G", "Adreno 619", 8, 128, 6.5, "5000mAh", "50MP Quad Pixel + 2MP", 4.2, 5300, 12, "Clean near-stock Android 14, 120Hz display, Vegan leather back", "Smooth stock UI, budget 5G gaming, value for money"),
        ("Realme Narzo 60x 5G", "Realme", "RMX3782", "6GB RAM / 128GB Storage / Stellar Green", 12499, 15999, "MediaTek Dimensity 6100+", "Mali-G57 MC2", 6, 128, 6.72, "5000mAh", "50MP AI + 2MP", 4.1, 6200, 12, "33W SUPERVOOC charging, Dynamic ultra smooth 120Hz display", "Fast charging, daily tasks, multimedia"),

        # Mid-Range Value & Camera (₹15,000 - ₹30,000)
        ("OnePlus Nord CE 3 Lite 5G", "OnePlus", "CPH2467", "8GB RAM / 128GB Storage / Pastel Lime", 17499, 19999, "Snapdragon 695 5G", "Adreno 619", 8, 128, 6.72, "5000mAh", "108MP 3x Lossless Zoom + 2MP + 2MP", 4.2, 19400, 12, "67W SUPERVOOC, OxygenOS, Dual stereo speakers", "Fast charging, clear photos, smooth daily usage"),
        ("Samsung Galaxy M34 5G", "Samsung", "SM-M346B", "8GB RAM / 128GB Storage / Prism Silver", 16999, 24499, "Exynos 1280 5nm", "Mali-G68", 8, 128, 6.5, "6000mAh", "50MP OIS No Shake Camera + 8MP Ultrawide + 2MP", 4.3, 14200, 12, "50MP OIS camera, 120Hz Super AMOLED, 4 OS upgrades promised", "Super AMOLED display, camera stabilization, battery beast"),
        ("Redmi Note 13 Pro 5G", "Xiaomi", "2312DRA50I", "8GB RAM / 256GB Storage / Coral Purple", 23999, 28999, "Snapdragon 7s Gen 2", "Adreno 710", 8, 256, 6.67, "5100mAh", "200MP OIS Ultra-Clear + 8MP + 2MP", 4.3, 9800, 12, "200MP flagship sensor with OIS, 1.5K AMOLED 120Hz, 67W Turbo Charge", "High resolution photography, crystal sharp display, fast charging"),
        ("Poco X6 Pro 5G", "Poco", "2311DRK48I", "12GB RAM / 512GB Storage / Racing Yellow", 25999, 30999, "MediaTek Dimensity 8300 Ultra", "Mali-G615", 12, 512, 6.67, "5000mAh", "64MP OIS + 8MP Ultrawide + 2MP", 4.4, 7600, 12, "Flagship 1.4M AnTuTu score, 1.5K Flow AMOLED, 67W charging", "Best-in-class gaming under ₹30k, heavy multitasking"),
        ("Motorola Edge 50 Fusion", "Motorola", "XT2429-1", "8GB RAM / 128GB Storage / Marshmallow Blue", 22999, 27999, "Snapdragon 7s Gen 2", "Adreno 710", 8, 128, 6.7, "5000mAh", "50MP Sony LYTIA 700C OIS + 13MP Ultrawide", 4.4, 5100, 12, "IP68 underwater protection, 144Hz 3D curved pOLED, 68W charging", "Clean UI, water resistance, great portrait camera"),

        # Upper Mid-Range & Flagship Killers (₹30,000 - ₹50,000)
        ("OnePlus 12R", "OnePlus", "CPH2585", "8GB RAM / 128GB Storage / Cool Blue", 39999, 42999, "Snapdragon 8 Gen 2", "Adreno 740", 8, 128, 6.78, "5500mAh", "50MP Sony IMX890 OIS + 8MP Ultrawide + 2MP", 4.5, 12800, 12, "100W SUPERVOOC, 4th Gen LTPO 120Hz AMOLED, Flagship SoC", "High-tier gaming, blazing fast charging, smooth software"),
        ("OnePlus 12R 16GB", "OnePlus", "CPH2585-256", "16GB RAM / 256GB Storage / Iron Gray", 45999, 49999, "Snapdragon 8 Gen 2", "Adreno 740", 16, 256, 6.78, "5500mAh", "50MP Sony IMX890 OIS + 8MP Ultrawide + 2MP", 4.6, 8400, 12, "16GB LPDDR5X RAM, 256GB UFS 4.0 storage, Dual Cryo-velocity VC cooling", "Hardcore 60/90fps gaming, multi-app workstation"),
        ("Google Pixel 7a", "Google", "GWKK3", "8GB RAM / 128GB Storage / Sea", 36999, 43999, "Google Tensor G2", "Mali-G710 MP7", 8, 128, 6.1, "4385mAh", "64MP Quad PD OIS + 13MP Ultrawide", 4.3, 11500, 12, "Best camera algorithms, pure Google software, Night Sight, Magic Eraser", "Exceptional camera quality, compact form factor, AI features"),
        ("Google Pixel 8a", "Google", "G8HH4", "8GB RAM / 128GB Storage / Aloe", 49999, 52999, "Google Tensor G3", "Immortalis-G715s", 8, 128, 6.1, "4492mAh", "64MP Quad PD OIS + 13MP Ultrawide", 4.4, 4200, 12, "7 years of OS updates, Tensor G3 AI, Best Take, Audio Magic Eraser", "Top camera phone under ₹50k, compact size, long software support"),
        ("Samsung Galaxy S23 FE 5G", "Samsung", "SM-S711B", "8GB RAM / 128GB Storage / Mint", 38999, 59999, "Exynos 2200 4nm", "Xclipse 920", 8, 128, 6.4, "4500mAh", "50MP OIS + 12MP Ultrawide + 8MP 3x Optical Telephoto", 4.2, 9100, 12, "3x optical zoom telephoto camera, IP68 water resistance, Wireless charging", "Versatile camera with true optical zoom, premium build, Samsung ecosystem"),
        ("iQOO Neo 9 Pro 5G", "iQOO", "I2217", "8GB RAM / 128GB Storage / Fiery Red", 34999, 39999, "Snapdragon 8 Gen 2", "Adreno 740", 8, 128, 6.78, "5160mAh", "50MP Sony IMX920 VCS + 8MP Ultrawide", 4.5, 6800, 12, "Supercomputing Chip Q1, 144Hz LTPO AMOLED, 120W FlashCharge", "Uncompromised gaming performance, quick charging, camera stability"),

        # Premium & Ultra Flagships (₹50,000 - ₹1,50,000)
        ("Apple iPhone 14", "Apple", "MPVN3HN/A", "6GB RAM / 128GB Storage / Midnight", 56999, 69900, "Apple A15 Bionic (5-core GPU)", "Apple 5-core GPU", 6, 128, 6.1, "3279mAh", "12MP Sensor-Shift OIS + 12MP Ultrawide", 4.6, 28400, 12, "Photonic Engine, Cinematic Mode 4K, Crash Detection, Ceramic Shield", "Superb video recording, long iOS lifespan, iOS ecosystem"),
        ("Apple iPhone 15", "Apple", "MTP03HN/A", "6GB RAM / 128GB Storage / Black", 69999, 79900, "Apple A16 Bionic", "Apple 5-core GPU", 6, 128, 6.1, "3349mAh", "48MP Quad-pixel Sensor-Shift OIS + 12MP Ultrawide", 4.7, 18900, 12, "Dynamic Island, 48MP main camera with 2x lossless zoom, USB Type-C", "All-round premium smartphone, best video capture, compact flagship"),
        ("Apple iPhone 15 Pro", "Apple", "MTV13HN/A", "8GB RAM / 128GB Storage / Natural Titanium", 124990, 134900, "Apple A17 Pro (3nm)", "Apple 6-core GPU Ray Tracing", 8, 128, 6.1, "3274mAh", "48MP OIS + 12MP 3x Telephoto + 12MP Ultrawide", 4.8, 6500, 12, "Aerospace-grade titanium, Action button, ProRes 4K60 video, ProMotion 120Hz", "Professional video creator phone, console-level gaming, titanium luxury"),
        ("Samsung Galaxy S24 5G", "Samsung", "SM-S921B", "8GB RAM / 256GB Storage / Onyx Black", 74999, 82999, "Exynos 2400 10-core", "Xclipse 940", 8, 256, 6.2, "4000mAh", "50MP Dual Pixel OIS + 10MP 3x Optical + 12MP Ultrawide", 4.5, 5200, 12, "Galaxy AI (Circle to Search, Live Translate), Armor Aluminum, 7 OS updates", "Compact Android flagship, AI features, beautiful display"),
        ("Samsung Galaxy S24 Ultra 5G", "Samsung", "SM-S928B", "12GB RAM / 256GB Storage / Titanium Gray", 129999, 134999, "Snapdragon 8 Gen 3 for Galaxy", "Adreno 750", 12, 256, 6.8, "5000mAh", "200MP OIS + 50MP 5x Optical + 10MP 3x Optical + 12MP Ultrawide", 4.8, 8900, 12, "Embedded S-Pen stylus, Titanium frame, 100x Space Zoom, Anti-reflective glass", "The ultimate camera zoom phone, business power user, unmatched display"),
        ("OnePlus 12 5G", "OnePlus", "CPH2573", "12GB RAM / 256GB Storage / Silky Black", 64999, 69999, "Snapdragon 8 Gen 3", "Adreno 750", 12, 256, 6.82, "5400mAh", "50MP Sony LYT-808 + 64MP 3x Periscope OIS + 48MP Ultrawide", 4.6, 9200, 12, "4th Gen Hasselblad camera, 2K 120Hz ProXDR display, 100W wired + 50W wireless", "Flagship cameras with periscope zoom, top gaming power, fast charge"),
    ]

    for item in phone_templates:
        raw_products.append({
            "product_id": prod_id,
            "name": item[0],
            "brand": item[1],
            "category": "Smartphones",
            "model_number": item[2],
            "variant": item[3],
            "price": item[4],
            "mrp": item[5],
            "processor": item[6],
            "gpu": item[7],
            "ram_gb": item[8],
            "storage_gb": item[9],
            "display_size": item[10],
            "battery_spec": item[11],
            "camera_spec": item[12],
            "connectivity": "5G, Wi-Fi 6, Bluetooth 5.3, NFC, GPS",
            "rating": item[13],
            "review_count": item[14],
            "warranty_months": item[15],
            "highlights": item[16],
            "intended_use": item[17],
            "image_url": f"/static/images/placeholders/smartphone.svg"
        })
        prod_id += 1

    # --- HEADPHONES / EARBUDS (Budget ₹1,200 to ₹35,000, uses: ANC, Bass, Calling, Battery, Gaming) ---
    headphone_templates = [
        ("boAt Airdopes 141", "boAt", "AD-141", "True Wireless / Bold Black / 42H Playtime", 1199, 4490, "ENx Tech Mic", "8mm Drivers", 0, 0, 0, "42 Hours total", "Dual Mic with ENx", 3.9, 189000, 12, "ASAP charge (5 min = 75 min), IPX4 water resistance, low latency mode", "Budget daily music, college commute"),
        ("Realme Buds Air 5", "Realme", "RMA2301", "True Wireless / Arctic White / 50dB ANC", 2999, 4999, "Realme R3 Audio Chip", "12.4mm Deep Bass Driver", 0, 0, 0, "38 Hours total", "6-Mic Call Noise Cancellation", 4.3, 14200, 12, "50dB Active Noise Cancellation (best under ₹3k), 45ms ultra low latency", "ANC on a budget, travel noise cancellation, gaming"),
        ("OnePlus Buds 3", "OnePlus", "E509A", "True Wireless / Metallic Gray / 49dB Smart ANC", 5499, 6499, "Dual DACs + LHDC 5.0", "10.4mm Woofer + 6mm Tweeter", 0, 0, 0, "44 Hours total", "3-Mic AI Clear Calls", 4.5, 9800, 12, "Dual dynamic drivers, Hi-Res LHDC audio, Sliding touch volume controls", "High fidelity sound, strong ANC, comfortable calling"),
        ("Sony WF-C700N", "Sony", "WFC700N/B", "True Wireless / Black / Digital Noise Canceling", 7990, 12990, "Sony Integrated Processor V1", "5mm High Compliance Driver", 0, 0, 0, "15 Hours total (ANC on)", "Noise Sensor Mics", 4.2, 5400, 12, "Multipoint connection, DSEE audio upscaling, Ergonomic compact fit", "Commuting, office focus, natural sound balance"),
        ("Sony WH-CH720N", "Sony", "WHCH720N/B", "Over-Ear Wireless / Black / Dual Noise Sensor", 8990, 14990, "Sony Integrated Processor V1", "30mm Driver Units", 0, 0, 0, "35 Hours total (ANC on)", "Beamforming Mics with Precise Voice", 4.3, 8900, 12, "Lightweight 192g over-ear design, 35hr battery, customizable EQ", "Long study sessions, coding with headphones, plane travel"),
        ("OnePlus Nord Buds 2", "OnePlus", "E508A", "True Wireless / Lightning White / 25dB ANC", 2499, 3299, "BassWave Enhancement", "12.4mm Titanized Driver", 0, 0, 0, "36 Hours total", "Dual Mic with AI Noise Reduction", 4.2, 32000, 12, "25dB ANC, IP55 water & dust resistance, fast pairing", "Budget daily earbuds with punchy bass and basic ANC"),
        ("Sony WH-1000XM4", "Sony", "WH1000XM4/BM", "Over-Ear Wireless / Black / Industry Leading ANC", 20990, 29990, "HD Noise Cancelling Processor QN1", "40mm Liquid Crystal Polymer Drivers", 0, 0, 0, "30 Hours total", "5-Mic Array with Speak-to-Chat", 4.6, 24500, 12, "Benchmark active noise cancellation, foldaway travel design, LDAC Hi-Res", "Frequent flyers, software engineers needing deep focus, audiophiles"),
        ("Sony WH-1000XM5", "Sony", "WH1000XM5/B", "Over-Ear Wireless / Black / Auto NC Optimizer", 28990, 34990, "Dual Processors V1 & QN1", "30mm Carbon Fiber Composite Drivers", 0, 0, 0, "30 Hours total", "8 Mics with AI Beamforming", 4.7, 12400, 12, "Industry best active noise cancelling, unmatched mic clarity for Zoom/Teams", "Executive calling, distraction-free programming, reference audio"),
        ("Apple AirPods Pro (2nd Gen)", "Apple", "MTJV3HN/A", "True Wireless / White / USB-C / MagSafe", 20999, 24900, "Apple H2 Audio Processor", "Custom high-excursion Apple driver", 0, 0, 0, "30 Hours total", "Dual beamforming microphones", 4.8, 16800, 12, "2x more ANC, Adaptive Audio, Transparency mode, Spatial Audio with tracking", "Apple ecosystem users, best transparency mode, calls & music"),
        ("Sennheiser Accentum Wireless", "Sennheiser", "ACCENTUM-BLACK", "Over-Ear Wireless / Black / Hybrid ANC", 11990, 14990, "Sennheiser Signature Sound Engine", "37mm Transducer", 0, 0, 0, "50 Hours battery beast", "Dual beamforming mics", 4.4, 3100, 24, "Massive 50-hour battery life, 5-band built-in EQ, aptX HD codec", "Battery life champion, rich acoustic detail, studio sound"),
    ]

    for item in headphone_templates:
        raw_products.append({
            "product_id": prod_id,
            "name": item[0],
            "brand": item[1],
            "category": "Headphones",
            "model_number": item[2],
            "variant": item[3],
            "price": item[4],
            "mrp": item[5],
            "processor": item[6],
            "gpu": "N/A (Audio DSP)",
            "ram_gb": 0,
            "storage_gb": 0,
            "display_size": 0,
            "battery_spec": item[11],
            "camera_spec": "N/A",
            "connectivity": "Bluetooth 5.3, AAC, SBC, LDAC / Multipoint",
            "rating": item[13],
            "review_count": item[14],
            "warranty_months": item[15],
            "highlights": item[16],
            "intended_use": item[17],
            "image_url": f"/static/images/placeholders/headphones.svg"
        })
        prod_id += 1

    # --- SMARTWATCHES (Budget ₹1,500 to ₹45,000, uses: Fitness, Calling, Health sensors, Premium) ---
    watch_templates = [
        ("Noise ColorFit Pulse 2 Max", "Noise", "WRB-SW-PULSE2MAX", "1.85 inch TFT / Jet Black / BT Calling", 1499, 5999, "Noise Health Suite v2", "Proprietary OS", 0, 0, 1.85, "10 Days standby", "N/A", 4.0, 94000, 12, "1.85-inch 550 nits display, Bluetooth calling with dial pad, 100 sports modes", "Entry-level fitness tracking, wrist calls, notification alerts"),
        ("boAt Wave Call 2", "boAt", "WAVE-CALL-2", "1.83 inch HD Display / Active Black / Calling", 1399, 6990, "Crest App OS", "Proprietary", 0, 0, 1.83, "7 Days battery", "N/A", 3.9, 45000, 12, "DIY watch face studio, HR and SpO2 tracking, multiple menu styles", "Budget smartwatch, basic daily activity tracking"),
        ("Amazfit Bip 5", "Amazfit", "A2215", "1.91 inch Ultra-Large / Soft Black / GPS Calling", 6499, 8999, "BioTracker 3 PPG Sensor", "Zepp OS 2.0", 0, 0, 1.91, "10 Days battery", "N/A", 4.3, 4200, 12, "4 satellite positioning systems (GPS), 120+ sports modes, rich app ecosystem", "Outdoor running, cycling, accurate standalone GPS tracking"),
        ("OnePlus Watch 2R", "OnePlus", "OPWWE234", "1.43 inch AMOLED / Forest Green / Dual Engine", 17999, 19999, "Snapdragon W5 Gen 1 + BES2700", "Wear OS 4 by Google", 2, 32, 1.43, "100 Hours Smart Mode", "N/A", 4.5, 3100, 12, "Wear OS with Google Maps/Wallet, 100h battery life dual-engine architecture", "Full Wear OS smartwatch, fitness enthusiasts, Android users"),
        ("Samsung Galaxy Watch 6", "Samsung", "SM-R930", "40mm Bluetooth / Graphite / Super AMOLED", 19999, 33999, "Exynos W930 Dual Core", "Wear OS Powered by Samsung", 2, 16, 1.3, "40 Hours typical", "N/A", 4.4, 6200, 12, "Sapphire crystal glass, ECG & Blood Pressure monitoring, Advanced Sleep Coaching", "Comprehensive health metrics, Samsung Galaxy phone pairing"),
        ("Apple Watch SE (2nd Gen)", "Apple", "MR9U3HN/A", "40mm GPS / Starlight Aluminum / Sport Band", 24900, 29900, "Apple S8 SiP Dual Core", "watchOS 10", 1, 32, 1.57, "18 Hours All-Day", "N/A", 4.7, 8900, 12, "Fall Detection, Crash Detection, Heart rate notifications, Water resistant 50m", "iPhone companion, safety monitoring, workout tracking"),
        ("Apple Watch Series 9", "Apple", "MR8U3HN/A", "41mm GPS / Midnight Aluminum / Sport Band", 37990, 41900, "Apple S9 SiP with 4-core Neural Engine", "watchOS 10", 1, 64, 1.7, "18 Hours (36h Low Power)", "N/A", 4.8, 5400, 12, "Double Tap gesture, 2000 nits Always-On Retina, Blood Oxygen, ECG", "Premier smartwatch experience, seamless Apple integration"),
        ("Samsung Galaxy Watch 5 Pro", "Samsung", "SM-R920", "45mm Bluetooth / Black Titanium / Sapphire Glass", 24999, 44999, "Exynos W920 Dual Core", "Wear OS Powered by Samsung", 1.5, 16, 1.4, "80 Hours battery beast", "N/A", 4.5, 4800, 12, "Titanium casing, D-Buckle strap, GPX route tracking for hiking, huge battery", "Outdoor sports, hiking, long endurance smartwatch"),
        ("boAt Storm Call 3", "boAt", "STORM-CALL-3", "1.83 inch HD / Silver Metal / Turn-by-Turn Navigation", 1299, 5999, "Crest Plus OS", "Proprietary", 0, 0, 1.83, "7 Days battery", "N/A", 4.0, 21000, 12, "Turn-by-turn navigation via MapmyIndia, QR tray, emergency SOS", "Affordable fitness with on-wrist navigation"),
    ]

    for item in watch_templates:
        raw_products.append({
            "product_id": prod_id,
            "name": item[0],
            "brand": item[1],
            "category": "Smartwatches",
            "model_number": item[2],
            "variant": item[3],
            "price": item[4],
            "mrp": item[5],
            "processor": item[6],
            "gpu": "Integrated Graphics",
            "ram_gb": item[8],
            "storage_gb": item[9],
            "display_size": item[10],
            "battery_spec": item[11],
            "camera_spec": "N/A",
            "connectivity": "Bluetooth 5.3, Wi-Fi, GPS, NFC",
            "rating": item[13],
            "review_count": item[14],
            "warranty_months": item[15],
            "highlights": item[16],
            "intended_use": item[17],
            "image_url": f"/static/images/placeholders/smartwatch.svg"
        })
        prod_id += 1

    # --- TELEVISIONS (Budget ₹12,000 to ₹1,80,000, uses: 4K HDR, Gaming 120Hz, Cinema, Budget) ---
    tv_templates = [
        ("Xiaomi Smart TV A 32", "Xiaomi", "L32M8-5AIN", "32 inch HD Ready / Vivid Picture Engine / PatchWall", 12999, 24999, "Cortex A35 Quad Core", "Mali G31 MP2", 1, 8, 32.0, "50W Power Consumption", "N/A", 4.2, 38000, 12, "Dolby Audio 20W, Google TV with PatchWall+, Bezel-less frame", "Bedroom TV, compact living spaces, streaming Netflix/Hotstar"),
        ("LG 43 inch 4K UHD Smart TV", "LG", "43UR7500PSC", "43 inch 4K Ultra HD / α5 AI Processor Gen6", 28990, 49990, "α5 AI Processor 4K Gen6", "LG WebOS 23", 1.5, 8, 43.0, "110W typical", "N/A", 4.3, 14200, 12, "AI Sound 5.1 virtual upmix, 4K Upscaling, HDR10 Pro, Game Optimizer", "Family living room, OTT 4K streaming, smooth webOS navigation"),
        ("Samsung 43 inch Crystal 4K Vivid", "Samsung", "UA43DUE70BKLXL", "43 inch 4K UHD / Crystal Processor 4K", 28990, 44900, "Crystal Processor 4K", "Tizen OS", 2, 8, 43.0, "115W typical", "N/A", 4.3, 11800, 12, "PurColor vibrant colors, Q-Symphony sound sync with soundbars, SolarCell remote", "Movies, cricket matches, everyday family entertainment"),
        ("Sony Bravia 55 inch 4K Google TV", "Sony", "KD-55X74L", "55 inch 4K Ultra HD / X1 4K Processor", 54990, 99900, "4K Processor X1", "Google TV OS", 2, 16, 55.0, "140W typical", "N/A", 4.6, 16400, 24, "Live Color technology, Motionflow XR 100, Open Baffle Speaker Dolby Audio", "Premium home theater, vivid natural cinematic color grading"),
        ("TCL 55 inch 4K QLED Gaming TV", "TCL", "55C645", "55 inch 4K QLED / 120Hz DLG / Dolby Vision Atmos", 37990, 77990, "AiPQ Engine 3.0 64-bit", "Google TV", 2, 16, 55.0, "135W typical", "N/A", 4.3, 5900, 24, "Quantum Dot 1 Billion Colors, AMD FreeSync, 120Hz Game Accelerator", "Console gaming (PS5/Xbox Series X), vibrant QLED viewing"),
        ("LG OLED evo C3 55 inch", "LG", "OLED55C3PSA", "55 inch 4K OLED evo / α9 AI Gen6 / 120Hz 0.1ms", 119990, 219990, "α9 AI Processor 4K Gen6", "LG WebOS 23", 3, 32, 55.0, "160W typical", "N/A", 4.8, 3200, 36, "Self-lit OLED pixels (Infinite Contrast), 4x HDMI 2.1 120Hz G-Sync & FreeSync", "Ultimate cinematic black levels, elite 4K 120Hz HDR gaming"),
        ("Sony Bravia XR 65 inch OLED", "Sony", "XR-65A80L", "65 inch 4K OLED / Cognitive Processor XR", 219990, 349900, "Cognitive Processor XR", "Google TV", 3, 32, 65.0, "190W typical", "N/A", 4.9, 1800, 24, "XR OLED Contrast Pro, Acoustic Surface Audio+ sound directly from screen", "Flagship luxury cinema experience, uncompromising picture & audio quality"),
    ]

    for item in tv_templates:
        raw_products.append({
            "product_id": prod_id,
            "name": item[0],
            "brand": item[1],
            "category": "Televisions",
            "model_number": item[2],
            "variant": item[3],
            "price": item[4],
            "mrp": item[5],
            "processor": item[6],
            "gpu": item[7],
            "ram_gb": int(item[8]),
            "storage_gb": item[9],
            "display_size": item[10],
            "battery_spec": item[11],
            "camera_spec": "N/A",
            "connectivity": "Wi-Fi 5, Bluetooth 5.0, 3x HDMI, 2x USB, Optical Out",
            "rating": item[13],
            "review_count": item[14],
            "warranty_months": item[15],
            "highlights": item[16],
            "intended_use": item[17],
            "image_url": f"/static/images/placeholders/tv.svg"
        })
        prod_id += 1

    # --- TABLETS (Budget ₹12,000 to ₹1,10,000, uses: Study, Notes, Drawing, Multimedia, Work) ---
    tablet_templates = [
        ("Realme Pad 2", "Realme", "RMP2204", "6GB RAM / 128GB Storage / Imagination Grey / Wi-Fi", 15999, 24999, "MediaTek Helio G99 6nm", "Mali-G57 MC2", 6, 128, 11.5, "8360mAh", "8MP Rear + 5MP Front", 4.3, 7100, 12, "2K 120Hz display, Quad speakers with Dolby Atmos, 33W SUPERVOOC", "Student study, PDF reading, binge watching OTT, light gaming"),
        ("Lenovo Tab M11", "Lenovo", "ZADA0028IN", "8GB RAM / 128GB Storage / Seafoam Green / Pen Included", 16999, 28000, "MediaTek Helio G88", "Mali-G52 MC2", 8, 128, 11.0, "7040mAh", "8MP Rear + 8MP Front", 4.2, 3800, 12, "Lenovo Tab Pen included in box, 90Hz FHD IPS display, Nebo handwriting app", "College handwritten notes, sketching, academic reading"),
        ("Xiaomi Pad 6", "Xiaomi", "23043RP34I", "8GB RAM / 256GB Storage / Graphite Grey", 25999, 41999, "Snapdragon 870 7nm", "Adreno 650", 8, 256, 11.0, "8840mAh", "13MP Rear + 8MP Front FocusFrame", 4.6, 14800, 12, "Snapdragon 870 flagship chip, 2.8K 144Hz 7-stage refresh, Metal unibody", "Multitasking work, mobile gaming, video editing, high value productivity"),
        ("Apple iPad 10th Gen", "Apple", "MPQ03HN/A", "64GB / Blue / Wi-Fi / A14 Bionic", 34900, 39900, "Apple A14 Bionic 6-core", "Apple 4-core GPU", 4, 64, 10.9, "28.6Wh Li-Po", "12MP Ultra Wide Front Center Stage + 12MP Rear", 4.7, 19200, 12, "All-screen design with Liquid Retina, USB-C, Landscape Center Stage camera", "College students, family tablet, digital art, long iPadOS support"),
        ("Samsung Galaxy Tab S9 FE", "Samsung", "SM-X510", "6GB RAM / 128GB / Mint / S-Pen Included", 36999, 44999, "Exynos 1380 5nm", "Mali-G68 MP5", 6, 128, 10.9, "8000mAh", "8MP Rear + 12MP Ultra Wide Front", 4.5, 6100, 12, "IP68 water and dust resistance, IP68 rated S-Pen included in box, Samsung DeX", "Digital artists, students needing waterproof durability, desktop mode"),
        ("Apple iPad Air M2", "Apple", "MUWC3HN/A", "128GB / Space Grey / Wi-Fi / Apple M2", 59900, 59900, "Apple M2 8-core CPU", "Apple 9-core GPU", 8, 128, 11.0, "28.93Wh Li-Po", "12MP Landscape Front Center Stage + 12MP Rear", 4.8, 3800, 12, "Apple M2 desktop-grade chip, Apple Pencil Pro support, Magic Keyboard support", "Professional illustration, 4K video editing, heavy academic research"),
        ("Samsung Galaxy Tab S9 Ultra", "Samsung", "SM-X910", "12GB RAM / 256GB / Graphite / Dynamic AMOLED 2X", 108999, 133999, "Snapdragon 8 Gen 2 for Galaxy", "Adreno 740", 12, 256, 14.6, "11200mAh", "13MP + 8MP Rear / 12MP + 12MP Dual Front", 4.8, 1400, 12, "Massive 14.6-inch Dynamic AMOLED 2X 120Hz, Armor Aluminum, S-Pen included", "Ultimate creative workstation, laptop replacement, multi-window productivity"),
    ]

    for item in tablet_templates:
        raw_products.append({
            "product_id": prod_id,
            "name": item[0],
            "brand": item[1],
            "category": "Tablets",
            "model_number": item[2],
            "variant": item[3],
            "price": item[4],
            "mrp": item[5],
            "processor": item[6],
            "gpu": item[7],
            "ram_gb": item[8],
            "storage_gb": item[9],
            "display_size": item[10],
            "battery_spec": item[11],
            "camera_spec": item[12],
            "connectivity": "Wi-Fi 6, Bluetooth 5.2, USB Type-C DisplayPort",
            "rating": item[13],
            "review_count": item[14],
            "warranty_months": item[15],
            "highlights": item[16],
            "intended_use": item[17],
            "image_url": f"/static/images/placeholders/tablet.svg"
        })
        prod_id += 1

    # Now let's expand the dataset to ~180 realistic products by adding variant models and additional brand models
    # This ensures comprehensive coverage across price brackets from ₹1,000 to ₹2,50,000!
    extra_templates = [
        # Additional Laptops
        ("Lenovo IdeaPad Gaming 3", "Lenovo", "82K20289IN", "Ryzen 5 5500H / 8GB / 512GB SSD / RTX 2050", 47990, 68990, "AMD Ryzen 5 5500H", "NVIDIA RTX 2050 (4GB)", 8, 512, 15.6, 45, 1, 4.2, 1520, 12, "144Hz FHD, Military Grade MIL-STD-810G", "Budget gaming, college coding"),
        ("ASUS Vivobook Pro 15 OLED", "ASUS", "M6500QC-HN541WS", "Ryzen 5 5600H / 16GB / 512GB SSD / RTX 3050", 62990, 80990, "AMD Ryzen 5 5600H", "NVIDIA RTX 3050 (4GB)", 16, 512, 15.6, 50, 1, 4.4, 940, 12, "FHD OLED 600 nits 100% DCI-P3, DialPad", "Creative design, programming, photo editing"),
        ("Apple MacBook Pro 14 M3", "Apple", "MTL73HN/A", "Apple M3 / 8GB / 512GB SSD / Space Grey", 159900, 169900, "Apple M3 (8-core CPU)", "Apple 10-core GPU", 8, 512, 14.2, 70, 2, 4.8, 1200, 12, "Liquid Retina XDR 120Hz ProMotion, 22-hour battery, HDMI, SD Card", "Professional developers, iOS compilation, media production"),
        ("Dell XPS 13 9315", "Dell", "XPS-9315-B740", "Core i5 1230U / 16GB / 512GB SSD / Iris Xe", 94990, 119990, "Intel Core i5 1230U", "Intel Iris Xe", 16, 512, 13.4, 51, 1, 4.4, 520, 12, "CNC machined aluminum, InfinityEdge 500 nits, 1.17 kg", "Executive business, portable software development"),
        ("HP Pavilion 14", "HP", "14-dv2014TU", "Core i5 1235U / 16GB / 512GB SSD / Iris Xe", 61990, 77990, "Intel Core i5 1235U", "Intel Iris Xe", 16, 512, 14.0, 43, 1, 4.3, 1640, 12, "FHD IPS micro-edge, B&O audio, backlit keyboard", "Everyday programming, student coursework, office"),
        ("Lenovo Yoga Slim 7x", "Lenovo", "83ED0049IN", "Snapdragon X Elite / 16GB / 1TB SSD / Adreno GPU", 139990, 168990, "Qualcomm Snapdragon X Elite (12-core)", "Qualcomm Adreno GPU (45 TOPS NPU)", 16, 1024, 14.5, 70, 2, 4.7, 410, 36, "3K OLED 90Hz PureSight 1000 nits, Copilot+ PC AI, 1.28 kg", "Next-gen AI coding, insane multi-day battery, Copilot+ PC"),
        ("ASUS ROG Zephyrus G14", "ASUS", "GA403UU-QS077W", "Ryzen 9 8945HS / 16GB / 1TB SSD / RTX 4060", 149990, 189990, "AMD Ryzen 9 8945HS (with Ryzen AI)", "NVIDIA RTX 4060 (8GB, 90W)", 16, 1024, 14.0, 73, 2, 4.8, 760, 24, "3K 120Hz OLED ROG Nebula display, Slash Lighting, 1.5 kg CNC chassis", "Compact ultra-performance machine learning, gaming on the go"),

        # Additional Phones
        ("Samsung Galaxy A55 5G", "Samsung", "SM-A556E", "8GB RAM / 128GB / Awesome Iceblue", 36999, 42999, "Exynos 1480 4nm AMD RDNA", "Xclipse 530", 8, 128, 6.6, "5000mAh", "50MP OIS + 12MP Ultrawide + 5MP Macro", 4.3, 4900, 12, "Metal frame, Gorilla Glass Victus+, Knox Vault security, 4 OS upgrades", "Premium build mid-ranger, security, durability"),
        ("Realme 12 Pro+ 5G", "Realme", "RMX3840", "8GB RAM / 256GB / Submarine Blue", 29999, 34999, "Snapdragon 7s Gen 2", "Adreno 710", 8, 256, 6.7, "5000mAh", "64MP 3x Periscope OIS + 50MP Sony IMX890 OIS + 8MP", 4.4, 7800, 12, "Luxury watch design, 3x periscope telephoto zoom, 120Hz curved AMOLED", "Camera zoom enthusiast, premium design under ₹30k"),
        ("Nothing Phone (2a)", "Nothing", "A142", "8GB RAM / 128GB / Black", 23999, 25999, "MediaTek Dimensity 7200 Pro", "Mali-G610 MC4", 8, 128, 6.7, "5000mAh", "50MP OIS + 50MP Ultrawide", 4.4, 15600, 12, "Iconic Glyph interface, clean Nothing OS 2.5, symmetrical bezels", "Clean bloatware-free UI, distinctive aesthetics, balanced specs"),
        ("Vivo V30 Pro 5G", "Vivo", "V2319", "8GB RAM / 256GB / Andaman Blue", 41999, 46999, "MediaTek Dimensity 8200 4nm", "Mali-G610 MC6", 8, 256, 6.78, "5000mAh", "50MP Sony IMX920 OIS + 50MP ZEISS Portrait + 50MP Ultra Wide", 4.5, 4100, 12, "ZEISS Professional Portrait Camera, Studio quality Aura Light", "Portrait photography, slim 7.45mm body, ZEISS color science"),
        ("Xiaomi 14", "Xiaomi", "23127PN0CG", "12GB RAM / 512GB / White", 69999, 79999, "Snapdragon 8 Gen 3", "Adreno 750", 12, 512, 6.36, "4610mAh", "50MP Leica Summilux OIS + 50MP 3.2x Leica Telephoto + 50MP Ultra Wide", 4.7, 3400, 12, "Leica professional optics, ultra-narrow bezel 1.5K 120Hz LTPO, 90W charge", "Compact Android flagship, Leica camera tuning, elite performance"),

        # Additional Headphones
        ("JBL Tune 760NC", "JBL", "JBLT760NCBLK", "Over-Ear Wireless / Black / Active Noise Cancelling", 5499, 7999, "JBL Pure Bass Sound", "40mm Dynamic Driver", 0, 0, 0, "35 Hours with ANC", "Mic with Voice Assistant", 4.2, 11200, 12, "JBL Pure Bass, lightweight foldable design, multi-point connection", "Commuters, deep bass lovers, everyday wireless"),
        ("Apple AirPods (3rd Gen)", "Apple", "MPNY3HN/A", "True Wireless / White / Lightning Case", 16900, 19900, "Apple H1 Chip", "Custom Apple high-excursion", 0, 0, 0, "30 Hours total", "Dual beamforming microphones", 4.5, 8400, 12, "Personalized Spatial Audio with dynamic head tracking, IPX4 sweat resistant", "iPhone users wanting open-ear comfort without silicone tips"),
        ("OnePlus Bullets Wireless Z2", "OnePlus", "E305A", "Neckband Wireless / Magico Black / Fast Charge", 1699, 2299, "Bass Booster", "12.4mm Drivers", 0, 0, 0, "30 Hours battery", "AI Noise Cancellation Mic", 4.3, 110000, 12, "10 min charge = 20 hours audio, IP55 sweat resistance, magnetic clip", "Workout neckband, all-day battery life, reliable budget daily"),
        ("Sony WF-1000XM5", "Sony", "WF1000XM5/B", "True Wireless / Black / Industry Leading Noise Canceling", 22990, 29990, "Dual Processor V2 & HD QN2e", "8.4mm Dynamic Driver X", 0, 0, 0, "24 Hours total", "6 Mics with Bone Conduction Sensors", 4.5, 4100, 12, "Best noise cancelling earbuds on market, LDAC, AI call isolation", "Ultimate compact noise cancellation, audiophile sound"),

        # Additional Smartwatches
        ("OnePlus Nord Watch", "OnePlus", "OPBBE221", "1.78 inch AMOLED / Deep Blue / 60Hz", 3499, 6999, "Fast Motion Tracker", "Proprietary", 0, 0, 1.78, "10 Days battery", "N/A", 4.1, 14200, 12, "1.78-inch 60Hz AMOLED 500 nits, SpO2 & Heart Rate 24h, 105 sports modes", "Vibrant AMOLED on budget, fitness & sleep monitoring"),
        ("Titan Talk Touch", "Titan", "90165AP01", "1.39 inch AMOLED / Black / BT Calling", 4995, 9995, "Titan Smart Suite", "Proprietary", 0, 0, 1.39, "5 Days battery", "N/A", 4.2, 3600, 12, "Classic metallic finish, Bluetooth calling, AI voice assistant support", "Office and formal wear smartwatch, trusted Indian brand"),
        ("Fastrack Limitless FS1 Pro", "Fastrack", "38096PP01", "1.96 inch Super AMOLED / Black / Calling", 2495, 5995, "Fastrack NextGen Suite", "Proprietary", 0, 0, 1.96, "7 Days battery", "N/A", 4.1, 18900, 12, "1.96-inch Arched Super AMOLED display, SingleSync BT calling, 110+ sports", "Trendy youth smartwatch with large vivid curved display"),

        # Additional TVs
        ("Samsung 55 inch QLED 4K", "Samsung", "QA55Q60DAULXL", "55 inch 4K QLED / Quantum Processor Lite", 64990, 94900, "Quantum Processor Lite 4K", "Tizen OS", 2, 16, 55.0, "145W typical", "N/A", 4.5, 5800, 24, "100% Color Volume with Quantum Dot, AirSlim design, Dual LED backlighting", "Premium living room entertainment, vibrant movies"),
        ("OnePlus 43 inch Y1S Pro", "OnePlus", "43Y1SPro", "43 inch 4K Ultra HD / Gamma Engine", 24999, 39999, "MediaTek 64-bit Quad Core", "Android TV 10", 2, 8, 43.0, "100W typical", "N/A", 4.2, 21000, 12, "HDR10+, Dolby Audio 24W, Seamless OnePlus Connect with OnePlus devices", "Smart ecosystem connectivity, 4K streaming under ₹25k"),
        ("Vu 55 inch GloLED 4K", "Vu", "55GloLED", "55 inch 4K GloLED / 400 Nits / Built-in Subwoofer", 32999, 55000, "Glo AI Processor", "Google TV", 2, 16, 55.0, "120W typical", "N/A", 4.3, 11400, 12, "Glo Panel 94% NTSC color gamut, 104W DJ sound with integrated subwoofer", "Party sound directly from TV, bright punchy display"),

        # Additional Tablets
        ("OnePlus Pad Go", "OnePlus", "OPD2304", "8GB RAM / 128GB / Twin Mint / 2.4K 90Hz", 19999, 21999, "MediaTek Helio G99", "Mali-G57 MC2", 8, 128, 11.35, "8000mAh", "8MP Rear + 8MP Front", 4.4, 9100, 12, "2.4K Eye-care 90Hz display, Quad speakers with Dolby Atmos, OxygenOS for Pad", "Study tablet, reading books, media streaming"),
        ("Apple iPad mini (6th Gen)", "Apple", "MK7M3HN/A", "64GB / Space Grey / Wi-Fi / A15 Bionic", 46900, 49900, "Apple A15 Bionic 6-core", "Apple 5-core GPU", 4, 64, 8.3, "19.3Wh Li-Po", "12MP Wide + 12MP Ultra Wide Center Stage", 4.7, 4300, 12, "Compact 8.3-inch Liquid Retina, Apple Pencil 2 magnetic attachment, pocket size", "Pilot charts, medical rounds, compact reading, portable sketchpad"),
    ]

    for item in extra_templates:
        raw_products.append({
            "product_id": prod_id,
            "name": item[0],
            "brand": item[1],
            "category": item[2] if len(item) > 17 and item[2] in ["Laptops", "Smartphones", "Headphones", "Smartwatches", "Televisions", "Tablets"] else (
                "Laptops" if "Laptop" in item[0] or "MacBook" in item[0] or "IdeaPad" in item[0] or "Vivobook" in item[0] or "Zenbook" in item[0] or "Yoga" in item[0] or "XPS" in item[0] or "Pavilion" in item[0]
                else ("Smartphones" if "5G" in item[0] or "iPhone" in item[0] or "Galaxy" in item[0] and "Tab" not in item[0] and "Watch" not in item[0] or "Phone" in item[0] or "Pro+" in item[0]
                else ("Headphones" if "Tune" in item[0] or "AirPods" in item[0] or "Bullets" in item[0] or "WF-" in item[0] or "WH-" in item[0]
                else ("Smartwatches" if "Watch" in item[0] or "Touch" in item[0] or "Limitless" in item[0]
                else ("Televisions" if "TV" in item[0] or "GloLED" in item[0] or "QLED" in item[0]
                else "Tablets"))))
            ),
            "model_number": item[2] if item[2] not in ["Laptops", "Smartphones", "Headphones", "Smartwatches", "Televisions", "Tablets"] else item[1],
            "variant": item[3],
            "price": item[4],
            "mrp": item[5],
            "processor": item[6],
            "gpu": item[7],
            "ram_gb": item[8],
            "storage_gb": item[9],
            "display_size": item[10],
            "battery_spec": f"{item[11]}Wh" if isinstance(item[11], (int, float)) and item[11] < 150 else str(item[11]),
            "camera_spec": item[12] if isinstance(item[12], str) else ("720p Webcam" if item[12] == 1 else "1080p Webcam"),
            "connectivity": "Wi-Fi, Bluetooth, High-speed USB",
            "rating": item[13],
            "review_count": item[14],
            "warranty_months": item[15],
            "highlights": item[16],
            "intended_use": item[17],
            "image_url": f"/static/images/placeholders/laptop.svg"
        })
        prod_id += 1

    # Generate realistic variant step-ups (different RAM, Storage, Color/Edition) to expand catalog to ~180 products
    # This also directly tests that the product matching engine distinguishes different RAM/storage configurations!
    variant_expansions = []
    for p in list(raw_products):
        cat = p["category"]
        if cat in ["Laptops", "Smartphones", "Tablets"] and p["storage_gb"] > 0:
            # Create a higher storage or RAM tier variant
            if p["storage_gb"] in [64, 128, 256, 512]:
                new_storage = p["storage_gb"] * 2
                new_ram = p["ram_gb"]
                if cat == "Laptops" and p["ram_gb"] == 8:
                    new_ram = 16
                elif cat == "Smartphones" and p["ram_gb"] == 6:
                    new_ram = 8
                
                price_delta = 4000 if cat == "Smartphones" else (7000 if cat == "Tablets" else 9000)
                new_price = p["price"] + price_delta
                new_mrp = p["mrp"] + price_delta + 2000
                v_text = f"{new_ram}GB RAM / {new_storage}GB Storage" if cat != "Laptops" else f"{new_ram}GB / {new_storage}GB SSD"
                
                variant_expansions.append({
                    "product_id": prod_id,
                    "name": f"{p['name']} ({new_ram}GB/{new_storage}GB)",
                    "brand": p["brand"],
                    "category": p["category"],
                    "model_number": f"{p['model_number']}-{new_storage}G",
                    "variant": f"{v_text} / High-Capacity Edition",
                    "price": new_price,
                    "mrp": new_mrp,
                    "processor": p["processor"],
                    "gpu": p["gpu"],
                    "ram_gb": new_ram,
                    "storage_gb": new_storage,
                    "display_size": p["display_size"],
                    "battery_spec": p["battery_spec"],
                    "camera_spec": p["camera_spec"],
                    "connectivity": p["connectivity"],
                    "rating": min(5.0, round(p["rating"] + 0.1, 1)),
                    "review_count": int(p["review_count"] * 0.6),
                    "warranty_months": p["warranty_months"],
                    "highlights": f"Upgraded {new_ram}GB Memory & {new_storage}GB Storage, {p['highlights'][:50]}",
                    "intended_use": p["intended_use"],
                    "image_url": p["image_url"]
                })
                prod_id += 1

    raw_products.extend(variant_expansions)

    for p in raw_products:
        cat = p["category"]
        if cat == "Laptops":
            p["image_url"] = "/static/images/placeholders/laptop.svg"
        elif cat == "Smartphones":
            p["image_url"] = "/static/images/placeholders/smartphone.svg"
        elif cat == "Headphones":
            p["image_url"] = "/static/images/placeholders/headphones.svg"
        elif cat == "Smartwatches":
            p["image_url"] = "/static/images/placeholders/smartwatch.svg"
        elif cat == "Televisions":
            p["image_url"] = "/static/images/placeholders/tv.svg"
        elif cat == "Tablets":
            p["image_url"] = "/static/images/placeholders/tablet.svg"

    # Write data/products.csv
    products_csv_path = DATA_DIR / "products.csv"
    with open(products_csv_path, "w", newline="", encoding="utf-8") as f:
        fieldnames = [
            "product_id", "name", "brand", "category", "model_number", "variant",
            "price", "mrp", "processor", "gpu", "ram_gb", "storage_gb",
            "display_size", "battery_spec", "camera_spec", "connectivity",
            "rating", "review_count", "warranty_months", "highlights", "intended_use", "image_url"
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for p in raw_products:
            writer.writerow(p)

    print(f"Generated {len(raw_products)} products into {products_csv_path}")

    # 2. Generate Multi-Platform Listings (Amazon, Flipkart, Croma, Reliance Digital, Vijay Sales, Official Brand Store)
    listings = []
    listing_id = 5001

    platforms_meta = [
        {"id": "amazon", "name": "Amazon India", "type": "Marketplace", "base_seller": "Appario Retail Pvt Ltd", "seller_rating": 4.6},
        {"id": "flipkart", "name": "Flipkart", "type": "Marketplace", "base_seller": "RetailNet SuperSeller", "seller_rating": 4.5},
        {"id": "croma", "name": "Croma", "type": "Retailer", "base_seller": "Infiniti Retail Ltd (Croma)", "seller_rating": 4.4},
        {"id": "reliance", "name": "Reliance Digital", "type": "Retailer", "base_seller": "Reliance Retail Ltd", "seller_rating": 4.3},
        {"id": "vijay_sales", "name": "Vijay Sales", "type": "Retailer", "base_seller": "Vijay Sales Electronic Retails", "seller_rating": 4.2},
        {"id": "official_store", "name": "Official Brand Store", "type": "Official Brand Store", "base_seller": "Direct Manufacturer", "seller_rating": 4.9}
    ]

    for p in raw_products:
        base_price = float(p["price"])
        mrp = float(p["mrp"])

        # Create between 3 and 6 platform listings for each product
        num_stores = random.choice([3, 4, 5, 6])
        selected_platforms = random.sample(platforms_meta, num_stores)

        # Make sure official store is included for high-profile products
        if p["brand"] in ["Apple", "Samsung", "HP", "ASUS", "Lenovo", "Sony"] and not any(sp["id"] == "official_store" for sp in selected_platforms):
            selected_platforms[0] = platforms_meta[5]

        for plat in selected_platforms:
            # Slight price variance around base price (-4% to +3%)
            variance_factor = random.uniform(0.97, 1.03)
            if plat["id"] == "flipkart" and random.random() > 0.5:
                # Sometimes slightly cheaper on Flipkart
                variance_factor = random.uniform(0.96, 0.99)
            elif plat["id"] == "official_store":
                # Official store tends to sell near retail MSRP but with full brand warranty
                variance_factor = random.uniform(0.99, 1.02)

            listed_price = round((base_price * variance_factor) / 10) * 10
            # Ensure listed price does not exceed MRP
            if listed_price > mrp:
                listed_price = mrp - 500

            discount = max(0, round(mrp - listed_price))

            # Guaranteed discount (e.g. coupon on product page or instant checkout promo)
            has_coupon = random.random() < 0.35
            coupon_discount = random.choice([500, 1000, 1500, 2000]) if (has_coupon and listed_price > 25000) else 0

            # Mandatory delivery charge
            if listed_price >= 20000 or plat["id"] in ["amazon", "flipkart"]:
                delivery_charge = 0
            else:
                delivery_charge = random.choice([0, 49, 99])

            # Conditional bank offer text (NOT deducted from effective price automatically)
            bank_names = ["HDFC Bank", "ICICI Bank", "SBI Card", "Axis Bank", "OneCard"]
            bank = random.choice(bank_names)
            card_discount = min(3000, max(500, round(listed_price * 0.05)))
            bank_offer_text = f"Flat ₹{card_discount:,} Instant Discount on {bank} Credit Card EMI" if listed_price > 10000 else f"10% off up to ₹750 on {bank} Debit Cards"

            # Product title variations (demonstrates exact vs variant matching normalization)
            title_variance_mode = random.choice(["exact", "verbose", "sku_added", "model_rearranged"])
            if title_variance_mode == "exact":
                listing_title = f"{p['brand']} {p['name']} ({p['variant']})"
            elif title_variance_mode == "verbose":
                listing_title = f"{p['name']} ({p['variant']}, {p['highlights'][:40]})"
            elif title_variance_mode == "sku_added":
                listing_title = f"{p['brand']} {p['model_number']} - {p['name']} / {p['variant']}"
            else:
                listing_title = f"{p['name']} Model {p['model_number']} ({p['brand']})"

            # Availability
            avail_status = random.choices(["In Stock", "Only 2 left in stock", "Usually dispatched in 24 hours"], weights=[0.85, 0.10, 0.05])[0]

            # Delivery timeline
            delivery_timeline = random.choice(["Tomorrow by 11 PM", "2 Days Free Delivery", "Standard Delivery in 3-4 days"])

            # Warranty
            warranty_text = f"{p['warranty_months']} Months Official Brand Warranty"

            # Product URL (Safe demo link)
            store_slug = plat['name'].lower().replace(' ', '-')
            demo_url = f"https://www.{store_slug}.demo/product/{p['product_id']}?model={p['model_number']}"

            listings.append({
                "listing_id": listing_id,
                "product_id": p["product_id"],
                "platform_id": plat["id"],
                "platform_name": plat["name"],
                "platform_type": plat["type"],
                "listing_title": listing_title,
                "brand": p["brand"],
                "model_number": p["model_number"],
                "variant": p["variant"],
                "listed_price": int(listed_price),
                "mrp": int(mrp),
                "discount": int(discount),
                "coupon_discount": int(coupon_discount),
                "delivery_charge": int(delivery_charge),
                "bank_offer_text": bank_offer_text,
                "seller_name": plat["base_seller"],
                "seller_rating": plat["seller_rating"],
                "availability": avail_status,
                "warranty": warranty_text,
                "delivery_info": delivery_timeline,
                "product_url": demo_url,
                "data_source": "DEMO DATA",
                "last_updated": "2026-09-30"
            })
            listing_id += 1

    # Write data/platform_listings.csv
    listings_csv_path = DATA_DIR / "platform_listings.csv"
    with open(listings_csv_path, "w", newline="", encoding="utf-8") as f:
        fieldnames = [
            "listing_id", "product_id", "platform_id", "platform_name", "platform_type",
            "listing_title", "brand", "model_number", "variant", "listed_price",
            "mrp", "discount", "coupon_discount", "delivery_charge", "bank_offer_text",
            "seller_name", "seller_rating", "availability", "warranty", "delivery_info",
            "product_url", "data_source", "last_updated"
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for l in listings:
            writer.writerow(l)

    print(f"Generated {len(listings)} multi-platform listings into {listings_csv_path}")

    # 3. Generate Users & User Searches (For DWDM Star Schema facts)
    users = []
    searches = []
    user_budgets = [
        ("Student / Budget", 30000, 50000, "Laptops"),
        ("Developer / ML Enthusiast", 70000, 110000, "Laptops"),
        ("Gamer", 65000, 120000, "Laptops"),
        ("Mobile Photography", 30000, 60000, "Smartphones"),
        ("Audiophile / Focus", 5000, 25000, "Headphones"),
        ("Fitness Enthusiast", 3000, 20000, "Smartwatches"),
        ("Home Theater Enthusiast", 40000, 120000, "Televisions"),
        ("Digital Artist / Student", 20000, 60000, "Tablets")
    ]

    for u_id in range(1, 201):
        persona = random.choice(user_budgets)
        pref_budget = random.randint(persona[1], persona[2])
        users.append({
            "user_id": u_id,
            "persona_name": persona[0],
            "preferred_category": persona[3],
            "budget_range": f"₹{persona[1]:,} - ₹{persona[2]:,}",
            "created_at": "2026-09-15"
        })

        # Generate 1 to 3 search records per user
        num_s = random.randint(1, 3)
        for s_idx in range(num_s):
            cat_prods = [p for p in raw_products if p["category"] == persona[3]]
            chosen_rec = random.choice(cat_prods) if cat_prods else random.choice(raw_products)
            searches.append({
                "search_id": len(searches) + 1,
                "user_id": u_id,
                "query_text": f"Best {persona[3].lower()} under ₹{pref_budget:,} for {persona[0]}",
                "category": persona[3],
                "budget": pref_budget,
                "recommended_product_id": chosen_rec["product_id"],
                "search_date": f"2026-09-{random.randint(15, 30):02d}"
            })

    # Write users.csv & searches.csv
    users_csv_path = DATA_DIR / "users.csv"
    with open(users_csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["user_id", "persona_name", "preferred_category", "budget_range", "created_at"])
        writer.writeheader()
        for u in users:
            writer.writerow(u)

    searches_csv_path = DATA_DIR / "searches.csv"
    with open(searches_csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["search_id", "user_id", "query_text", "category", "budget", "recommended_product_id", "search_date"])
        writer.writeheader()
        for s in searches:
            writer.writerow(s)

    print(f"Generated {len(users)} users and {len(searches)} search queries for DWDM warehouse.")

if __name__ == "__main__":
    generate_datasets()
