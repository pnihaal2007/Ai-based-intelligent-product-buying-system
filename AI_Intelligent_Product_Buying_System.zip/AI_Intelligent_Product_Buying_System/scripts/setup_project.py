"""One-command project setup script.
Executes end-to-end initialization:
1. Generates realistic synthetic datasets (data/products.csv, data/platform_listings.csv)
2. Initializes SQLite operational database and DWDM star schema
3. Executes full ETL pipeline (cleans, normalizes, loads dimensions & facts)
4. Trains and serializes Machine Learning models (K-Means product clustering & scalers)
5. Verifies all generated database tables and model artifacts
"""
import sys
import sqlite3
from pathlib import Path

# Add project root to sys.path
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from config import Config
from scripts.generate_demo_data import generate_datasets
from database.create_database import init_database
from dwdm.etl import run_etl
from ml.train_models import train_and_save_models

def setup_entire_project():
    """Runs all initialization steps sequentially with status checks."""
    print("=" * 70)
    print("AI-BASED INTELLIGENT PRODUCT BUYING DECISION SYSTEM")
    print("One-Command Project Setup & Initialization Script")
    print("=" * 70)

    # Step 1: Generate Demo Datasets
    print("\n[STEP 1/5] Generating Demo Datasets in ₹ INR...")
    generate_datasets()
    if not Config.PRODUCTS_CSV.exists() or not Config.LISTINGS_CSV.exists():
        raise RuntimeError("Dataset generation failed!")
    print("✓ Demo datasets generated successfully.")

    # Step 2: Initialize Database Schema
    print("\n[STEP 2/5] Creating SQLite Database & Star-Schema Tables...")
    init_database(Config.DATABASE_PATH)
    if not Config.DATABASE_PATH.exists():
        raise RuntimeError("Database file was not created!")
    print("✓ Database and Star-Schema tables initialized.")

    # Step 3: Run ETL Pipeline
    print("\n[STEP 3/5] Executing DWDM ETL Pipeline...")
    etl_stats = run_etl(Config.DATABASE_PATH)
    print(f"✓ ETL completed: {etl_stats['products_loaded']} products & {etl_stats['listings_loaded']} listings loaded.")

    # Step 4: Train ML Models
    print("\n[STEP 4/5] Training Machine Learning Models (K-Means Clustering)...")
    train_and_save_models(Config.DATABASE_PATH, Config.ML_MODELS_DIR)
    if not Config.KMEANS_MODEL_PATH.exists():
        raise RuntimeError("ML model file was not generated!")
    print("✓ ML models trained and artifacts persisted to ml/models/.")

    # Step 5: Final Verification Checklist
    print("\n[STEP 5/5] Performing System Verification...")
    conn = sqlite3.connect(Config.DATABASE_PATH)
    cursor = conn.cursor()

    checks = [
        ("products", "SELECT COUNT(*) FROM products;"),
        ("product_listings", "SELECT COUNT(*) FROM product_listings;"),
        ("dim_product", "SELECT COUNT(*) FROM dim_product;"),
        ("fact_product_prices", "SELECT COUNT(*) FROM fact_product_prices;"),
        ("fact_user_searches", "SELECT COUNT(*) FROM fact_user_searches;"),
    ]

    all_ok = True
    for table_name, sql in checks:
        cursor.execute(sql)
        count = cursor.fetchone()[0]
        if count > 0:
            print(f"  ✓ Table '{table_name}': {count} records verified.")
        else:
            print(f"  ✗ Table '{table_name}' is empty!")
            all_ok = False
    conn.close()

    if all_ok:
        print("\n" + "=" * 70)
        print("PROJECT SETUP COMPLETE & VERIFIED SUCCESSFULLY!")
        print("To start the application locally, run:")
        print("  python app.py")
        print("=" * 70)
    else:
        print("\nWarning: Some database tables appear empty. Review output above.")

if __name__ == "__main__":
    setup_entire_project()
