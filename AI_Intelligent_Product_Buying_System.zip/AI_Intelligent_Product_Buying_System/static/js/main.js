// Main JavaScript for AI Shopping Assistant and Interactive Components

document.addEventListener("DOMContentLoaded", function () {
  // 1. Example query quick-click handler
  const exampleButtons = document.querySelectorAll(".example-query-btn");
  const queryInput = document.querySelector("#aiQueryInput") || document.querySelector(".hero-search-input");

  if (exampleButtons && queryInput) {
    exampleButtons.forEach((btn) => {
      btn.addEventListener("click", function () {
        const text = this.getAttribute("data-query");
        if (text) {
          queryInput.value = text;
          queryInput.focus();
        }
      });
    });
  }

  // 2. Dynamic Manual Preference Form Category Switcher
  const categorySelect = document.querySelector("#manualCategorySelect");
  if (categorySelect) {
    categorySelect.addEventListener("change", function () {
      const selected = this.value;
      const sections = document.querySelectorAll(".category-specific-fields");
      sections.forEach((sec) => (sec.style.display = "none"));

      if (selected === "Laptops") {
        const lap = document.querySelector("#laptopSpecificFields");
        if (lap) lap.style.display = "block";
      } else if (selected === "Smartphones") {
        const phone = document.querySelector("#phoneSpecificFields");
        if (phone) phone.style.display = "block";
      } else if (selected === "Headphones") {
        const head = document.querySelector("#headphoneSpecificFields");
        if (head) head.style.display = "block";
      } else if (selected === "Televisions") {
        const tv = document.querySelector("#tvSpecificFields");
        if (tv) tv.style.display = "block";
      }
    });
  }

  // 3. Compare List Storage Manager
  window.toggleCompare = function (productId, productName) {
    let compareList = JSON.parse(localStorage.getItem("ai_compare_list") || "[]");
    const idx = compareList.indexOf(productId);

    if (idx > -1) {
      compareList.splice(idx, 1);
      updateCompareUI(compareList);
      showToast(`Removed "${productName}" from comparison`);
    } else {
      if (compareList.length >= 4) {
        alert("You can compare a maximum of 4 products at a time.");
        return;
      }
      compareList.push(productId);
      updateCompareUI(compareList);
      showToast(`Added "${productName}" to comparison (Total: ${compareList.length})`);
    }
  };

  function updateCompareUI(list) {
    localStorage.setItem("ai_compare_list", JSON.stringify(list));
    const badge = document.querySelector("#compareBadge");
    if (badge) {
      badge.textContent = list.length;
      badge.style.display = list.length > 0 ? "inline-block" : "none";
    }
    const compareLink = document.querySelector("#navCompareLink");
    if (compareLink && list.length > 0) {
      compareLink.href = `/compare?ids=${list.join(",")}`;
    }
  }

  // Initial badge sync
  const currentList = JSON.parse(localStorage.getItem("ai_compare_list") || "[]");
  updateCompareUI(currentList);

  function showToast(message) {
    const existing = document.querySelector("#toastAlert");
    if (existing) existing.remove();

    const toast = document.createElement("div");
    toast.id = "toastAlert";
    toast.className = "position-fixed bottom-0 end-0 p-3";
    toast.style.zIndex = 1080;
    toast.innerHTML = `
      <div class="toast show align-items-center text-white bg-dark border-0 shadow" role="alert">
        <div class="d-flex">
          <div class="toast-body"><i class="bi bi-info-circle me-2"></i>${message}</div>
          <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
      </div>
    `;
    document.body.appendChild(toast);
    setTimeout(() => {
      if (toast) toast.remove();
    }, 3000);
  }
});
