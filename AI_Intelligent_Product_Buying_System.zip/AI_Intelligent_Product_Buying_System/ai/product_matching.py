"""Cross-Platform Exact Product and Variant Matching Engine.
Determines whether listings across different stores represent the exact same product,
the same model family with a different RAM/storage variant, a probable match, or a different product.
"""
import re
from typing import Dict, Any, Tuple

class ProductMatchingEngine:
    """Verifies variant identity and computes matching confidence scores."""

    @staticmethod
    def extract_specs_from_title(text: str) -> Dict[str, Any]:
        """Extracts key hardware specifications from product or listing titles."""
        text_lower = text.lower()
        specs = {
            "ram_gb": None,
            "storage_gb": None,
            "model_code": None
        }

        # RAM extraction (e.g. 8GB RAM, 16 GB, 12GB)
        ram_m = re.search(r'\b(4|6|8|12|16|24|32|64)\s*(?:gb|g)?\s*(?:ram|unified|memory)?\b', text_lower)
        if ram_m and int(ram_m.group(1)) in [4, 6, 8, 12, 16, 24, 32, 64]:
            specs["ram_gb"] = int(ram_m.group(1))

        # Storage extraction (e.g. 128GB, 256GB, 512GB, 1TB)
        tb_m = re.search(r'\b(1|2)\s*tb\b', text_lower)
        if tb_m:
            specs["storage_gb"] = int(tb_m.group(1)) * 1024
        else:
            gb_m = re.search(r'\b(64|128|256|512)\s*(?:gb|g)?\s*(?:ssd|rom|storage)?\b', text_lower)
            if gb_m:
                specs["storage_gb"] = int(gb_m.group(1))

        # Model code extraction (e.g. 15-fa0070TX, SM-S928B, MLY33HN/A)
        model_m = re.search(r'\b([a-z0-9]{2,6}-[a-z0-9]{4,8}|[a-z]{1,3}\d{3,5}[a-z]{0,3}|[a-z0-9]{5,8}/[a-z])\b', text_lower)
        if model_m:
            specs["model_code"] = model_m.group(1).upper()

        return specs

    def compute_match_confidence(self, base_product: Dict[str, Any], listing: Dict[str, Any]) -> Tuple[float, str, str]:
        """Compares a canonical product against a store listing.
        Returns:
            confidence (float 0.0 - 100.0)
            classification ("Exact Match", "Probable Match", "Different Variant", "Different Product")
            detail_explanation (str)
        """
        b_brand = str(base_product.get("brand", "")).strip().lower()
        l_brand = str(listing.get("brand", "")).strip().lower()
        b_model = str(base_product.get("model_number", "")).strip().lower()
        l_model = str(listing.get("model_number", "")).strip().lower()
        b_name = str(base_product.get("name", "")).strip().lower()
        l_title = str(listing.get("listing_title", "")).strip().lower()

        # Check Brand alignment
        if b_brand and l_brand and b_brand != l_brand:
            return 20.0, "Different Product", f"Brand mismatch ({b_brand.title()} vs {l_brand.title()})"

        # Check explicit Model Number matching
        model_exact = (b_model and l_model and b_model == l_model)
        model_in_title = bool(b_model and b_model in l_title)

        # Extract specifications from both
        b_ram = base_product.get("ram_gb")
        b_storage = base_product.get("storage_gb")

        l_specs = self.extract_specs_from_title(l_title + " " + str(listing.get("variant", "")))
        l_ram = listing.get("ram_gb") or l_specs["ram_gb"]
        l_storage = listing.get("storage_gb") or l_specs["storage_gb"]

        # Check for Variant Discrepancy (e.g. 8GB vs 16GB or 128GB vs 256GB)
        variant_mismatch = False
        mismatch_reasons = []

        if b_ram and l_ram and int(b_ram) != int(l_ram):
            variant_mismatch = True
            mismatch_reasons.append(f"RAM difference ({b_ram}GB vs {l_ram}GB)")

        if b_storage and l_storage and int(b_storage) != int(l_storage):
            variant_mismatch = True
            mismatch_reasons.append(f"Storage difference ({b_storage}GB vs {l_storage}GB)")

        if variant_mismatch:
            # Different Variant of same product line!
            # Section 16 rule: 8GB/128GB vs 12GB/256GB must NOT be considered identical!
            confidence = 61.0
            classification = "Different Variant"
            explanation = "Same product family, but " + ", ".join(mismatch_reasons)
            return confidence, classification, explanation

        # High Confidence Exact Match
        if model_exact or (model_in_title and (b_ram == l_ram or not l_ram)):
            confidence = 98.0
            classification = "Exact Match"
            explanation = "Model code, brand, and hardware configurations are identical."
            return confidence, classification, explanation

        # Check name token overlap
        b_tokens = set(re.findall(r'\w+', b_name)) - {"5g", "laptop", "phone", "tv", "inch", "gb"}
        l_tokens = set(re.findall(r'\w+', l_title))
        overlap = len(b_tokens.intersection(l_tokens)) / max(1, len(b_tokens))

        if overlap >= 0.75:
            confidence = 88.0
            classification = "Probable Match"
            explanation = "Product title and core hardware specifications match with high confidence."
            return confidence, classification, explanation
        elif overlap >= 0.50:
            confidence = 68.0
            classification = "Probable Match"
            explanation = "Similar product naming; verify full variant details before ordering."
            return confidence, classification, explanation
        else:
            confidence = 35.0
            classification = "Different Product"
            explanation = "Listing does not match the target model specifications."
            return confidence, classification, explanation
