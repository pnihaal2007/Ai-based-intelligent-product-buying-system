"""Explainable AI engine that generates transparent, data-grounded pros and trade-offs
directly from real stored product specifications and user requirements.
"""
from typing import Dict, Any, List

class ExplanationEngine:
    """Generates human-readable, specification-grounded explanations for AI recommendations."""

    @staticmethod
    def generate_reasons(product: Dict[str, Any], user_req: Dict[str, Any]) -> List[str]:
        """Generates realistic positive reasons why the product fits the user."""
        reasons = []
        category = product.get("category", "")
        uses = user_req.get("use_cases", [])
        budget = user_req.get("budget", float('inf'))
        price = product.get("price", 0)
        proc = str(product.get("processor", ""))
        gpu = str(product.get("gpu", ""))
        ram = int(product.get("ram_gb", 0))
        storage = int(product.get("storage_gb", 0))
        highlights = str(product.get("highlights", ""))

        # Budget fit reason
        if price <= budget:
            diff = budget - price
            if diff >= 5000:
                reasons.append(f"Comfortably within budget (₹{diff:,.0f} remaining for accessories or savings)")
            else:
                reasons.append(f"Fits directly within your stated ₹{budget:,.0f} budget")

        # Category-specific reasons
        if category == "Laptops":
            if "programming" in uses:
                if ram >= 16:
                    reasons.append(f"{ram}GB high-speed memory allows running heavy IDEs, Docker and background emulators smoothly")
                if "Core i7" in proc or "Ryzen 7" in proc or "Core i5" in proc or "Apple M" in proc:
                    reasons.append(f"Fast {proc} ensures quick code compilation and multi-core task handling")
            if "gaming" in uses or "machine_learning" in uses:
                if "RTX" in gpu:
                    reasons.append(f"Dedicated {gpu} provides CUDA support for ML models and high FPS gaming")
                elif "Radeon" in gpu or "Iris" in gpu:
                    reasons.append("Integrated graphics handle casual gaming and light graphic workflows")
            if "college" in uses or "battery" in uses:
                bat = product.get("battery_spec", "")
                if "Apple" in product.get("brand", "") or "Wh" in bat:
                    reasons.append(f"Solid endurance with {bat} for campus study and library sessions")

        elif category == "Smartphones":
            cam = str(product.get("camera_spec", ""))
            if "camera" in uses or "OIS" in cam:
                reasons.append(f"Advanced optical image stabilization ({cam}) ensures crisp photos and stable video")
            if "gaming" in uses:
                reasons.append(f"High-tier {proc} chipset delivers consistent high framerate mobile gaming")
            if "battery" in uses:
                bat = str(product.get("battery_spec", ""))
                reasons.append(f"High capacity {bat} easily powers through heavy full-day usage")

        elif category == "Headphones":
            if "anc_audio" in uses or "ANC" in highlights:
                reasons.append("Strong Active Noise Cancellation blocks ambient distractions in noisy environments")
            reasons.append(f"Long-lasting battery ({product.get('battery_spec', '')}) for uninterrupted listening")

        # Fallback to highlights if specific reasons are few
        if len(reasons) < 2 and highlights:
            reasons.append(highlights)

        # Brand preference reason
        pref_brand = user_req.get("preferred_brand")
        if pref_brand and pref_brand.lower() == str(product.get("brand", "")).lower():
            reasons.append(f"Matches your preferred brand choice: {pref_brand}")

        return reasons[:4]

    @staticmethod
    def generate_tradeoffs(product: Dict[str, Any], user_req: Dict[str, Any]) -> List[str]:
        """Generates realistic trade-offs based on physical and technical specs."""
        tradeoffs = []
        category = product.get("category", "")
        uses = user_req.get("use_cases", [])
        gpu = str(product.get("gpu", ""))
        ram = int(product.get("ram_gb", 0))
        storage = int(product.get("storage_gb", 0))
        proc = str(product.get("processor", ""))

        if category == "Laptops":
            if "RTX" in gpu:
                tradeoffs.append("Dedicated gaming GPU results in higher power draw and heavier charger adapter")
                tradeoffs.append("Chassis is slightly heavier (approx 2.2 - 2.4 kg) than ultraportables")
            elif "Iris" in gpu or "UHD" in gpu:
                if "gaming" in uses or "machine_learning" in uses:
                    tradeoffs.append("Lacks dedicated NVIDIA GPU; unsuitable for heavy AAA gaming or CUDA deep learning")
            if ram == 8:
                tradeoffs.append("8GB RAM is limited for extreme multitasking; consider upgrading to 16GB later")
            if storage <= 256:
                tradeoffs.append("256GB SSD fills up quickly with large datasets or modern games")

        elif category == "Smartphones":
            if "Apple" in product.get("brand", ""):
                tradeoffs.append("No expandable MicroSD storage and charging adapter sold separately")
            if product.get("price", 0) < 25000:
                tradeoffs.append("Plastic frame build rather than metal or premium glass")
            if "Pixel" in str(product.get("name", "")):
                tradeoffs.append("Charging speed (18W-30W) is slower than competitor 67W-100W flash chargers")

        elif category == "Headphones":
            if product.get("price", 0) < 5000:
                tradeoffs.append("Plastic build and microphone clarity in windy outdoor conditions is basic")

        if not tradeoffs:
            tradeoffs.append("Premium pricing compared to baseline entry-level alternatives")

        return tradeoffs[:3]
