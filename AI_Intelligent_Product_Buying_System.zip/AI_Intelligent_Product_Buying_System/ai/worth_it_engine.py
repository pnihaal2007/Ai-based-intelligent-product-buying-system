"""Worth-It Evaluation Engine.
Analyzes whether a specific considered product is actually worth buying for a user's stated budget
and requirements, and automatically provides alternatives when superior options exist.
"""
import sqlite3
from typing import Dict, Any, List, Optional
from pathlib import Path
from ai.recommendation_engine import RecommendationEngine
from ai.alternative_finder import AlternativeFinder
from ai.explanation_engine import ExplanationEngine

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "database" / "database.db"

class WorthItEngine:
    """Evaluates product suitability and value for a specific user profile."""

    def __init__(self, db_path=DB_PATH):
        self.db_path = db_path
        self.rec_engine = RecommendationEngine(db_path)
        self.alt_finder = AlternativeFinder(db_path)

    def evaluate_product(self, product: Dict[str, Any], user_req: Dict[str, Any]) -> Dict[str, Any]:
        """Conducts complete worth-it evaluation for a considered product."""
        price = float(product.get("price", 0))
        budget = float(user_req.get("budget", price))
        category = product.get("category", "")
        uses = user_req.get("use_cases", [])

        # Compute multi-factor scores
        perf_score = self.rec_engine.calculate_performance_score(product, uses)
        val_score = self.rec_engine.calculate_value_score(perf_score, price, product.get("rating", 4.0), category)
        pref_score = self.rec_engine.calculate_user_preference_score(product, user_req)
        match_score = self.rec_engine.calculate_match_score(product, user_req, perf_score, val_score, pref_score)

        # Budget analysis
        price_diff = budget - price
        is_over_budget = price > budget

        # Check for better alternatives
        alternatives = self.alt_finder.find_better_alternatives(product, user_req, limit=3)
        has_substantially_better_alts = any(
            (alt["ai_match_score"] > match_score + 8.0) or
            (match_score < 80.0 and alt["ai_match_score"] > match_score + 4.0)
            for alt in alternatives
        )

        # Determine Assessment Verdict
        if is_over_budget:
            verdict = "BETTER ALTERNATIVES AVAILABLE"
            verdict_badge = "danger"
            summary_statement = f"This product costs ₹{abs(price_diff):,.0f} more than your stated ₹{budget:,.0f} budget. Multiple alternatives provide equal or better satisfaction within your financial limit."
        elif match_score >= 84.0 and val_score >= 70.0 and not has_substantially_better_alts:
            verdict = "STRONG FIT FOR YOUR REQUIREMENTS"
            verdict_badge = "success"
            summary_statement = "This product matches your requirements exceptionally well, delivers solid performance for your budget, and represents a smart purchase decision."
        elif has_substantially_better_alts or match_score < 72.0:
            verdict = "BETTER ALTERNATIVES AVAILABLE"
            verdict_badge = "warning"
            summary_statement = "While this product is functional, other competitors in this price range deliver stronger specifications, modern components, or better overall value."
        else:
            verdict = "REASONABLE FIT — CONSIDER THESE TRADE-OFFS"
            verdict_badge = "info"
            summary_statement = "This product satisfies your core requirements, but entails specific trade-offs (such as battery, memory or pricing) that you should carefully consider before purchasing."

        reasons = ExplanationEngine.generate_reasons(product, user_req)
        tradeoffs = ExplanationEngine.generate_tradeoffs(product, user_req)

        return {
            "product": product,
            "user_requirements": user_req,
            "budget": budget,
            "price": price,
            "price_diff": price_diff,
            "is_over_budget": is_over_budget,
            "ai_match_score": match_score,
            "performance_score": perf_score,
            "value_score": val_score,
            "preference_score": pref_score,
            "verdict": verdict,
            "verdict_badge": verdict_badge,
            "summary_statement": summary_statement,
            "reasons": reasons,
            "tradeoffs": tradeoffs,
            "better_alternatives": alternatives
        }
