"""Natural-Language Query Parser for AI shopping assistance.
Extracts category, budget, preferred brand, use cases, feature priorities, and specific product models
using comprehensive local pattern matching and rule-based NLP without external API dependencies.
"""
import re
from typing import Dict, Any, List, Optional

class QueryParser:
    """Parses natural language shopping queries into structured user requirement representations."""

    CATEGORIES = {
        "Laptops": ["laptop", "laptops", "notebook", "macbook", "ultrabook", "chromebook", "computer", "pc"],
        "Smartphones": ["phone", "phones", "smartphone", "smartphones", "mobile", "mobiles", "iphone", "galaxy", "handset"],
        "Headphones": ["headphone", "headphones", "earphone", "earphones", "earbud", "earbuds", "tws", "airpods", "neckband", "headset"],
        "Smartwatches": ["watch", "watches", "smartwatch", "smartwatches", "fitness tracker", "band"],
        "Televisions": ["tv", "tvs", "television", "televisions", "smart tv", "led tv", "oled", "qled", "screen"],
        "Tablets": ["tablet", "tablets", "ipad", "tab", "tabs"]
    }

    BRANDS = [
        "Apple", "Samsung", "HP", "Lenovo", "ASUS", "Dell", "Acer", "MSI",
        "OnePlus", "Xiaomi", "Redmi", "Poco", "Realme", "Motorola", "Google",
        "Vivo", "iQOO", "Nothing", "Sony", "boAt", "JBL", "Sennheiser",
        "Noise", "Amazfit", "Titan", "Fastrack", "LG", "TCL", "Vu"
    ]

    USE_CASES = {
        "programming": ["coding", "programming", "developer", "software", "code", "python", "java", "web dev", "engineering", "btech", "cs"],
        "gaming": ["gaming", "game", "gamer", "games", "aaa", "fps", "rtx", "gtx", "esports", "steam", "playstation"],
        "machine_learning": ["ml", "machine learning", "deep learning", "ai", "artificial intelligence", "data science", "neural", "cuda"],
        "camera": ["camera", "photography", "photos", "video", "videography", "selfie", "vlog", "vlogging", "portrait"],
        "battery": ["battery", "battery life", "backup", "long battery", "all day", "fast charging", "mah"],
        "college": ["college", "student", "study", "university", "school", "assignments", "note taking", "lightweight", "portable"],
        "office": ["office", "work", "business", "multitasking", "excel", "presentation", "zoom", "teams", "calling"],
        "anc_audio": ["anc", "noise cancelling", "noise cancellation", "sound quality", "bass", "music", "audiophile", "calling"],
        "cinema": ["cinema", "movies", "4k", "hdr", "dolby", "home theater", "ott", "netflix", "soundbar"]
    }

    def parse(self, query_text: str) -> Dict[str, Any]:
        """Parses raw user query into requirement dictionary."""
        query_lower = query_text.lower().strip()

        # 1. Detect Category
        detected_category = None
        for cat, synonyms in self.CATEGORIES.items():
            for syn in synonyms:
                if re.search(r'\b' + re.escape(syn) + r'\b', query_lower):
                    detected_category = cat
                    break
            if detected_category:
                break

        # 2. Detect Budget in INR (e.g. ₹80,000, 80000, 80k, under 40k, below 5,000, max 70000)
        detected_budget = None
        budget_patterns = [
            r'(?:under|below|budget|within|max|around|upto|up to|worth|price)\s*(?:of|is|:)?\s*(?:₹|rs\.?|inr)?\s*([0-9]+(?:,[0-9]+)*|\d+)\s*(k|thousand|l|lakh)?',
            r'(?:₹|rs\.?|inr)\s*([0-9]+(?:,[0-9]+)*|\d+)\s*(k|thousand|l|lakh)?',
            r'\b([0-9]{1,3}(?:,[0-9]{3})+)\b',
            r'\b([0-9]+)\s*(k|thousand|l|lakh)\b',
            r'\b(3[0-9]{4}|4[0-9]{4}|5[0-9]{4}|6[0-9]{4}|7[0-9]{4}|8[0-9]{4}|9[0-9]{4}|1[0-9]{5}|2[0-9]{5})\b'
        ]

        for pat in budget_patterns:
            matches = re.finditer(pat, query_lower)
            for m in matches:
                val_str = m.group(1).replace(',', '')
                try:
                    num = float(val_str)
                    multiplier = m.group(2) if len(m.groups()) >= 2 else None
                    if multiplier in ['k', 'thousand']:
                        num *= 1000
                    elif multiplier in ['l', 'lakh']:
                        num *= 100000
                    
                    if 500 <= num <= 500000:
                        detected_budget = num
                        break
                except ValueError:
                    continue
            if detected_budget:
                break

        # 3. Detect Preferred Brand
        detected_brand = None
        for b in self.BRANDS:
            if re.search(r'\b' + re.escape(b.lower()) + r'\b', query_lower):
                detected_brand = b
                break

        # 4. Detect Use Cases & User Intent
        detected_uses = []
        for use, keywords in self.USE_CASES.items():
            for kw in keywords:
                if re.search(r'\b' + re.escape(kw) + r'\b', query_lower):
                    detected_uses.append(use)
                    break

        # If category wasn't explicitly mentioned, infer from brand or use case
        if not detected_category:
            if "camera" in detected_uses or "selfie" in query_lower:
                detected_category = "Smartphones"
            elif any(u in ["gaming", "programming", "machine_learning"] for u in detected_uses):
                detected_category = "Laptops"
            elif "anc_audio" in detected_uses:
                detected_category = "Headphones"
            elif "cinema" in detected_uses:
                detected_category = "Televisions"
            else:
                detected_category = "Laptops"  # default fallback category

        # 5. Detect Feature Priorities
        priority_features = []
        if "gaming" in detected_uses or "machine_learning" in detected_uses or "gpu" in query_lower:
            priority_features.append("High Performance GPU")
        if "programming" in detected_uses or "ram" in query_lower or "multitasking" in detected_uses:
            priority_features.append("16GB+ RAM & Fast CPU")
        if "battery" in detected_uses or "long battery" in query_lower:
            priority_features.append("Long Battery Life")
        if "camera" in detected_uses or "photo" in query_lower or "video" in query_lower:
            priority_features.append("High-Resolution OIS Camera")
        if "anc_audio" in detected_uses or "anc" in query_lower:
            priority_features.append("Active Noise Cancellation (ANC)")
        if "oled" in query_lower or "amoled" in query_lower or "120hz" in query_lower:
            priority_features.append("Vibrant 120Hz / AMOLED Display")

        # 6. Detect Query Intent / Mode
        query_type = "recommendation"
        if any(w in query_lower for w in ["worth", "is it worth", "should i buy", "worth buying", "good to buy"]):
            query_type = "worth_it"
        elif any(w in query_lower for w in ["compare", "vs", "versus", "difference between"]):
            query_type = "comparison"
        elif any(w in query_lower for w in ["where to buy", "cheapest store", "best price on"]):
            query_type = "store_comparison"

        # 7. Extract Potential Specific Product Mention
        specific_product = None
        for b in self.BRANDS:
            if b.lower() in query_lower:
                # Extract words following brand
                idx = query_lower.find(b.lower())
                sub = query_text[idx:idx+45].strip()
                # Clean off trailing budget words
                sub = re.sub(r'(?i)\s+(under|below|for|is|worth|at|with|my).*', '', sub).strip()
                if len(sub) > len(b):
                    specific_product = sub
                    break

        return {
            "raw_query": query_text,
            "category": detected_category,
            "budget": detected_budget or 80000.0,
            "preferred_brand": detected_brand,
            "use_cases": detected_uses,
            "priority_features": priority_features,
            "query_type": query_type,
            "specific_product": specific_product,
            "summary": self._format_summary(detected_category, detected_budget, detected_uses, detected_brand)
        }

    def _format_summary(self, category: str, budget: Optional[float], uses: List[str], brand: Optional[str]) -> str:
        parts = []
        if category:
            parts.append(f"Category: {category}")
        if budget:
            parts.append(f"Budget: ₹{budget:,.0f}")
        if brand:
            parts.append(f"Brand: {brand}")
        if uses:
            uses_str = ", ".join(u.replace('_', ' ').title() for u in uses)
            parts.append(f"Use: {uses_str}")
        return " | ".join(parts) if parts else "General Search"
