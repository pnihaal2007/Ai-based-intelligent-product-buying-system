"""Automatic Alternative Product Finder.
Identifies and presents 2 to 3 superior products within the user's budget when the considered product
is poor value, under-specced, or overpriced for their needs.
"""
import sqlite3
from typing import List, Dict, Any, Optional
from pathlib import Path
from ai.recommendation_engine import RecommendationEngine

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "database" / "database.db"

class AlternativeFinder:
    """Finds better alternatives within user budget and generates comparative advantage metrics."""

    def __init__(self, db_path=DB_PATH):
        self.db_path = db_path
        self.rec_engine = RecommendationEngine(db_path)

    def find_better_alternatives(self, target_product: Dict[str, Any], user_req: Dict[str, Any], limit: int = 3) -> List[Dict[str, Any]]:
        """Searches for products in the same category within budget that yield higher AI Match or better Value."""
        category = target_product.get("category", "")
        target_id = target_product.get("product_id")
        target_price = float(target_product.get("price", 0))
        budget = user_req.get("budget", target_price)

        # Get candidates via recommendation engine
        all_recs = self.rec_engine.recommend(user_req, limit=12)

        # Calculate target product's own scores
        t_perf = self.rec_engine.calculate_performance_score(target_product, user_req.get("use_cases", []))
        t_val = self.rec_engine.calculate_value_score(t_perf, target_price, target_product.get("rating", 4.0), category)
        t_pref = self.rec_engine.calculate_user_preference_score(target_product, user_req)
        t_match = self.rec_engine.calculate_match_score(target_product, user_req, t_perf, t_val, t_pref)

        better_alternatives = []
        for cand in all_recs:
            if cand["product_id"] == target_id:
                continue

            cand_price = float(cand.get("price", 0))
            cand_match = float(cand.get("ai_match_score", 0))
            cand_val = float(cand.get("value_score", 0))

            # Must be strictly within user budget (or cheaper than target product)
            # AND have either higher match score, higher value score, or save significant money
            is_superior = (
                (cand_match > t_match + 2.0 and cand_price <= budget) or
                (cand_price < target_price and cand_match >= t_match - 2.0) or
                (cand_val > t_val + 5.0 and cand_price <= budget)
            )

            if is_superior:
                # Calculate comparison deltas
                price_delta = target_price - cand_price
                match_delta = cand_match - t_match
                
                # Highlight tangible hardware improvements
                improvements = []
                if price_delta > 1000:
                    improvements.append(f"₹{price_delta:,.0f} cheaper than your considered model")
                elif price_delta < 0:
                    improvements.append(f"₹{abs(price_delta):,.0f} more, but within your ₹{budget:,.0f} budget")

                if cand.get("ram_gb", 0) > target_product.get("ram_gb", 0):
                    improvements.append(f"Higher RAM: {cand['ram_gb']}GB vs {target_product.get('ram_gb')}GB")

                if cand.get("storage_gb", 0) > target_product.get("storage_gb", 0):
                    improvements.append(f"More Storage: {cand['storage_gb']}GB vs {target_product.get('storage_gb')}GB")

                c_gpu = str(cand.get("gpu", ""))
                t_gpu = str(target_product.get("gpu", ""))
                if "rtx 40" in c_gpu.lower() and "rtx 40" not in t_gpu.lower():
                    improvements.append("Significantly more powerful modern GPU (RTX 40-series)")

                if cand.get("rating", 0) > target_product.get("rating", 0):
                    improvements.append(f"Higher verified user rating ({cand.get('rating')} vs {target_product.get('rating')})")

                # Honest trade-off of the alternative
                alt_tradeoff = ""
                if cand_price > target_price:
                    alt_tradeoff = f"Costs ₹{abs(price_delta):,.0f} more than {target_product.get('name')}"
                elif target_product.get("display_size", 0) > cand.get("display_size", 0):
                    alt_tradeoff = "Slightly more compact screen size"
                else:
                    alt_tradeoff = "Different exterior styling / brand ecosystem"

                cand_entry = dict(cand)
                cand_entry.update({
                    "price_delta": price_delta,
                    "match_delta": round(match_delta, 1),
                    "improvements": improvements[:3],
                    "alternative_tradeoff": alt_tradeoff
                })
                better_alternatives.append(cand_entry)

        # Sort by match score and price savings
        better_alternatives.sort(key=lambda x: (x["ai_match_score"], x["price_delta"]), reverse=True)
        return better_alternatives[:limit]
