"""Store and Platform Buying Option Scoring Engine.
Computes effective prices, normalizes multi-factor store purchasing attributes,
and transparently ranks retailers without hiding competing options.
"""
from typing import List, Dict, Any
from config import Config

class PlatformScoringEngine:
    """Evaluates multi-platform listings and assigns transparent buying option scores."""

    def __init__(self, weights=None):
        self.weights = weights or Config.SCORING_WEIGHTS

    @staticmethod
    def calculate_effective_price(listing: Dict[str, Any]) -> float:
        """Calculates Effective Price:
        Effective Price = Listed Price + Mandatory Delivery Charges - Guaranteed Coupons.
        Does NOT subtract conditional bank offers.
        """
        listed_price = float(listing.get("listed_price", 0))
        delivery = float(listing.get("delivery_charge", 0))
        coupon = float(listing.get("coupon_discount", 0))
        return round(max(0, listed_price + delivery - coupon), 2)

    def score_buying_options(self, listings: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Scores all listings for a product and returns ranked results with full explainability."""
        if not listings:
            return []

        # Find min effective price across available listings to calibrate price component
        valid_prices = [self.calculate_effective_price(l) for l in listings if self.calculate_effective_price(l) > 0]
        min_price = min(valid_prices) if valid_prices else 1.0

        scored_listings = []
        for l in listings:
            eff_price = self.calculate_effective_price(l)
            reasons = []
            notes = []

            # 1. Price / Value Component (40%)
            # If price equals min_price, 100 pts. If higher, proportional drop.
            if eff_price > 0:
                price_ratio = min_price / eff_price
                price_comp = min(100.0, max(20.0, price_ratio * 100.0))
            else:
                price_comp = 50.0

            if abs(eff_price - min_price) < 50:
                reasons.append("Lowest observed effective price in market")
            elif eff_price <= min_price * 1.02:
                reasons.append("Within 2% of the lowest market price")
            else:
                diff = eff_price - min_price
                notes.append(f"₹{diff:,.0f} higher than the cheapest available platform")

            # 2. Seller / Source Reliability (20%)
            plat_type = l.get("platform_type", "Marketplace")
            seller_rating = float(l.get("seller_rating") or 4.2)
            if plat_type == "Official Brand Store":
                seller_comp = 98.0
                reasons.append("Direct official manufacturer store (100% authenticity guarantee)")
            else:
                seller_comp = min(100.0, (seller_rating / 5.0) * 100.0)
                if seller_rating >= 4.5:
                    reasons.append(f"Highly-rated seller ({seller_rating} / 5.0)")

            # 3. Warranty (15%)
            warranty_text = str(l.get("warranty", ""))
            if "2 Year" in warranty_text or "24 Months" in warranty_text:
                warranty_comp = 95.0
                reasons.append("Extended 2-year warranty included")
            elif "Official" in warranty_text or "1 Year" in warranty_text or "12 Months" in warranty_text:
                warranty_comp = 85.0
                reasons.append("Official manufacturer warranty")
            elif not warranty_text or warranty_text == "None":
                warranty_comp = 50.0
                notes.append("Warranty details not clearly specified by seller")
            else:
                warranty_comp = 75.0

            # 4. Offers & Coupons (10%)
            coupon = float(l.get("coupon_discount", 0))
            bank_offer = str(l.get("bank_offer_text", "")).strip()
            offers_comp = 60.0
            if coupon > 0:
                offers_comp += 25.0
                reasons.append(f"Instant ₹{coupon:,.0f} coupon applied at checkout")
            if bank_offer:
                offers_comp += 15.0
                notes.append(f"Conditional offer: {bank_offer}")

            # 5. Availability (10%)
            avail = str(l.get("availability", "In Stock"))
            if "In Stock" in avail:
                avail_comp = 100.0
                reasons.append("Ready in stock for dispatch")
            elif "Only" in avail:
                avail_comp = 80.0
                notes.append(f"Limited stock: {avail}")
            else:
                avail_comp = 60.0
                notes.append(f"Availability notice: {avail}")

            # 6. Delivery (5%)
            delivery_charge = float(l.get("delivery_charge", 0))
            delivery_info = str(l.get("delivery_info", ""))
            if delivery_charge == 0:
                delivery_comp = 95.0
                reasons.append(f"Free delivery ({delivery_info})")
            else:
                delivery_comp = 50.0
                notes.append(f"₹{delivery_charge:,.0f} mandatory shipping charge")

            # Calculate Weighted Overall Buying Option Score
            total_score = (
                (price_comp * self.weights["price_value"]) +
                (seller_comp * self.weights["seller_reliability"]) +
                (warranty_comp * self.weights["warranty"]) +
                (offers_comp * self.weights["offers"]) +
                (avail_comp * self.weights["availability"]) +
                (delivery_comp * self.weights["delivery"])
            )

            total_score = round(min(99.0, max(30.0, total_score)), 1)

            entry = dict(l)
            entry.update({
                "effective_price": eff_price,
                "buying_score": total_score,
                "reasons": reasons[:3],
                "considerations": notes[:2],
                "is_best_overall": False  # assigned below
            })
            scored_listings.append(entry)

        # Sort by buying_score descending
        scored_listings.sort(key=lambda x: (x["buying_score"], -x["effective_price"]), reverse=True)

        if scored_listings:
            scored_listings[0]["is_best_overall"] = True

        return scored_listings
