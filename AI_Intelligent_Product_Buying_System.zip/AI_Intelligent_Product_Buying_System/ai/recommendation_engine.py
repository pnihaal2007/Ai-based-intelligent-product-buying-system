"""AI Product Recommendation Engine with dynamic multi-criteria weighted scoring,
budget awareness, and explainable specification evaluation.
"""
import sqlite3
from typing import List, Dict, Any, Optional
from pathlib import Path
from ai.explanation_engine import ExplanationEngine

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "database" / "database.db"

class RecommendationEngine:
    """Computes AI Match, Performance, Value-for-Money, and Preference scores."""

    def __init__(self, db_path=DB_PATH):
        self.db_path = db_path

    def get_connection(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def calculate_performance_score(self, product: Dict[str, Any], use_cases: List[str]) -> float:
        """Calculates 0-100 hardware performance capability based on specifications."""
        category = product.get("category", "")
        proc = str(product.get("processor", "")).lower()
        gpu = str(product.get("gpu", "")).lower()
        ram = int(product.get("ram_gb", 0))
        storage = int(product.get("storage_gb", 0))
        price = float(product.get("price", 0))

        if category == "Laptops":
            # CPU tier (max 30 pts)
            cpu_pts = 15
            if any(k in proc for k in ["core i9", "ryzen 9", "m3 max", "m3 pro", "13700hx", "7840hs"]):
                cpu_pts = 30
            elif any(k in proc for k in ["core i7", "ryzen 7", "m2", "m3", "13650hx", "7735hs", "ultra 7"]):
                cpu_pts = 26
            elif any(k in proc for k in ["core i5", "ryzen 5", "12450h", "13420h"]):
                cpu_pts = 20
            elif any(k in proc for k in ["core i3", "ryzen 3"]):
                cpu_pts = 12

            # GPU tier (max 35 pts)
            gpu_pts = 10
            if "rtx 4060" in gpu or "rtx 4070" in gpu:
                gpu_pts = 35
            elif "rtx 4050" in gpu:
                gpu_pts = 30
            elif "rtx 3050" in gpu:
                gpu_pts = 24
            elif "rtx 2050" in gpu:
                gpu_pts = 18
            elif "apple" in gpu or "arc" in gpu:
                gpu_pts = 22
            elif "iris" in gpu or "radeon" in gpu:
                gpu_pts = 14

            # RAM & Storage (max 25 pts)
            ram_pts = 20 if ram >= 16 else (12 if ram == 8 else 6)
            storage_pts = 10 if storage >= 1024 else (8 if storage >= 512 else 4)

            # Battery / Display baseline (max 10 pts)
            disp_pts = 8

            score = cpu_pts + gpu_pts + ram_pts + storage_pts + disp_pts
            return min(100.0, max(20.0, float(score)))

        elif category == "Smartphones":
            # SoC (max 40 pts)
            soc_pts = 20
            if any(k in proc for k in ["gen 3", "a17 pro", "a16", "dimensity 9300", "gen 2", "exynos 2400"]):
                soc_pts = 40
            elif any(k in proc for k in ["a15", "dimensity 8300", "tensor g3", "7s gen 2"]):
                soc_pts = 32
            elif any(k in proc for k in ["snapdragon 695", "dimensity 6100", "exynos 1330", "g99"]):
                soc_pts = 20

            # RAM / Storage (max 25 pts)
            ram_pts = 15 if ram >= 12 else (12 if ram >= 8 else 8)
            storage_pts = 10 if storage >= 256 else 7

            # Camera / Display (max 35 pts)
            cam = str(product.get("camera_spec", "")).lower()
            cam_pts = 30 if ("ois" in cam and ("telephoto" in cam or "200mp" in cam or "periscope" in cam)) else (24 if "ois" in cam else 15)

            score = soc_pts + ram_pts + storage_pts + cam_pts
            return min(100.0, max(20.0, float(score)))

        else:
            # Baseline estimation from rating & price bracket
            base = 60.0 + min(30.0, (price / 50000.0) * 30.0) + (product.get("rating", 4.0) - 3.5) * 10
            return min(100.0, max(30.0, round(base, 1)))

    def calculate_value_score(self, performance_score: float, price: float, rating: float, category: str) -> float:
        """Evaluates tangible specifications and user satisfaction relative to retail price."""
        # Baseline category expected prices
        cat_medians = {
            "Laptops": 70000.0,
            "Smartphones": 35000.0,
            "Headphones": 8000.0,
            "Smartwatches": 12000.0,
            "Televisions": 45000.0,
            "Tablets": 30000.0
        }
        ref_price = cat_medians.get(category, 50000.0)
        price_factor = (ref_price / max(1000.0, price)) ** 0.35
        rating_boost = (rating / 5.0) * 20.0

        raw_val = (performance_score * 0.75 * price_factor) + rating_boost
        return round(min(98.0, max(35.0, raw_val)), 1)

    def calculate_user_preference_score(self, product: Dict[str, Any], user_req: Dict[str, Any]) -> float:
        """Measures how well the product addresses the user's specific use cases and feature requests."""
        uses = user_req.get("use_cases", [])
        pref_brand = user_req.get("preferred_brand")
        gpu = str(product.get("gpu", "")).lower()
        ram = int(product.get("ram_gb", 0))
        proc = str(product.get("processor", "")).lower()
        brand = str(product.get("brand", "")).lower()
        cat = product.get("category", "")

        score = 65.0  # base compatibility

        # Brand preference
        if pref_brand:
            if pref_brand.lower() == brand:
                score += 15.0
            else:
                score -= 8.0

        # Laptop uses
        if cat == "Laptops":
            if "programming" in uses:
                if ram >= 16: score += 12.0
                elif ram == 8: score -= 5.0
                if "core i7" in proc or "ryzen 7" in proc or "m2" in proc or "m3" in proc: score += 8.0

            if "gaming" in uses:
                if "rtx 40" in gpu: score += 15.0
                elif "rtx 30" in gpu: score += 10.0
                elif "rtx 20" in gpu: score += 4.0
                else: score -= 20.0  # severely penalize non-gaming GPU if gaming requested

            if "machine_learning" in uses:
                if "rtx" in gpu: score += 15.0  # CUDA support
                elif "apple" in gpu: score += 8.0
                else: score -= 18.0

            if "college" in uses or "battery" in uses:
                if "apple" in brand: score += 14.0
                elif product.get("display_size", 15.6) <= 14.5: score += 6.0

        # Smartphone uses
        elif cat == "Smartphones":
            cam = str(product.get("camera_spec", "")).lower()
            if "camera" in uses:
                if "periscope" in cam or "telephoto" in cam or "200mp" in cam: score += 18.0
                elif "ois" in cam: score += 12.0
                else: score -= 10.0

            if "gaming" in uses:
                if "gen 3" in proc or "gen 2" in proc or "dimensity 8300" in proc: score += 16.0
                elif "695" in proc: score -= 10.0

            if "battery" in uses:
                bat = str(product.get("battery_spec", ""))
                if "6000mah" in bat or "5500mah" in bat: score += 12.0

        # Headphones uses
        elif cat == "Headphones":
            if "anc_audio" in uses:
                if "sony" in brand or "apple" in brand or "anc" in str(product.get("highlights", "")).lower():
                    score += 15.0

        return min(100.0, max(20.0, round(score, 1)))

    def calculate_match_score(self, product: Dict[str, Any], user_req: Dict[str, Any],
                              perf_score: float, val_score: float, pref_score: float) -> float:
        """Synthesizes all factors into the definitive AI Match %."""
        budget = user_req.get("budget", 80000.0)
        price = float(product.get("price", 0))

        # Budget alignment factor
        if price <= budget:
            # Within budget
            budget_ratio = price / max(1.0, budget)
            if 0.70 <= budget_ratio <= 1.0:
                # Optimal spending zone
                budget_score = 95.0
            elif budget_ratio < 0.70:
                # Significant savings, high value reward
                budget_score = 90.0 + (budget_ratio * 5.0)
            else:
                budget_score = 92.0
        else:
            # Over budget penalty (proportional to excess)
            over_pct = (price - budget) / budget
            budget_score = max(20.0, 85.0 - (over_pct * 120.0))

        # Composite AI Match Score:
        # User Preference (40%), Budget Compatibility (25%), Performance (20%), Value (15%)
        ai_match = (pref_score * 0.40) + (budget_score * 0.25) + (perf_score * 0.20) + (val_score * 0.15)
        return min(98.0, max(25.0, round(ai_match, 1)))

    def recommend(self, user_req: Dict[str, Any], limit: int = 6) -> List[Dict[str, Any]]:
        """Finds, scores, and ranks candidate products according to user priorities."""
        category = user_req.get("category", "Laptops")
        budget = user_req.get("budget", 80000.0)
        pref_brand = user_req.get("preferred_brand")

        conn = self.get_connection()
        cursor = conn.cursor()

        # Query products in category. Allow products up to 15% above budget to test trade-offs,
        # but filter out absurdly out-of-budget items.
        max_allowed_price = budget * 1.20
        sql = "SELECT * FROM products WHERE category = ? AND price <= ?;"
        cursor.execute(sql, (category, max_allowed_price))
        rows = [dict(r) for r in cursor.fetchall()]

        # If zero found (e.g. extremely low budget), broaden price window to show nearest options
        if not rows:
            cursor.execute("SELECT * FROM products WHERE category = ? ORDER BY price ASC LIMIT 5;", (category,))
            rows = [dict(r) for r in cursor.fetchall()]

        conn.close()

        scored_products = []
        for p in rows:
            perf_score = self.calculate_performance_score(p, user_req.get("use_cases", []))
            val_score = self.calculate_value_score(perf_score, p["price"], p["rating"], category)
            pref_score = self.calculate_user_preference_score(p, user_req)
            match_score = self.calculate_match_score(p, user_req, perf_score, val_score, pref_score)

            # Generate explainable reasons & trade-offs
            reasons = ExplanationEngine.generate_reasons(p, user_req)
            tradeoffs = ExplanationEngine.generate_tradeoffs(p, user_req)

            # Budget awareness delta
            remaining = budget - p["price"]
            budget_verdict = ""
            if remaining >= 5000:
                budget_verdict = f"Save ₹{remaining:,.0f} under budget without sacrificing performance"
            elif remaining >= 0:
                budget_verdict = f"Comfortably within budget (₹{remaining:,.0f} left)"
            else:
                budget_verdict = f"₹{abs(remaining):,.0f} above stated budget"

            item = dict(p)
            item.update({
                "ai_match_score": match_score,
                "performance_score": perf_score,
                "value_score": val_score,
                "preference_score": pref_score,
                "reasons": reasons,
                "tradeoffs": tradeoffs,
                "budget_remaining": remaining,
                "budget_verdict": budget_verdict
            })
            scored_products.append(item)

        # Sort products by AI Match Score descending.
        # If match scores are nearly identical (within 2%), prefer the more budget-friendly / higher value option!
        scored_products.sort(
            key=lambda x: (x["ai_match_score"], x["value_score"], -x["price"]),
            reverse=True
        )

        return scored_products[:limit]
