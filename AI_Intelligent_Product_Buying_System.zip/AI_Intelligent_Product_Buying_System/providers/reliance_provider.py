"""Reliance Digital Retailer Provider implementation."""
from typing import List, Dict, Any, Optional
from config import Config
from providers.base_provider import BaseProvider
from providers.demo_provider import DemoProvider

class RelianceProvider(BaseProvider):
    """Adapter for Reliance Digital retailer data."""

    def __init__(self, mode=Config.APP_MODE):
        is_live = (mode == "LIVE") and bool(Config.RELIANCE_API_KEY)
        status_mode = "LIVE" if is_live else "DEMO"
        super().__init__("reliance", "Reliance Digital", "Retailer", mode=status_mode)
        self.is_live = is_live
        self.demo_fallback = DemoProvider("reliance", "Reliance Digital", "Retailer")

    def search_listings(self, query: str, category: Optional[str] = None, max_results: int = 10) -> List[Dict[str, Any]]:
        return self.demo_fallback.search_listings(query, category, max_results)

    def get_product_listings(self, product_id: int) -> List[Dict[str, Any]]:
        return self.demo_fallback.get_product_listings(product_id)
