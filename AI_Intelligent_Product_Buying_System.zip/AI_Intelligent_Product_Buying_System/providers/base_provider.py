"""Abstract Base Provider definition for modular retail and marketplace data integration."""
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional

class BaseProvider(ABC):
    """Abstract base class that all shopping platform providers must implement."""

    def __init__(self, platform_id: str, platform_name: str, platform_type: str, mode: str = "DEMO"):
        self.platform_id = platform_id
        self.platform_name = platform_name
        self.platform_type = platform_type
        self.mode = mode.upper()

    @abstractmethod
    def search_listings(self, query: str, category: Optional[str] = None, max_results: int = 10) -> List[Dict[str, Any]]:
        """Searches for listings matching a query string."""
        pass

    @abstractmethod
    def get_product_listings(self, product_id: int) -> List[Dict[str, Any]]:
        """Retrieves all listings for a specific product ID."""
        pass

    def normalize_listing(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """Normalizes external or database listing data into a standard schema."""
        listed_price = float(raw_data.get("listed_price", 0))
        mrp = float(raw_data.get("mrp", listed_price))
        delivery_charge = float(raw_data.get("delivery_charge", 0))
        coupon_discount = float(raw_data.get("coupon_discount", 0))

        # Effective Price = Listed Price + Mandatory Delivery Charges - Guaranteed Coupons
        effective_price = round(listed_price + delivery_charge - coupon_discount, 2)

        return {
            "listing_id": raw_data.get("listing_id"),
            "product_id": raw_data.get("product_id"),
            "platform": self.platform_name,
            "platform_id": self.platform_id,
            "platform_type": self.platform_type,
            "product_name": raw_data.get("listing_title") or raw_data.get("name", ""),
            "brand": raw_data.get("brand", ""),
            "model_number": raw_data.get("model_number", ""),
            "variant": raw_data.get("variant", ""),
            "listed_price": listed_price,
            "mrp": mrp,
            "discount": round(mrp - listed_price, 2) if mrp >= listed_price else 0,
            "coupon_discount": coupon_discount,
            "delivery_charge": delivery_charge,
            "effective_price": effective_price,
            "rating": raw_data.get("seller_rating") or raw_data.get("rating"),
            "review_count": raw_data.get("review_count"),
            "seller": raw_data.get("seller_name", "Authorized Retailer"),
            "availability": raw_data.get("availability", "In Stock"),
            "warranty": raw_data.get("warranty", "Official Brand Warranty"),
            "delivery": raw_data.get("delivery_info", "Standard Delivery"),
            "offer_text": raw_data.get("bank_offer_text", ""),
            "product_url": raw_data.get("product_url", "#"),
            "data_source": self.mode + " DATA",
            "last_updated": raw_data.get("last_updated", "2026-09-30")
        }
