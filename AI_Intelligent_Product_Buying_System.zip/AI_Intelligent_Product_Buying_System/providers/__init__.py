"""Providers registry factory."""
from typing import Dict, List
from providers.base_provider import BaseProvider
from providers.demo_provider import DemoProvider
from providers.amazon_provider import AmazonProvider
from providers.flipkart_provider import FlipkartProvider
from providers.croma_provider import CromaProvider
from providers.reliance_provider import RelianceProvider
from providers.vijay_sales_provider import VijaySalesProvider
from providers.official_brand_provider import OfficialBrandProvider

def get_all_providers() -> List[BaseProvider]:
    """Returns instances of all registered shopping providers."""
    return [
        AmazonProvider(),
        FlipkartProvider(),
        CromaProvider(),
        RelianceProvider(),
        VijaySalesProvider(),
        OfficialBrandProvider()
    ]

def get_provider(platform_id: str) -> BaseProvider:
    """Returns provider instance for a specific platform ID."""
    providers_map = {
        "amazon": AmazonProvider,
        "flipkart": FlipkartProvider,
        "croma": CromaProvider,
        "reliance": RelianceProvider,
        "vijay_sales": VijaySalesProvider,
        "official_store": OfficialBrandProvider
    }
    cls = providers_map.get(platform_id, DemoProvider)
    if cls == DemoProvider:
        return DemoProvider(platform_id, platform_id.title(), "Retailer")
    return cls()
