"""Official Manufacturer Brand Store Provider implementation (Apple, Samsung, HP, Lenovo, etc.)."""
from typing import List, Dict, Any, Optional
from config import Config
from providers.base_provider import BaseProvider
from providers.demo_provider import DemoProvider

class OfficialBrandProvider(BaseProvider):
    """Adapter for official direct-to-consumer brand online stores."""

    def __init__(self, mode=Config.APP_MODE):
        super().__init__("official_store", "Official Brand Store", "Official Brand Store", mode="DEMO")
        self.demo_fallback = DemoProvider("official_store", "Official Brand Store", "Official Brand Store")

    def search_listings(self, query: str, category: Optional[str] = None, max_results: int = 10) -> List[Dict[str, Any]]:
        return self.demo_fallback.search_listings(query, category, max_results)

    def get_product_listings(self, product_id: int) -> List[Dict[str, Any]]:
        return self.demo_fallback.get_product_listings(product_id)
