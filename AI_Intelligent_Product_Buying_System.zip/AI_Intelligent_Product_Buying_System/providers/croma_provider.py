"""Croma Electronics Retailer Provider implementation."""
from typing import List, Dict, Any, Optional
from config import Config
from providers.base_provider import BaseProvider
from providers.demo_provider import DemoProvider

class CromaProvider(BaseProvider):
    """Adapter for Croma electronics retailer data."""

    def __init__(self, mode=Config.APP_MODE):
        is_live = (mode == "LIVE") and bool(Config.CROMA_API_KEY)
        status_mode = "LIVE" if is_live else "DEMO"
        super().__init__("croma", "Croma", "Retailer", mode=status_mode)
        self.is_live = is_live
        self.demo_fallback = DemoProvider("croma", "Croma", "Retailer")

    def search_listings(self, query: str, category: Optional[str] = None, max_results: int = 10) -> List[Dict[str, Any]]:
        return self.demo_fallback.search_listings(query, category, max_results)

    def get_product_listings(self, product_id: int) -> List[Dict[str, Any]]:
        return self.demo_fallback.get_product_listings(product_id)
