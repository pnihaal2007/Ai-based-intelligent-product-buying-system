"""Demo Provider implementation that queries the local SQLite operational database."""
import sqlite3
from typing import List, Dict, Any, Optional
from pathlib import Path
from providers.base_provider import BaseProvider

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "database" / "database.db"

class DemoProvider(BaseProvider):
    """Provides realistic synthetic product listings for demo and offline execution."""

    def __init__(self, platform_id: str, platform_name: str, platform_type: str, db_path=DB_PATH):
        super().__init__(platform_id, platform_name, platform_type, mode="DEMO")
        self.db_path = db_path

    def get_connection(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def search_listings(self, query: str, category: Optional[str] = None, max_results: int = 10) -> List[Dict[str, Any]]:
        conn = self.get_connection()
        cursor = conn.cursor()
        sql = """
        SELECT * FROM product_listings
        WHERE platform_id = ? AND (listing_title LIKE ? OR brand LIKE ?)
        LIMIT ?;
        """
        pattern = f"%{query}%"
        cursor.execute(sql, (self.platform_id, pattern, pattern, max_results))
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return [self.normalize_listing(r) for r in rows]

    def get_product_listings(self, product_id: int) -> List[Dict[str, Any]]:
        conn = self.get_connection()
        cursor = conn.cursor()
        sql = """
        SELECT * FROM product_listings
        WHERE platform_id = ? AND product_id = ?;
        """
        cursor.execute(sql, (self.platform_id, product_id))
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return [self.normalize_listing(r) for r in rows]
