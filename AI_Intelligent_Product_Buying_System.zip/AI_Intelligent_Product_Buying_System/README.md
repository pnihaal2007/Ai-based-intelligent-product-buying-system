# AI-Based Intelligent Product Buying Decision System
*(Artificial Intelligence + Data Warehousing and Data Mining — AI + DWDM)*

---

## 1. ABSTRACT

Modern e-commerce consumers face decision paralysis. When purchasing consumer electronics such as laptops, smartphones, headphones, or televisions, buyers are confronted with technical jargon, opaque pricing, and fragmented marketplace listings.

The **AI-Based Intelligent Product Buying Decision System** is a unified decision-support platform designed to answer three essential questions:
1. **Which product should I buy for my requirements and budget?**
2. **Is the product I am considering actually worth buying for my budget and requirements?**
3. **Where should I buy that exact product from for the lowest effective price?**

By integrating **Artificial Intelligence (AI)** (natural-language query parsing, dynamic multi-criteria weighted recommendation scoring, specification-grounded explainability, and K-Means machine learning clustering) with a **Data Warehousing & Data Mining (DWDM)** star-schema architecture (multi-source ETL data pipeline, cross-store price normalization, and exploratory data mining), the system delivers transparent, impartial purchasing guidance.

---

## 2. PROBLEM STATEMENT & OBJECTIVES

### The Problem
* **Fragmented Research:** Consumers spend hours manually searching multiple websites (Amazon, Flipkart, Croma, Reliance Digital, official brand stores) to compare prices and verify whether listings represent identical hardware configurations.
* **Lack of Technical Expertise:** Ordinary buyers struggle to determine if an Intel Core i5 12th Gen is sufficient for data science, or if 8GB RAM will bottleneck their programming workflow.
* **Deceptive Pricing:** Listed headline prices frequently hide delivery charges or promote conditional credit card discounts that not all buyers possess.

### The Solution & Objectives
* Provide an intelligent natural-language assistant where users describe requirements in everyday language.
* Compute transparent recommendation scores (AI Match %, Performance, Value-for-Money, User Preference) tailored to domain-specific use cases.
* Validate budget worthiness with an automated **"Is It Worth It?"** engine that surfaces superior alternatives when an item is overpriced or under-specced.
* Perform cross-platform variant matching to distinguish identical SKUs from different RAM/storage tiers.
* Consolidate catalog data into a Kimball Star-Schema Data Warehouse for executive business intelligence and data mining.

---

## 3. ARCHITECTURE & WORKFLOW

```mermaid
graph TD
    User([User Query / Natural Language Input]) --> NLP[Rule-Based NLP Query Parser]
    NLP --> URM[User Requirement Model: Category, Budget, Use Cases]
    URM --> REC[AI Recommendation Engine: Dynamic Weighted Scoring]
    REC --> WORTH[Worth-It Evaluation Engine]
    
    WORTH -->|Strong Fit| PRODS[Selected Best-Fit Product]
    WORTH -->|Suboptimal / Over budget| ALTS[Automatic Alternative Finder]
    ALTS --> PRODS
    
    PRODS --> PROV[Multi-Platform Retailer Layer]
    PROV --> MATCH[Exact Variant Matching Engine]
    MATCH --> SCORE[Platform Scoring Engine: Effective Price & Reliability]
    SCORE --> DECISION([Final User Decision Support Page])

    PROV -.-> ETL[DWDM ETL Pipeline: Extract, Clean, Transform, Deduplicate]
    ETL --> DWH[(SQLite Star-Schema Data Warehouse)]
    DWH --> MINING[Data Mining Engine]
    MINING --> DASH[Interactive Plotly Analytics Dashboard]
```

---

## 4. SYSTEM COMPONENTS: AI vs DWDM

| Component | Discipline | Description |
|---|---|---|
| **Query Parser** | **AI** | Extracts category, budget in ₹ INR, brand preference, use cases, and feature priorities from freeform text without external API costs. |
| **Recommendation Engine** | **AI** | Computes multi-factor scores (AI Match, Performance, Value, Preference) with adaptive weights based on usage context. |
| **"Is It Worth It?" Engine** | **AI** | Evaluates a product's price against user budget and specifications, producing verdicts (*Strong Fit*, *Reasonable Fit*, *Better Alternatives*). |
| **Alternative Finder** | **AI** | Discovers 2–3 superior products strictly within user budget, detailing money saved and hardware improvements. |
| **Product Matching** | **AI / Data Integration** | Analyzes brand, model code, CPU, GPU, RAM, and storage to calculate matching confidence (98% Exact Match vs 61% Different Variant). |
| **K-Means Clustering** | **Machine Learning** | Groups products into empirical segments (*Budget-Friendly*, *Balanced Value*, *High Performance*, *Flagship*) from normalized attributes. |
| **ETL Pipeline** | **DWDM** | Extracts raw CSVs/APIs, imputes missing values, cleans duplicates, computes effective prices, and loads operational & analytical tables. |
| **Star Schema** | **DWDM** | Houses central fact tables (`fact_product_prices`, `fact_user_searches`) and dimensions (`dim_product`, `dim_platform`, `dim_date`, etc.). |
| **Data Mining Engine** | **DWDM** | Analyzes platform price disparities, category distributions, brand pricing power, and search intent patterns. |
| **BI Analytics Dashboard** | **DWDM** | Visualizes data warehouse insights using interactive Plotly.js charts. |

---

## 5. DATABASE & STAR-SCHEMA DESIGN

### Operational Tables
* `products`: Product catalog attributes (processor, GPU, RAM, storage, display, battery, camera, rating, price, MRP).
* `platforms`: Supported stores (Amazon, Flipkart, Croma, Reliance Digital, Vijay Sales, Official Brand Store).
* `product_listings`: Store-level listings with listed prices, delivery charges, coupons, bank offers, seller rating, and availability.
* `users` & `user_preferences`: Anonymous persona definitions and criteria history.
* `search_history` & `recommendations`: Historical queries, matched products, and score breakdowns.

### DWDM Star Schema
* **Dimension Tables:**
  * `dim_product` (product_key, product_id, name, brand, category, model_number, variant, ram_gb, storage_gb, price_tier)
  * `dim_platform` (platform_key, platform_id, platform_name, platform_type)
  * `dim_date` (date_key, full_date, day, month, month_name, quarter, year)
  * `dim_brand` (brand_key, brand_name)
  * `dim_category` (category_key, category_name)
  * `dim_user` (user_key, user_id, persona_name, preferred_category, budget_range)
* **Fact Tables:**
  * `fact_product_prices` (price_fact_key, product_key, platform_key, date_key, listed_price, effective_price, discount, coupon_discount, delivery_charge, availability_status)
  * `fact_user_searches` (search_fact_key, user_key, category_key, date_key, budget, recommended_product_key)

---

## 6. PROJECT DIRECTORY STRUCTURE

```text
AI_Intelligent_Product_Buying_System/
│
├── app.py                     # Main Flask web application and API controller
├── config.py                  # Central configuration and file path resolution
├── requirements.txt           # Verified Python package dependencies
├── README.md                  # Comprehensive technical documentation
├── .env.example               # Environment variable templates
├── .gitignore                 # Version control exclusions
│
├── ai/                        # Artificial Intelligence modules
│   ├── __init__.py
│   ├── query_parser.py        # Local rule-based NLP query parser
│   ├── recommendation_engine.py # Multi-criteria weighted recommendation engine
│   ├── worth_it_engine.py     # "Is It Worth It?" suitability evaluation
│   ├── alternative_finder.py  # Automatic superior alternative finder
│   ├── product_matching.py    # Cross-platform exact variant matching
│   ├── platform_scoring.py    # Transparent store buying option scoring
│   └── explanation_engine.py  # Specification-grounded explainability generator
│
├── providers/                 # Modular shopping platform adapters
│   ├── __init__.py            # Provider registry factory
│   ├── base_provider.py       # Base class and normalized schema
│   ├── demo_provider.py       # SQLite demo data provider
│   ├── amazon_provider.py     # Amazon India adapter (Live check + Demo fallback)
│   ├── flipkart_provider.py   # Flipkart adapter
│   ├── croma_provider.py      # Croma electronics retailer adapter
│   ├── reliance_provider.py   # Reliance Digital adapter
│   ├── vijay_sales_provider.py# Vijay Sales adapter
│   └── official_brand_provider.py # Direct manufacturer store adapter
│
├── ml/                        # Machine Learning components
│   ├── __init__.py
│   ├── train_models.py        # K-Means clustering & NearestNeighbors training
│   └── models/                # Serialized model artifacts (PKL files)
│
├── dwdm/                      # Data Warehousing & Data Mining modules
│   ├── __init__.py
│   ├── warehouse.py           # Star-schema abstractions and connection helpers
│   ├── etl.py                 # Multi-source Extract, Transform, Load pipeline
│   └── data_mining.py         # Statistical pattern mining and BI aggregations
│
├── database/                  # Database management
│   ├── create_database.py     # Schema definition for operational & warehouse tables
│   └── database.db            # SQLite operational database & data warehouse
│
├── data/                      # Demo datasets in Indian Rupees (₹ INR)
│   ├── products.csv           # 151 realistic consumer electronic products
│   ├── platform_listings.csv  # 700 multi-store marketplace listings
│   ├── users.csv              # Synthetic user personas
│   └── searches.csv           # User search log facts
│
├── templates/                 # Jinja2 responsive HTML5 templates
│   ├── base.html              # Core navigation layout and footer
│   ├── index.html             # Landing page with hero AI search
│   ├── assistant.html         # Interactive NLP assistant and guided form
│   ├── products.html          # Filterable product catalog
│   ├── product_detail.html    # Detailed specifications and store table
│   ├── recommendations.html   # Ranked recommendation cards
│   ├── worth_it.html          # Worth-it analysis and better alternatives
│   ├── compare.html           # Side-by-side product comparison
│   ├── stores.html            # Dedicated cross-platform comparison
│   ├── analytics.html         # Interactive Plotly DWDM analytics dashboard
│   ├── about.html             # Academic project presentation & architecture
│   ├── 404.html               # Not found error state
│   └── 500.html               # Server error state
│
├── static/                    # Frontend assets
│   ├── css/style.css          # Custom modern responsive styling
│   ├── js/main.js             # Client-side dynamic form & comparison scripts
│   └── images/placeholders/   # Clean SVG illustrations for categories
│
├── tests/                     # Automated unit and integration test suite
│   ├── test_query_parser.py
│   ├── test_recommendation.py
│   ├── test_worth_it.py
│   ├── test_alternatives.py
│   ├── test_product_matching.py
│   ├── test_platform_scoring.py
│   ├── test_etl.py
│   └── test_routes.py
│
└── scripts/                   # Management scripts
    ├── generate_demo_data.py  # Generates realistic synthetic datasets
    └── setup_project.py       # One-command complete project setup
```

---

## 7. INSTALLATION & EXECUTION INSTRUCTIONS

### Prerequisites
* Python 3.9, 3.10, 3.11, or 3.12 installed on your system.
* VS Code or any text editor / terminal.

### Quick Start (Windows / VS Code)

1. **Extract the ZIP file:**
   Extract `AI_Intelligent_Product_Buying_System.zip` and open the folder in VS Code.

2. **Open Terminal in VS Code:**
   Press `Ctrl + ~` to open the integrated terminal.

3. **Create and Activate Virtual Environment:**
   ```bash
   python -m venv venv
   venv\Scripts\activate
   ```
   *(On macOS/Linux use: `source venv/bin/activate`)*

4. **Install Required Packages:**
   ```bash
   pip install -r requirements.txt
   ```

5. **One-Command Setup:**
   Run the setup script to generate data, build SQLite tables, execute the ETL pipeline, and train ML models:
   ```bash
   python scripts/setup_project.py
   ```

6. **Start the Flask Server:**
   ```bash
   python app.py
   ```

7. **Open Application in Browser:**
   Navigate to:
   ```text
   http://127.0.0.1:5000
   ```

---

## 8. AUTOMATED TESTING

Execute the comprehensive automated test suite with pytest:

```bash
pytest tests/ -v
```

All 28 tests across query parsing, recommendation logic, worth-it evaluation, alternative generation, product matching, platform scoring, ETL data transformation, and Flask routes execute and pass.

---

## 9. DEMO MODE vs LIVE MODE

* **DEMO MODE (Default):**
  Uses realistic, pre-generated sample data for 151 products and 700 listings across Amazon India, Flipkart, Croma, Reliance Digital, Vijay Sales, and Official Stores. All pages clearly display the **"DEMO DATA"** badge.
* **LIVE MODE:**
  When authorized API keys (`AMAZON_API_KEY`, `FLIPKART_API_KEY`, etc.) are configured in `.env`, the provider adapters connect to live external APIs. In the absence of valid keys, the system gracefully falls back to verified Demo Mode without fabricating data.

---

## 10. ACADEMIC DEMONSTRATION SCENARIOS

When presenting this project to evaluators:

1. **Scenario 1 — General Requirement:**
   * Query: *"I have ₹80,000 and need a laptop for programming, machine learning and moderate gaming."*
   * System extracts Budget=₹80,000, Category=Laptop, Uses=Programming, ML, Gaming.
   * Ranks laptops like Lenovo LOQ and ASUS TUF A15 with RTX GPUs and 16GB RAM.
   * Demonstrates budget remaining: *"₹67,999 recommended | ₹12,001 budget saved"*.
2. **Scenario 2 — Worth-It Evaluation:**
   * Select a laptop and ask if it's worth ₹70,000.
   * System evaluates specs, rating, and value. If suboptimal, it automatically presents 2–3 alternatives within budget with exact spec improvements.
3. **Scenario 3 — Smartphone Camera Query:**
   * Query: *"Best camera phone under ₹40,000"*
   * System extracts Camera priority and applies smartphone camera-specific scoring weights (OIS, Telephoto zoom, night mode).
4. **Scenario 4 — Cross-Store Matching:**
   * Click "Stores" on any product to see the exact model compared across Amazon, Flipkart, Croma, and Official Store with effective prices and transparent buying option scores.
5. **Scenario 5 — DWDM Analytics Dashboard:**
   * Open the "Analytics" tab to inspect Plotly charts generated directly from SQLite Star-Schema fact and dimension tables.
