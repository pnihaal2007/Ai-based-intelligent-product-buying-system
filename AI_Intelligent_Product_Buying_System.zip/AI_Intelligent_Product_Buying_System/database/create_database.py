"""Database schema initialization for operational and DWDM star-schema tables.
Uses SQLite for zero-configuration, robust local execution.
"""
import sqlite3
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "database" / "database.db"

def init_database(db_path=DB_PATH):
    """Creates all operational and DWDM star schema tables."""
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Enable foreign keys
    cursor.execute("PRAGMA foreign_keys = ON;")

    # ==========================================
    # 1. OPERATIONAL TABLES
    # ==========================================
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS products (
        product_id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        brand TEXT NOT NULL,
        category TEXT NOT NULL,
        model_number TEXT NOT NULL,
        variant TEXT,
        price REAL NOT NULL,
        mrp REAL NOT NULL,
        processor TEXT,
        gpu TEXT,
        ram_gb INTEGER DEFAULT 0,
        storage_gb INTEGER DEFAULT 0,
        display_size REAL DEFAULT 0,
        battery_spec TEXT,
        camera_spec TEXT,
        connectivity TEXT,
        rating REAL DEFAULT 0,
        review_count INTEGER DEFAULT 0,
        warranty_months INTEGER DEFAULT 12,
        highlights TEXT,
        intended_use TEXT,
        image_url TEXT
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS platforms (
        platform_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        platform_type TEXT NOT NULL,
        icon TEXT
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS product_listings (
        listing_id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        platform_id TEXT NOT NULL,
        platform_name TEXT NOT NULL,
        platform_type TEXT NOT NULL,
        listing_title TEXT NOT NULL,
        brand TEXT NOT NULL,
        model_number TEXT NOT NULL,
        variant TEXT,
        listed_price REAL NOT NULL,
        mrp REAL NOT NULL,
        discount REAL DEFAULT 0,
        coupon_discount REAL DEFAULT 0,
        delivery_charge REAL DEFAULT 0,
        effective_price REAL NOT NULL,
        bank_offer_text TEXT,
        seller_name TEXT,
        seller_rating REAL DEFAULT 4.0,
        availability TEXT DEFAULT 'In Stock',
        warranty TEXT,
        delivery_info TEXT,
        product_url TEXT,
        data_source TEXT DEFAULT 'DEMO DATA',
        last_updated TEXT,
        FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
        FOREIGN KEY (platform_id) REFERENCES platforms(platform_id)
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        persona_name TEXT,
        preferred_category TEXT,
        budget_range TEXT,
        created_at TEXT
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS user_preferences (
        preference_id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        category TEXT NOT NULL,
        max_budget REAL NOT NULL,
        preferred_brand TEXT,
        primary_use TEXT,
        priority_features TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(user_id)
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS search_history (
        search_id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        query_text TEXT NOT NULL,
        category TEXT,
        budget REAL,
        recommended_product_id INTEGER,
        search_date TEXT,
        FOREIGN KEY (user_id) REFERENCES users(user_id),
        FOREIGN KEY (recommended_product_id) REFERENCES products(product_id)
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS recommendations (
        rec_id INTEGER PRIMARY KEY AUTOINCREMENT,
        search_id INTEGER,
        product_id INTEGER NOT NULL,
        match_score REAL NOT NULL,
        value_score REAL NOT NULL,
        performance_score REAL NOT NULL,
        reasons_json TEXT,
        tradeoffs_json TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (search_id) REFERENCES search_history(search_id),
        FOREIGN KEY (product_id) REFERENCES products(product_id)
    );
    """)

    # ==========================================
    # 2. DWDM STAR-SCHEMA WAREHOUSE TABLES
    # ==========================================
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS dim_product (
        product_key INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER UNIQUE NOT NULL,
        product_name TEXT NOT NULL,
        brand TEXT NOT NULL,
        category TEXT NOT NULL,
        model_number TEXT,
        variant TEXT,
        ram_gb INTEGER,
        storage_gb INTEGER,
        price_tier TEXT
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS dim_platform (
        platform_key INTEGER PRIMARY KEY AUTOINCREMENT,
        platform_id TEXT UNIQUE NOT NULL,
        platform_name TEXT NOT NULL,
        platform_type TEXT NOT NULL
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS dim_date (
        date_key INTEGER PRIMARY KEY,
        full_date TEXT UNIQUE NOT NULL,
        day INTEGER,
        month INTEGER,
        month_name TEXT,
        quarter INTEGER,
        year INTEGER
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS dim_brand (
        brand_key INTEGER PRIMARY KEY AUTOINCREMENT,
        brand_name TEXT UNIQUE NOT NULL
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS dim_category (
        category_key INTEGER PRIMARY KEY AUTOINCREMENT,
        category_name TEXT UNIQUE NOT NULL
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS dim_user (
        user_key INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER UNIQUE NOT NULL,
        persona_name TEXT,
        preferred_category TEXT,
        budget_range TEXT
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS fact_product_prices (
        price_fact_key INTEGER PRIMARY KEY AUTOINCREMENT,
        product_key INTEGER NOT NULL,
        platform_key INTEGER NOT NULL,
        date_key INTEGER NOT NULL,
        listed_price REAL NOT NULL,
        effective_price REAL NOT NULL,
        discount REAL DEFAULT 0,
        coupon_discount REAL DEFAULT 0,
        delivery_charge REAL DEFAULT 0,
        availability_status TEXT,
        FOREIGN KEY (product_key) REFERENCES dim_product(product_key),
        FOREIGN KEY (platform_key) REFERENCES dim_platform(platform_key),
        FOREIGN KEY (date_key) REFERENCES dim_date(date_key)
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS fact_user_searches (
        search_fact_key INTEGER PRIMARY KEY AUTOINCREMENT,
        user_key INTEGER NOT NULL,
        category_key INTEGER NOT NULL,
        date_key INTEGER NOT NULL,
        budget REAL NOT NULL,
        recommended_product_key INTEGER,
        FOREIGN KEY (user_key) REFERENCES dim_user(user_key),
        FOREIGN KEY (category_key) REFERENCES dim_category(category_key),
        FOREIGN KEY (date_key) REFERENCES dim_date(date_key),
        FOREIGN KEY (recommended_product_key) REFERENCES dim_product(product_key)
    );
    """)

    # Useful Indexes for Fast Lookup
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_products_brand ON products(brand);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_products_price ON products(price);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_listings_prod_id ON product_listings(product_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_fact_prices_prod ON fact_product_prices(product_key);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_fact_searches_cat ON fact_user_searches(category_key);")

    conn.commit()
    conn.close()
    print(f"Database schema initialized successfully at {db_path}")

if __name__ == "__main__":
    init_database()
