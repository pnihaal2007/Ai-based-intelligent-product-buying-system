"""Data Warehouse utilities and Star-Schema query abstractions for DWDM module."""
import sqlite3
from pathlib import Path
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "database" / "database.db"

def get_db_connection(db_path=DB_PATH):
    """Establishes an SQLite database connection with row factory."""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

def get_star_schema_summary(db_path=DB_PATH):
    """Returns row counts and metadata across star schema dimensions and fact tables."""
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    
    tables = [
        "dim_product", "dim_platform", "dim_date", "dim_brand",
        "dim_category", "dim_user", "fact_product_prices", "fact_user_searches"
    ]
    summary = {}
    for tbl in tables:
        try:
            cursor.execute(f"SELECT COUNT(*) FROM {tbl};")
            summary[tbl] = cursor.fetchone()[0]
        except Exception:
            summary[tbl] = 0
            
    conn.close()
    return summary

def get_fact_prices_dataframe(db_path=DB_PATH):
    """Joins fact_product_prices with dimensions into a unified analytical DataFrame."""
    conn = sqlite3.connect(db_path)
    query = """
    SELECT 
        f.price_fact_key,
        p.product_id,
        p.product_name,
        p.brand,
        p.category,
        p.price_tier,
        p.ram_gb,
        p.storage_gb,
        pl.platform_id,
        pl.platform_name,
        pl.platform_type,
        d.full_date,
        f.listed_price,
        f.effective_price,
        f.discount,
        f.coupon_discount,
        f.delivery_charge,
        f.availability_status
    FROM fact_product_prices f
    JOIN dim_product p ON f.product_key = p.product_key
    JOIN dim_platform pl ON f.platform_key = pl.platform_key
    JOIN dim_date d ON f.date_key = d.date_key;
    """
    df = pd.read_sql_query(query, conn)
    conn.close()
    return df

def get_fact_searches_dataframe(db_path=DB_PATH):
    """Joins fact_user_searches with dimensions into an analytical DataFrame."""
    conn = sqlite3.connect(db_path)
    query = """
    SELECT 
        s.search_fact_key,
        u.user_id,
        u.persona_name,
        u.budget_range,
        c.category_name,
        d.full_date,
        s.budget,
        p.product_name AS recommended_product,
        p.brand AS recommended_brand
    FROM fact_user_searches s
    JOIN dim_user u ON s.user_key = u.user_key
    JOIN dim_category c ON s.category_key = c.category_key
    JOIN dim_date d ON s.date_key = d.date_key
    LEFT JOIN dim_product p ON s.recommended_product_key = p.product_key;
    """
    df = pd.read_sql_query(query, conn)
    conn.close()
    return df
