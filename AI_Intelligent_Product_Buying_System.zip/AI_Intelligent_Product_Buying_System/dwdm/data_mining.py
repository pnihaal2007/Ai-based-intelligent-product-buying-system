"""Data Mining and Business Intelligence analytics module for DWDM component.
Extracts actionable statistical patterns and aggregations from the SQLite Data Warehouse.
"""
import sqlite3
import pandas as pd
import numpy as np
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "database" / "database.db"

class DataMiningEngine:
    """Analyzes patterns, distributions, price variance and user search behavior."""

    def __init__(self, db_path=DB_PATH):
        self.db_path = db_path

    def get_connection(self):
        return sqlite3.connect(self.db_path)

    def mine_category_distribution(self):
        """Mines product count and percentage per category."""
        conn = self.get_connection()
        query = """
        SELECT category, COUNT(*) as product_count,
               ROUND(AVG(price), 2) as avg_price,
               MIN(price) as min_price,
               MAX(price) as max_price,
               ROUND(AVG(rating), 2) as avg_rating
        FROM products
        GROUP BY category
        ORDER BY product_count DESC;
        """
        df = pd.read_sql_query(query, conn)
        conn.close()
        return df.to_dict(orient="records")

    def mine_brand_market_share(self, top_n=10):
        """Mines brand frequency across the catalog."""
        conn = self.get_connection()
        query = f"""
        SELECT brand, COUNT(*) as product_count,
               ROUND(AVG(price), 2) as avg_price,
               ROUND(AVG(rating), 2) as avg_rating
        FROM products
        GROUP BY brand
        ORDER BY product_count DESC
        LIMIT {top_n};
        """
        df = pd.read_sql_query(query, conn)
        conn.close()
        return df.to_dict(orient="records")

    def mine_platform_price_disparity(self):
        """Analyzes price differences across online platforms and stores."""
        conn = self.get_connection()
        query = """
        SELECT 
            platform_name,
            platform_type,
            COUNT(*) as listing_count,
            ROUND(AVG(listed_price), 2) as avg_listed_price,
            ROUND(AVG(effective_price), 2) as avg_effective_price,
            ROUND(AVG(discount), 2) as avg_discount,
            ROUND(AVG(delivery_charge), 2) as avg_delivery_charge,
            ROUND(AVG(seller_rating), 2) as avg_seller_rating
        FROM product_listings
        GROUP BY platform_name, platform_type
        ORDER BY avg_effective_price ASC;
        """
        df = pd.read_sql_query(query, conn)
        conn.close()
        return df.to_dict(orient="records")

    def mine_search_patterns(self):
        """Mines search history trends, popular categories, and average budget."""
        conn = self.get_connection()
        query = """
        SELECT 
            category,
            COUNT(*) as search_count,
            ROUND(AVG(budget), 2) as avg_budget,
            MIN(budget) as min_budget,
            MAX(budget) as max_budget
        FROM search_history
        GROUP BY category
        ORDER BY search_count DESC;
        """
        df = pd.read_sql_query(query, conn)
        conn.close()
        return df.to_dict(orient="records")

    def mine_price_vs_rating_correlation(self):
        """Calculates Pearson correlation between price and rating."""
        conn = self.get_connection()
        query = "SELECT price, rating FROM products;"
        df = pd.read_sql_query(query, conn)
        conn.close()
        if len(df) > 1:
            corr = df["price"].corr(df["rating"])
            return round(float(corr), 3)
        return 0.0

    def mine_value_for_money_leaders(self, top_n=6):
        """Identifies top value products where specifications/rating exceed price expectation."""
        conn = self.get_connection()
        query = """
        SELECT product_id, name, brand, category, price, rating, review_count, highlights
        FROM products
        ORDER BY (rating / (price / 10000.0)) DESC
        LIMIT ?;
        """
        cursor = conn.cursor()
        cursor.execute(query, (top_n,))
        rows = cursor.fetchall()
        conn.close()
        
        leaders = []
        for r in rows:
            leaders.append({
                "product_id": r[0], "name": r[1], "brand": r[2],
                "category": r[3], "price": r[4], "rating": r[5],
                "review_count": r[6], "highlights": r[7]
            })
        return leaders

    def get_full_analytics_dataset(self):
        """Returns unified analytical data structures for Plotly chart rendering."""
        cat_dist = self.mine_category_distribution()
        brand_dist = self.mine_brand_market_share()
        plat_disp = self.mine_platform_price_disparity()
        search_trends = self.mine_search_patterns()
        corr = self.mine_price_vs_rating_correlation()

        return {
            "categories": cat_dist,
            "brands": brand_dist,
            "platforms": plat_disp,
            "search_trends": search_trends,
            "price_rating_correlation": corr
        }

if __name__ == "__main__":
    miner = DataMiningEngine()
    print("Mined Category Distribution:", miner.mine_category_distribution())
    print("\nMined Platform Price Disparities:", miner.mine_platform_price_disparity())
    print("\nPrice vs Rating Correlation:", miner.mine_price_vs_rating_correlation())
