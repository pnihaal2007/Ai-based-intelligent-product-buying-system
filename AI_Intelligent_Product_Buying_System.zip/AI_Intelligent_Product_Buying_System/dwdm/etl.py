"""ETL (Extract, Transform, Load) Pipeline for AI + DWDM System.
Extracts product, pricing, user and search datasets from CSV sources, cleans and transforms them,
and loads them into operational SQLite tables and DWDM star-schema tables.
"""
import sys
import sqlite3
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from config import Config

def determine_price_tier(price):
    """Categorizes product into standard price bands."""
    if price < 25000:
        return "Budget (< ₹25,000)"
    elif price < 60000:
        return "Mid-Range (₹25k - ₹60k)"
    elif price < 100000:
        return "Upper Mid / Premium (₹60k - ₹1L)"
    else:
        return "Ultra Premium / Flagship (> ₹1L)"

def run_etl(db_path=Config.DATABASE_PATH):
    """Executes the full Extract, Transform, Load pipeline."""
    print("=" * 60)
    print("STARTING ETL PIPELINE EXECUTION")
    print(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    stats = {
        "products_extracted": 0,
        "products_cleaned": 0,
        "products_duplicates": 0,
        "products_rejected": 0,
        "products_loaded": 0,
        "listings_extracted": 0,
        "listings_cleaned": 0,
        "listings_duplicates": 0,
        "listings_rejected": 0,
        "listings_loaded": 0,
        "users_loaded": 0,
        "searches_loaded": 0,
        "fact_prices_loaded": 0,
        "fact_searches_loaded": 0
    }

    # -------------------------------------------------------------
    # 1. EXTRACT PHASE
    # -------------------------------------------------------------
    print("\n[PHASE 1: EXTRACT] Reading raw CSV data files...")
    
    if not Config.PRODUCTS_CSV.exists() or not Config.LISTINGS_CSV.exists():
        raise FileNotFoundError(f"Missing CSV data in {Config.DATA_DIR}. Run generate_demo_data.py first.")

    raw_products_df = pd.read_csv(Config.PRODUCTS_CSV)
    raw_listings_df = pd.read_csv(Config.LISTINGS_CSV)
    raw_users_df = pd.read_csv(Config.USERS_CSV) if Config.USERS_CSV.exists() else pd.DataFrame()
    raw_searches_df = pd.read_csv(Config.SEARCHES_CSV) if Config.SEARCHES_CSV.exists() else pd.DataFrame()

    stats["products_extracted"] = len(raw_products_df)
    stats["listings_extracted"] = len(raw_listings_df)
    print(f"-> Extracted {stats['products_extracted']} raw products")
    print(f"-> Extracted {stats['listings_extracted']} raw marketplace listings")
    print(f"-> Extracted {len(raw_users_df)} user personas and {len(raw_searches_df)} queries")

    # -------------------------------------------------------------
    # 2. TRANSFORM PHASE
    # -------------------------------------------------------------
    print("\n[PHASE 2: TRANSFORM] Cleaning, validating, and normalizing...")

    # A. Clean & Transform Products
    prods = raw_products_df.copy()
    initial_p_count = len(prods)

    # Reject invalid records (missing mandatory fields or price <= 0)
    prods = prods.dropna(subset=["product_id", "name", "brand", "category", "price"])
    prods = prods[prods["price"] > 0]
    stats["products_rejected"] = initial_p_count - len(prods)

    # Check and remove duplicates on product_id
    before_dedup = len(prods)
    prods = prods.drop_duplicates(subset=["product_id"])
    stats["products_duplicates"] = before_dedup - len(prods)

    # Normalize Text fields
    prods["name"] = prods["name"].astype(str).str.strip()
    prods["brand"] = prods["brand"].astype(str).str.strip().str.title()
    # Fix brand casing for known trademarks
    prods["brand"] = prods["brand"].replace({
        "Hp": "HP", "Asus": "ASUS", "Msi": "MSI", "Boat": "boAt",
        "Lg": "LG", "Tcl": "TCL", "Iqoo": "iQOO"
    })
    prods["category"] = prods["category"].astype(str).str.strip().str.title()
    prods["model_number"] = prods["model_number"].astype(str).str.strip()
    prods["variant"] = prods["variant"].fillna("Standard Edition").astype(str).str.strip()

    # Fill numerical missing values
    prods["price"] = prods["price"].astype(float)
    prods["mrp"] = prods["mrp"].fillna(prods["price"] * 1.15).astype(float)
    prods["ram_gb"] = prods["ram_gb"].fillna(0).astype(int)
    prods["storage_gb"] = prods["storage_gb"].fillna(0).astype(int)
    prods["display_size"] = prods["display_size"].fillna(0.0).astype(float)
    prods["rating"] = prods["rating"].fillna(4.0).clip(1.0, 5.0).astype(float)
    prods["review_count"] = prods["review_count"].fillna(100).astype(int)
    prods["warranty_months"] = prods["warranty_months"].fillna(12).astype(int)

    # Fill text specifications
    prods["processor"] = prods["processor"].fillna("Standard Processor")
    prods["gpu"] = prods["gpu"].fillna("Integrated Graphics")
    prods["battery_spec"] = prods["battery_spec"].fillna("Standard Battery")
    prods["camera_spec"] = prods["camera_spec"].fillna("N/A")
    prods["connectivity"] = prods["connectivity"].fillna("Wi-Fi, Bluetooth")
    prods["highlights"] = prods["highlights"].fillna("High performance and reliability")
    prods["intended_use"] = prods["intended_use"].fillna("Everyday productivity")
    prods["image_url"] = prods["image_url"].fillna("/static/images/placeholders/laptop.svg")

    prods["price_tier"] = prods["price"].apply(determine_price_tier)
    stats["products_cleaned"] = len(prods)
    print(f"-> Transformed products: {stats['products_cleaned']} valid (rejected {stats['products_rejected']}, duplicates removed {stats['products_duplicates']})")

    # B. Clean & Transform Listings
    listings = raw_listings_df.copy()
    initial_l_count = len(listings)

    listings = listings.dropna(subset=["product_id", "platform_id", "listed_price"])
    listings = listings[listings["listed_price"] > 0]
    stats["listings_rejected"] = initial_l_count - len(listings)

    before_l_dedup = len(listings)
    listings = listings.drop_duplicates(subset=["product_id", "platform_id"])
    stats["listings_duplicates"] = before_l_dedup - len(listings)

    # Price normalization & effective price calculation
    listings["listed_price"] = listings["listed_price"].astype(float)
    listings["mrp"] = listings["mrp"].fillna(listings["listed_price"]).astype(float)
    listings["discount"] = (listings["mrp"] - listings["listed_price"]).clip(lower=0)
    listings["coupon_discount"] = listings["coupon_discount"].fillna(0).astype(float)
    listings["delivery_charge"] = listings["delivery_charge"].fillna(0).astype(float)

    # Formal Effective Price Formula:
    # Effective Price = Listed Price + Mandatory Delivery Charges - Guaranteed Coupons
    listings["effective_price"] = (
        listings["listed_price"] + listings["delivery_charge"] - listings["coupon_discount"]
    ).round(2)

    # Platform normalization
    listings["platform_name"] = listings["platform_name"].astype(str).str.strip()
    listings["brand"] = listings["brand"].astype(str).str.strip().str.title().replace({
        "Hp": "HP", "Asus": "ASUS", "Msi": "MSI", "Boat": "boAt", "Lg": "LG", "Tcl": "TCL", "Iqoo": "iQOO"
    })
    listings["availability"] = listings["availability"].fillna("In Stock")
    listings["seller_name"] = listings["seller_name"].fillna("Authorized Retailer")
    listings["seller_rating"] = listings["seller_rating"].fillna(4.3).astype(float)
    listings["warranty"] = listings["warranty"].fillna("1 Year Manufacturer Warranty")
    listings["delivery_info"] = listings["delivery_info"].fillna("Standard Delivery")
    listings["data_source"] = listings["data_source"].fillna("DEMO DATA")
    listings["last_updated"] = listings["last_updated"].fillna(datetime.now().strftime("%Y-%m-%d"))

    stats["listings_cleaned"] = len(listings)
    print(f"-> Transformed listings: {stats['listings_cleaned']} valid (rejected {stats['listings_rejected']}, duplicates {stats['listings_duplicates']})")

    # -------------------------------------------------------------
    # 3. LOAD PHASE
    # -------------------------------------------------------------
    print("\n[PHASE 3: LOAD] Loading into Operational and DWDM Warehouse Tables...")
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Clear existing data for fresh idempotent load
    cursor.execute("DELETE FROM fact_product_prices;")
    cursor.execute("DELETE FROM fact_user_searches;")
    cursor.execute("DELETE FROM dim_product;")
    cursor.execute("DELETE FROM dim_platform;")
    cursor.execute("DELETE FROM dim_date;")
    cursor.execute("DELETE FROM dim_brand;")
    cursor.execute("DELETE FROM dim_category;")
    cursor.execute("DELETE FROM dim_user;")
    cursor.execute("DELETE FROM product_listings;")
    cursor.execute("DELETE FROM recommendations;")
    cursor.execute("DELETE FROM search_history;")
    cursor.execute("DELETE FROM user_preferences;")
    cursor.execute("DELETE FROM users;")
    cursor.execute("DELETE FROM products;")
    cursor.execute("DELETE FROM platforms;")

    # A. Load Operational: Platforms
    for p in Config.PLATFORMS:
        cursor.execute("""
            INSERT INTO platforms (platform_id, name, platform_type, icon)
            VALUES (?, ?, ?, ?);
        """, (p["id"], p["name"], p["type"], p["icon"]))

    # B. Load Operational: Products
    product_insert_sql = """
        INSERT INTO products (
            product_id, name, brand, category, model_number, variant,
            price, mrp, processor, gpu, ram_gb, storage_gb,
            display_size, battery_spec, camera_spec, connectivity,
            rating, review_count, warranty_months, highlights, intended_use, image_url
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
    """
    for _, row in prods.iterrows():
        cursor.execute(product_insert_sql, (
            int(row["product_id"]), row["name"], row["brand"], row["category"],
            row["model_number"], row["variant"], float(row["price"]), float(row["mrp"]),
            row["processor"], row["gpu"], int(row["ram_gb"]), int(row["storage_gb"]),
            float(row["display_size"]), row["battery_spec"], row["camera_spec"], row["connectivity"],
            float(row["rating"]), int(row["review_count"]), int(row["warranty_months"]),
            row["highlights"], row["intended_use"], row["image_url"]
        ))
    stats["products_loaded"] = len(prods)

    # C. Load Operational: Listings
    listing_insert_sql = """
        INSERT INTO product_listings (
            product_id, platform_id, platform_name, platform_type,
            listing_title, brand, model_number, variant,
            listed_price, mrp, discount, coupon_discount, delivery_charge,
            effective_price, bank_offer_text, seller_name, seller_rating,
            availability, warranty, delivery_info, product_url, data_source, last_updated
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
    """
    for _, row in listings.iterrows():
        cursor.execute(listing_insert_sql, (
            int(row["product_id"]), row["platform_id"], row["platform_name"], row["platform_type"],
            row["listing_title"], row["brand"], row["model_number"], row["variant"],
            float(row["listed_price"]), float(row["mrp"]), float(row["discount"]),
            float(row["coupon_discount"]), float(row["delivery_charge"]), float(row["effective_price"]),
            row["bank_offer_text"], row["seller_name"], float(row["seller_rating"]),
            row["availability"], row["warranty"], row["delivery_info"],
            row["product_url"], row["data_source"], row["last_updated"]
        ))
    stats["listings_loaded"] = len(listings)

    # D. Load Operational: Users & Searches
    if not raw_users_df.empty:
        for _, u in raw_users_df.iterrows():
            cursor.execute("""
                INSERT INTO users (user_id, persona_name, preferred_category, budget_range, created_at)
                VALUES (?, ?, ?, ?, ?);
            """, (int(u["user_id"]), u["persona_name"], u["preferred_category"], u["budget_range"], u["created_at"]))
        stats["users_loaded"] = len(raw_users_df)

    if not raw_searches_df.empty:
        for _, s in raw_searches_df.iterrows():
            cursor.execute("""
                INSERT INTO search_history (user_id, query_text, category, budget, recommended_product_id, search_date)
                VALUES (?, ?, ?, ?, ?, ?);
            """, (int(s["user_id"]), s["query_text"], s["category"], float(s["budget"]), int(s["recommended_product_id"]), s["search_date"]))
        stats["searches_loaded"] = len(raw_searches_df)

    # =============================================================
    # DWDM STAR-SCHEMA POPULATION
    # =============================================================
    print("-> Populating Star Schema Dimensions & Facts...")

    # 1. dim_brand
    unique_brands = prods["brand"].unique()
    for b in unique_brands:
        cursor.execute("INSERT INTO dim_brand (brand_name) VALUES (?);", (b,))

    # 2. dim_category
    unique_cats = prods["category"].unique()
    for c in unique_cats:
        cursor.execute("INSERT INTO dim_category (category_name) VALUES (?);", (c,))

    # 3. dim_platform
    for p in Config.PLATFORMS:
        cursor.execute("""
            INSERT INTO dim_platform (platform_id, platform_name, platform_type)
            VALUES (?, ?, ?);
        """, (p["id"], p["name"], p["type"]))

    # 4. dim_date
    date_records = [
        (20260915, "2026-09-15", 15, 9, "September", 3, 2026),
        (20260920, "2026-09-20", 20, 9, "September", 3, 2026),
        (20260925, "2026-09-25", 25, 9, "September", 3, 2026),
        (20260930, "2026-09-30", 30, 9, "September", 3, 2026),
    ]
    for d in date_records:
        cursor.execute("""
            INSERT INTO dim_date (date_key, full_date, day, month, month_name, quarter, year)
            VALUES (?, ?, ?, ?, ?, ?, ?);
        """, d)

    # 5. dim_product
    for _, p in prods.iterrows():
        cursor.execute("""
            INSERT INTO dim_product (
                product_id, product_name, brand, category, model_number, variant,
                ram_gb, storage_gb, price_tier
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
        """, (
            int(p["product_id"]), p["name"], p["brand"], p["category"],
            p["model_number"], p["variant"], int(p["ram_gb"]), int(p["storage_gb"]), p["price_tier"]
        ))

    # 6. dim_user
    if not raw_users_df.empty:
        for _, u in raw_users_df.iterrows():
            cursor.execute("""
                INSERT INTO dim_user (user_id, persona_name, preferred_category, budget_range)
                VALUES (?, ?, ?, ?);
            """, (int(u["user_id"]), u["persona_name"], u["preferred_category"], u["budget_range"]))

    # 7. Fact Table: fact_product_prices
    # Join keys from dimensions
    cursor.execute("""
        INSERT INTO fact_product_prices (
            product_key, platform_key, date_key,
            listed_price, effective_price, discount, coupon_discount, delivery_charge, availability_status
        )
        SELECT 
            dp.product_key,
            dpl.platform_key,
            20260930 AS date_key,
            pl.listed_price,
            pl.effective_price,
            pl.discount,
            pl.coupon_discount,
            pl.delivery_charge,
            pl.availability
        FROM product_listings pl
        JOIN dim_product dp ON pl.product_id = dp.product_id
        JOIN dim_platform dpl ON pl.platform_id = dpl.platform_id;
    """)
    cursor.execute("SELECT COUNT(*) FROM fact_product_prices;")
    stats["fact_prices_loaded"] = cursor.fetchone()[0]

    # 8. Fact Table: fact_user_searches
    cursor.execute("""
        INSERT INTO fact_user_searches (
            user_key, category_key, date_key, budget, recommended_product_key
        )
        SELECT 
            du.user_key,
            dc.category_key,
            20260930 AS date_key,
            sh.budget,
            dp.product_key
        FROM search_history sh
        JOIN dim_user du ON sh.user_id = du.user_id
        JOIN dim_category dc ON sh.category = dc.category_name
        LEFT JOIN dim_product dp ON sh.recommended_product_id = dp.product_id;
    """)
    cursor.execute("SELECT COUNT(*) FROM fact_user_searches;")
    stats["fact_searches_loaded"] = cursor.fetchone()[0]

    conn.commit()
    conn.close()

    print("\n" + "=" * 60)
    print("ETL PIPELINE SUMMARY STATISTICS")
    print("=" * 60)
    print(f"Products: {stats['products_extracted']} Extracted | {stats['products_cleaned']} Cleaned | {stats['products_loaded']} Loaded")
    print(f"Listings: {stats['listings_extracted']} Extracted | {stats['listings_cleaned']} Cleaned | {stats['listings_loaded']} Loaded")
    print(f"Users & Searches: {stats['users_loaded']} Users Loaded | {stats['searches_loaded']} Searches Loaded")
    print(f"Star-Schema Facts: {stats['fact_prices_loaded']} Price Facts | {stats['fact_searches_loaded']} Search Facts")
    print("ETL execution completed successfully.\n")

    return stats

if __name__ == "__main__":
    run_etl()
