"""Configuration settings for AI-Based Intelligent Product Buying Decision System."""
import os
from pathlib import Path
from dotenv import load_dotenv

# Base Directory of the Project
BASE_DIR = Path(__file__).resolve().parent

# Load environment variables if .env exists
env_path = BASE_DIR / ".env"
if env_path.exists():
    load_dotenv(env_path)
else:
    load_dotenv(BASE_DIR / ".env.example")

class Config:
    """Application configuration parameters."""
    SECRET_KEY = os.getenv("SECRET_KEY", "ai-dwdm-decision-support-key-2026")
    APP_MODE = os.getenv("APP_MODE", "DEMO").upper()  # 'DEMO' or 'LIVE'
    PORT = int(os.getenv("PORT", 5000))
    DEBUG = os.getenv("FLASK_DEBUG", "True").lower() in ("true", "1", "yes")

    # Data & Database Paths
    DATABASE_PATH = BASE_DIR / "database" / "database.db"
    DATA_DIR = BASE_DIR / "data"
    PRODUCTS_CSV = DATA_DIR / "products.csv"
    LISTINGS_CSV = DATA_DIR / "platform_listings.csv"
    USERS_CSV = DATA_DIR / "users.csv"
    SEARCHES_CSV = DATA_DIR / "searches.csv"

    # ML Model Artifacts Path
    ML_MODELS_DIR = BASE_DIR / "ml" / "models"
    KMEANS_MODEL_PATH = ML_MODELS_DIR / "kmeans_model.pkl"
    SCALER_PATH = ML_MODELS_DIR / "scaler.pkl"
    KNN_MODEL_PATH = ML_MODELS_DIR / "knn_model.pkl"

    # Supported Product Categories
    CATEGORIES = [
        "Laptops",
        "Smartphones",
        "Headphones",
        "Smartwatches",
        "Televisions",
        "Tablets"
    ]

    # Supported Retailers / Platforms
    PLATFORMS = [
        {"id": "amazon", "name": "Amazon India", "type": "Marketplace", "icon": "bi-cart-check"},
        {"id": "flipkart", "name": "Flipkart", "type": "Marketplace", "icon": "bi-bag-fill"},
        {"id": "croma", "name": "Croma", "type": "Retailer", "icon": "bi-shop"},
        {"id": "reliance", "name": "Reliance Digital", "type": "Retailer", "icon": "bi-building"},
        {"id": "vijay_sales", "name": "Vijay Sales", "type": "Retailer", "icon": "bi-tv"},
        {"id": "official_store", "name": "Official Brand Store", "type": "Official Brand Store", "icon": "bi-shield-check"}
    ]

    # Platform Buying Option Scoring Weights (Total 100%)
    SCORING_WEIGHTS = {
        "price_value": 0.40,       # Effective price relative to lowest in market
        "seller_reliability": 0.20, # Seller rating & verified status
        "warranty": 0.15,          # Official brand warranty & duration
        "offers": 0.10,            # Instant discounts & coupons
        "availability": 0.10,      # In stock vs limited / pre-order
        "delivery": 0.05           # Free fast delivery vs charges
    }

    # Optional Live API Keys
    AMAZON_API_KEY = os.getenv("AMAZON_API_KEY", "")
    FLIPKART_API_KEY = os.getenv("FLIPKART_API_KEY", "")
    CROMA_API_KEY = os.getenv("CROMA_API_KEY", "")
    RELIANCE_API_KEY = os.getenv("RELIANCE_API_KEY", "")
    VIJAY_SALES_API_KEY = os.getenv("VIJAY_SALES_API_KEY", "")
