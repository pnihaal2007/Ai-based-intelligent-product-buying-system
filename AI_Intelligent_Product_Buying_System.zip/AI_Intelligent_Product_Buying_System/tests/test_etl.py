"""Unit tests for DWDM ETL Pipeline and Star-Schema Data Warehouse."""
import sys
import sqlite3
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from dwdm.etl import run_etl, determine_price_tier
from config import Config

def test_price_tier_classification():
    assert "Budget" in determine_price_tier(15000)
    assert "Mid-Range" in determine_price_tier(45000)
    assert "Premium" in determine_price_tier(75000)
    assert "Flagship" in determine_price_tier(125000)

def test_etl_execution_and_star_schema_loading():
    """Runs ETL pipeline and asserts star-schema dimensions and facts are populated."""
    stats = run_etl(Config.DATABASE_PATH)

    assert stats["products_loaded"] > 100
    assert stats["listings_loaded"] > 300
    assert stats["fact_prices_loaded"] > 300
    assert stats["fact_searches_loaded"] > 100

    conn = sqlite3.connect(Config.DATABASE_PATH)
    cursor = conn.cursor()

    # Verify dim_product
    cursor.execute("SELECT COUNT(*) FROM dim_product;")
    dim_p_count = cursor.fetchone()[0]
    assert dim_p_count == stats["products_loaded"]

    # Verify fact_product_prices joins
    cursor.execute("""
        SELECT COUNT(*) 
        FROM fact_product_prices f
        JOIN dim_product p ON f.product_key = p.product_key;
    """)
    join_count = cursor.fetchone()[0]
    assert join_count > 0

    conn.close()
