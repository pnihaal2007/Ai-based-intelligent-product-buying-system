"""Unit tests for Automatic Alternative Product Finder."""
import sys
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from ai.alternative_finder import AlternativeFinder
from config import Config

def test_alternative_finder_respects_budget():
    """Verifies that discovered alternatives are within user's maximum budget."""
    finder = AlternativeFinder(Config.DATABASE_PATH)
    weak_laptop = {
        "product_id": 9993,
        "name": "Underpowered Laptop",
        "brand": "Generic",
        "category": "Laptops",
        "price": 68000.0,
        "rating": 3.8,
        "processor": "Intel Core i3",
        "gpu": "Intel UHD",
        "ram_gb": 8,
        "storage_gb": 256
    }
    user_req = {
        "budget": 70000.0,
        "category": "Laptops",
        "use_cases": ["programming", "gaming"]
    }
    alternatives = finder.find_better_alternatives(weak_laptop, user_req, limit=3)

    assert len(alternatives) > 0
    for alt in alternatives:
        assert alt["price"] <= 70000.0
        assert "improvements" in alt
        assert alt["product_id"] != weak_laptop["product_id"]
