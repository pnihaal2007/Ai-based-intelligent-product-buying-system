"""Integration and route tests for Flask application."""
import sys
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

import pytest
from app import app

@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client

def test_home_route(client):
    rv = client.get("/")
    assert rv.status_code == 200
    assert b"SmartBuyer" in rv.data

def test_assistant_route(client):
    rv = client.get("/assistant")
    assert rv.status_code == 200
    assert b"AI Product Recommendation Assistant" in rv.data

def test_products_route(client):
    rv = client.get("/products")
    assert rv.status_code == 200
    assert b"Product Catalog" in rv.data

def test_product_detail_route(client):
    rv = client.get("/product/1001")
    assert rv.status_code == 200
    assert b"Technical Specifications" in rv.data

def test_recommend_route(client):
    rv = client.get("/recommend?q=Gaming+laptop+under+80000+for+coding")
    assert rv.status_code == 200
    assert b"Recommendations for Your Target Profile" in rv.data

def test_worth_it_route(client):
    rv = client.get("/worth-it?product_id=1001&budget=80000")
    assert rv.status_code == 200
    assert b"Worth It" in rv.data

def test_compare_route(client):
    rv = client.get("/compare?ids=1001,1002")
    assert rv.status_code == 200
    assert b"Side-by-Side Product Comparison" in rv.data

def test_stores_route(client):
    rv = client.get("/stores/1001")
    assert rv.status_code == 200
    assert b"Store Comparison" in rv.data

def test_analytics_route(client):
    rv = client.get("/analytics")
    assert rv.status_code == 200
    assert b"DWDM Business Intelligence" in rv.data

def test_about_route(client):
    rv = client.get("/about")
    assert rv.status_code == 200
    assert b"AI-Based Intelligent Product Buying Decision System" in rv.data

def test_api_recommend(client):
    rv = client.post("/api/recommend", json={"query": "Best camera phone under 40000"})
    assert rv.status_code == 200
    data = rv.get_json()
    assert "recommendations" in data
    assert len(data["recommendations"]) > 0

def test_download_zip_route(client):
    rv = client.get("/download-zip")
    assert rv.status_code == 200
    assert rv.headers["Content-Type"] == "application/zip"
