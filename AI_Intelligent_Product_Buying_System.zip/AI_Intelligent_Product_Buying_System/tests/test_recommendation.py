"""Unit tests for AI Product Recommendation Engine."""
import sys
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from ai.recommendation_engine import RecommendationEngine
from config import Config

def test_dynamic_scoring_for_different_users():
    """Verifies that the same product receives different recommendation scores for different user requirements."""
    engine = RecommendationEngine(Config.DATABASE_PATH)

    sample_laptop = {
        "product_id": 9999,
        "name": "Test Nitro Gaming",
        "brand": "Acer",
        "category": "Laptops",
        "price": 75000.0,
        "mrp": 90000.0,
        "processor": "Intel Core i5 13420H",
        "gpu": "NVIDIA RTX 4050 6GB",
        "ram_gb": 16,
        "storage_gb": 512,
        "display_size": 15.6,
        "rating": 4.4
    }

    # Gamer Profile
    gamer_req = {
        "budget": 80000.0,
        "category": "Laptops",
        "use_cases": ["gaming", "machine_learning"],
        "preferred_brand": None
    }
    p_gamer = engine.calculate_user_preference_score(sample_laptop, gamer_req)

    # Lightweight Student Profile (No gaming, cares about battery/portability)
    student_req = {
        "budget": 80000.0,
        "category": "Laptops",
        "use_cases": ["college", "battery"],
        "preferred_brand": "Apple"
    }
    p_student = engine.calculate_user_preference_score(sample_laptop, student_req)

    # Gamer preference score must be significantly higher than non-gamer student score
    assert p_gamer > p_student + 10.0

def test_budget_awareness_not_defaulting_to_most_expensive():
    """Verifies that the engine does not blindly favor a more expensive product over a better value one."""
    engine = RecommendationEngine(Config.DATABASE_PATH)
    req = {
        "category": "Laptops",
        "budget": 80000.0,
        "use_cases": ["programming", "gaming"],
        "preferred_brand": None
    }
    recs = engine.recommend(req, limit=6)
    assert len(recs) > 0

    # Ensure recommended products are within or reasonably close to budget
    for r in recs:
        assert r["price"] <= 80000.0 * 1.20
        assert "ai_match_score" in r
        assert "budget_remaining" in r
        assert r["ai_match_score"] > 50.0
