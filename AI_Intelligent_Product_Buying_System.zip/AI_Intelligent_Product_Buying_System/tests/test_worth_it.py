"""Unit tests for Worth-It Evaluation Engine."""
import sys
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from ai.worth_it_engine import WorthItEngine
from config import Config

def test_over_budget_product_worth_it():
    """An overpriced product beyond stated budget should be flagged with alternatives."""
    engine = WorthItEngine(Config.DATABASE_PATH)
    expensive_laptop = {
        "product_id": 9991,
        "name": "Overpriced Spec Laptop",
        "brand": "Generic",
        "category": "Laptops",
        "price": 120000.0,
        "rating": 4.0,
        "processor": "Intel Core i5",
        "gpu": "Intel Iris Xe",
        "ram_gb": 8,
        "storage_gb": 256
    }
    user_req = {
        "budget": 70000.0,
        "category": "Laptops",
        "use_cases": ["programming", "gaming"]
    }
    result = engine.evaluate_product(expensive_laptop, user_req)

    assert result["is_over_budget"] is True
    assert result["verdict"] == "BETTER ALTERNATIVES AVAILABLE"
    assert len(result["better_alternatives"]) > 0

def test_strong_fit_product_worth_it():
    """A well-priced, high-spec product matching user needs should score as Strong Fit or Reasonable Fit."""
    engine = WorthItEngine(Config.DATABASE_PATH)
    good_laptop = {
        "product_id": 9992,
        "name": "High Value Coding Laptop",
        "brand": "Lenovo",
        "category": "Laptops",
        "price": 64990.0,
        "rating": 4.5,
        "processor": "Intel Core i5 12450H",
        "gpu": "NVIDIA RTX 3050",
        "ram_gb": 16,
        "storage_gb": 512
    }
    user_req = {
        "budget": 75000.0,
        "category": "Laptops",
        "use_cases": ["programming", "gaming"]
    }
    result = engine.evaluate_product(good_laptop, user_req)

    assert result["is_over_budget"] is False
    assert result["verdict"] in ["STRONG FIT FOR YOUR REQUIREMENTS", "REASONABLE FIT — CONSIDER THESE TRADE-OFFS"]
    assert len(result["reasons"]) > 0
