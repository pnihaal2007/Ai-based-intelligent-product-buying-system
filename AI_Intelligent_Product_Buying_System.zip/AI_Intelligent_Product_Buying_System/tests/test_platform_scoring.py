"""Unit tests for Platform and Store Buying Option Scoring Engine."""
import sys
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from ai.platform_scoring import PlatformScoringEngine

def test_effective_price_calculation():
    """Effective price must include delivery and coupons, but keep conditional bank offers separate."""
    engine = PlatformScoringEngine()
    listing = {
        "listed_price": 74999.0,
        "delivery_charge": 99.0,
        "coupon_discount": 1500.0,
        "bank_offer_text": "Flat ₹3,000 off on HDFC Credit Cards"
    }

    eff_price = engine.calculate_effective_price(listing)
    # Expected: 74999 + 99 - 1500 = 73598 (bank offer NOT subtracted!)
    assert eff_price == 73598.0

def test_cheapest_headline_price_not_automatic_winner_if_unreliable():
    """A store with slightly cheaper headline price but bad seller rating and no warranty
    should not automatically beat an official brand store with free delivery and 2yr warranty."""
    engine = PlatformScoringEngine()

    shady_store = {
        "platform_name": "ShadyMarket",
        "platform_type": "Marketplace",
        "listed_price": 68000.0,
        "delivery_charge": 500.0,
        "coupon_discount": 0.0,
        "seller_name": "UnknownSeller",
        "seller_rating": 2.8,
        "warranty": "None",
        "availability": "Limited Stock",
        "delivery_info": "7-10 Days"
    }

    official_store = {
        "platform_name": "Official Brand Store",
        "platform_type": "Official Brand Store",
        "listed_price": 68500.0,
        "delivery_charge": 0.0,
        "coupon_discount": 500.0,  # Effective price = 68000
        "seller_name": "Direct Manufacturer",
        "seller_rating": 4.9,
        "warranty": "2 Year Official Comprehensive Warranty",
        "availability": "In Stock",
        "delivery_info": "1 Day Fast Free Delivery"
    }

    scored = engine.score_buying_options([shady_store, official_store])
    assert len(scored) == 2
    # Official brand store must score higher
    assert scored[0]["platform_name"] == "Official Brand Store"
    assert scored[0]["buying_score"] > scored[1]["buying_score"]

def test_missing_data_does_not_crash_scoring():
    """Ensures missing optional fields do not crash the scoring engine."""
    engine = PlatformScoringEngine()
    bare_listing = {
        "listed_price": 40000.0
    }
    scored = engine.score_buying_options([bare_listing])
    assert len(scored) == 1
    assert scored[0]["buying_score"] > 0
    assert scored[0]["effective_price"] == 40000.0
