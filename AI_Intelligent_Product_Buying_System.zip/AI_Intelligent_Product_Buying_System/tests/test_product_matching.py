"""Unit tests for Cross-Platform Exact Product / Variant Matching Engine."""
import sys
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from ai.product_matching import ProductMatchingEngine

def test_variant_difference_detection():
    """8GB/128GB vs 12GB/256GB must NOT automatically be considered identical!"""
    engine = ProductMatchingEngine()

    base_phone = {
        "brand": "OnePlus",
        "name": "OnePlus 12R",
        "model_number": "CPH2585",
        "ram_gb": 8,
        "storage_gb": 128
    }

    # Different RAM & Storage variant listing
    variant_listing = {
        "brand": "OnePlus",
        "listing_title": "OnePlus 12R (16GB RAM, 256GB Storage, Cool Blue)",
        "model_number": "CPH2585-256",
        "ram_gb": 16,
        "storage_gb": 256
    }

    confidence, classification, explanation = engine.compute_match_confidence(base_phone, variant_listing)

    assert classification == "Different Variant"
    assert confidence < 75.0
    assert "RAM difference" in explanation or "Storage difference" in explanation

def test_exact_match_detection():
    """Identical model code and specifications must achieve high match confidence."""
    engine = ProductMatchingEngine()

    base_laptop = {
        "brand": "HP",
        "name": "HP Victus Gaming 15",
        "model_number": "15-fa0070TX",
        "ram_gb": 16,
        "storage_gb": 512
    }

    store_listing = {
        "brand": "HP",
        "listing_title": "HP Victus 15-fa0070TX Intel Core i5 Gaming Notebook (16GB/512GB)",
        "model_number": "15-fa0070TX",
        "ram_gb": 16,
        "storage_gb": 512
    }

    confidence, classification, explanation = engine.compute_match_confidence(base_laptop, store_listing)

    assert classification == "Exact Match"
    assert confidence >= 95.0
