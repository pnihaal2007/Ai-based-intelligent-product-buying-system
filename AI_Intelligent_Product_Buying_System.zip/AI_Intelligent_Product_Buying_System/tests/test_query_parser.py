"""Unit tests for Natural-Language Query Parser."""
import sys
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from ai.query_parser import QueryParser

def test_parse_laptop_query():
    parser = QueryParser()
    query = "Gaming laptop under ₹80000 for coding"
    res = parser.parse(query)

    assert res["category"] == "Laptops"
    assert res["budget"] == 80000.0
    assert "gaming" in res["use_cases"]
    assert "programming" in res["use_cases"]

def test_parse_worth_it_query():
    parser = QueryParser()
    query = "Is HP Victus worth ₹70,000 for programming?"
    res = parser.parse(query)

    assert res["query_type"] == "worth_it"
    assert res["category"] == "Laptops"
    assert res["budget"] == 70000.0
    assert res["preferred_brand"] == "HP"
    assert "programming" in res["use_cases"]

def test_parse_smartphone_camera_query():
    parser = QueryParser()
    query = "Best camera phone under ₹40,000"
    res = parser.parse(query)

    assert res["category"] == "Smartphones"
    assert res["budget"] == 40000.0
    assert "camera" in res["use_cases"]

def test_parse_earbuds_query():
    parser = QueryParser()
    query = "Good earbuds below ₹5,000 with ANC and battery"
    res = parser.parse(query)

    assert res["category"] == "Headphones"
    assert res["budget"] == 5000.0
    assert "anc_audio" in res["use_cases"]
    assert "battery" in res["use_cases"]
