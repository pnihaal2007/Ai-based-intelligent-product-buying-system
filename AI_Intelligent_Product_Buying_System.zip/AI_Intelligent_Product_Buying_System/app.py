"""Flask Web Application for AI-Based Intelligent Product Buying Decision System.
Combines Artificial Intelligence (NLP parsing, dynamic weighted recommendation, worth-it engine)
and Data Warehousing & Data Mining (star-schema analytics, multi-platform listings comparison).
"""
import os
import sys
import json
import sqlite3
import zipfile
import io
from pathlib import Path
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, send_file

# Add project root to sys.path
BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

from config import Config
from ai import (
    QueryParser,
    RecommendationEngine,
    WorthItEngine,
    AlternativeFinder,
    ProductMatchingEngine,
    PlatformScoringEngine,
    ExplanationEngine
)
from dwdm.warehouse import get_db_connection, get_star_schema_summary
from dwdm.data_mining import DataMiningEngine
from providers import get_all_providers, get_provider

app = Flask(__name__)
app.config.from_object(Config)

# Initialize Core AI Engines
query_parser = QueryParser()
rec_engine = RecommendationEngine(Config.DATABASE_PATH)
worth_it_engine = WorthItEngine(Config.DATABASE_PATH)
alt_finder = AlternativeFinder(Config.DATABASE_PATH)
matching_engine = ProductMatchingEngine()
scoring_engine = PlatformScoringEngine()
mining_engine = DataMiningEngine(Config.DATABASE_PATH)

def get_product_by_id(product_id: int):
    """Helper to fetch a single product by ID."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM products WHERE product_id = ?;", (product_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

@app.route("/")
def index():
    """Home landing page with hero AI search, categories, and top value picks."""
    conn = get_db_connection()
    cursor = conn.cursor()
    # Fetch top rated / featured picks across categories
    cursor.execute("""
        SELECT * FROM products
        WHERE rating >= 4.3
        ORDER BY (rating * 10000.0 / price) DESC
        LIMIT 6;
    """)
    featured = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return render_template("index.html", featured_products=featured)

@app.route("/assistant")
def assistant():
    """Natural-language AI shopping assistant and guided preference form."""
    q = request.args.get("q", "").strip()
    parsed = query_parser.parse(q) if q else None
    return render_template("assistant.html", parsed_query=parsed)

@app.route("/recommend", methods=["GET", "POST"])
def recommend():
    """Processes user requirements and returns ranked AI recommendations."""
    if request.method == "POST":
        category = request.form.get("category", "Laptops")
        budget = float(request.form.get("budget", 80000))
        brand = request.form.get("brand") or None
        use_cases = request.form.getlist("use_cases")
        user_req = {
            "raw_query": f"Manual Guided Search: {category} under ₹{budget:,.0f}",
            "category": category,
            "budget": budget,
            "preferred_brand": brand,
            "use_cases": use_cases,
            "priority_features": [],
            "query_type": "recommendation"
        }
    else:
        query_text = request.args.get("q", "").strip()
        if not query_text:
            return redirect(url_for("assistant"))

        user_req = query_parser.parse(query_text)
        # If user explicitly overrode budget or category in URL
        if request.args.get("budget"):
            try:
                user_req["budget"] = float(request.args.get("budget"))
            except ValueError:
                pass
        if request.args.get("category"):
            user_req["category"] = request.args.get("category")

    # If query was detected as a worth-it question (e.g. "Is Laptop X worth ₹70,000?")
    if user_req.get("query_type") == "worth_it" and user_req.get("specific_product"):
        # Look for matching product
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT product_id FROM products WHERE name LIKE ? OR brand LIKE ? LIMIT 1;",
                       (f"%{user_req['specific_product']}%", f"%{user_req['specific_product']}%"))
        match_row = cursor.fetchone()
        conn.close()
        if match_row:
            return redirect(url_for("worth_it", product_id=match_row["product_id"], budget=user_req["budget"]))

    recommendations = rec_engine.recommend(user_req, limit=6)
    return render_template("recommendations.html", user_requirements=user_req, recommendations=recommendations)

@app.route("/worth-it", methods=["GET", "POST"])
def worth_it():
    """Evaluates whether a considered product is worth buying for user's budget and requirements."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT product_id, name, brand, price FROM products ORDER BY name ASC;")
    all_prods = [dict(r) for r in cursor.fetchall()]
    conn.close()

    product_id = request.args.get("product_id") or request.form.get("product_id")
    budget_arg = request.args.get("budget") or request.form.get("budget")

    evaluated = None
    if product_id:
        target_prod = get_product_by_id(int(product_id))
        if target_prod:
            budget = float(budget_arg) if budget_arg else float(target_prod["price"])
            # Synthesize user requirement
            user_req = {
                "raw_query": f"Is {target_prod['name']} worth buying for ₹{budget:,.0f}?",
                "category": target_prod["category"],
                "budget": budget,
                "preferred_brand": target_prod["brand"],
                "use_cases": ["programming", "gaming"] if target_prod["category"] == "Laptops" else ["camera"],
                "priority_features": []
            }
            evaluated = worth_it_engine.evaluate_product(target_prod, user_req)

    return render_template("worth_it.html", all_products=all_prods, evaluated=evaluated)

@app.route("/products")
def products():
    """Full product catalog with filtering by category, brand, price sort, and search keyword."""
    conn = get_db_connection()
    cursor = conn.cursor()

    cat_filter = request.args.get("category", "").strip()
    brand_filter = request.args.get("brand", "").strip()
    search_query = request.args.get("search", "").strip()
    sort_order = request.args.get("sort", "featured")

    sql = "SELECT * FROM products WHERE 1=1"
    params = []

    if cat_filter:
        sql += " AND category = ?"
        params.append(cat_filter)
    if brand_filter:
        sql += " AND brand = ?"
        params.append(brand_filter)
    if search_query:
        sql += " AND (name LIKE ? OR brand LIKE ? OR processor LIKE ? OR highlights LIKE ?)"
        term = f"%{search_query}%"
        params.extend([term, term, term, term])

    if sort_order == "price_asc":
        sql += " ORDER BY price ASC"
    elif sort_order == "price_desc":
        sql += " ORDER BY price DESC"
    elif sort_order == "rating_desc":
        sql += " ORDER BY rating DESC"
    else:
        sql += " ORDER BY rating DESC, review_count DESC"

    cursor.execute(sql, params)
    prods = [dict(r) for r in cursor.fetchall()]

    # Fetch unique categories and brands for filter menus
    cursor.execute("SELECT DISTINCT category FROM products ORDER BY category ASC;")
    categories = [r[0] for r in cursor.fetchall()]
    cursor.execute("SELECT DISTINCT brand FROM products ORDER BY brand ASC;")
    brands = [r[0] for r in cursor.fetchall()]
    cursor.execute("SELECT COUNT(*) FROM products;")
    total_count = cursor.fetchone()[0]

    conn.close()
    return render_template(
        "products.html",
        products=prods,
        categories=categories,
        brands=brands,
        selected_category=cat_filter,
        selected_brand=brand_filter,
        selected_sort=sort_order,
        search_query=search_query,
        total_count=total_count
    )

@app.route("/product/<int:product_id>")
def product_detail(product_id):
    """Detailed specifications and buying options for a specific product."""
    product = get_product_by_id(product_id)
    if not product:
        return render_template("404.html"), 404

    # Fetch all listings from operational database
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM product_listings WHERE product_id = ? ORDER BY listed_price ASC;", (product_id,))
    listings = [dict(r) for r in cursor.fetchall()]
    conn.close()

    # Assign transparent buying option scores
    scored_listings = scoring_engine.score_buying_options(listings)

    return render_template(
        "product_detail.html",
        product=product,
        listings=listings,
        scored_listings=scored_listings
    )

@app.route("/stores/<int:product_id>")
def stores(product_id):
    """Dedicated cross-platform store comparison table with effective prices."""
    product = get_product_by_id(product_id)
    if not product:
        return render_template("404.html"), 404

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM product_listings WHERE product_id = ? ORDER BY listed_price ASC;", (product_id,))
    listings = [dict(r) for r in cursor.fetchall()]
    conn.close()

    scored_listings = scoring_engine.score_buying_options(listings)
    best_option = scored_listings[0] if scored_listings else None

    return render_template(
        "stores.html",
        product=product,
        listings=scored_listings,
        best_option=best_option
    )

@app.route("/compare")
def compare():
    """Side-by-side comparison for 2 to 4 products."""
    ids_param = request.args.get("ids", "")
    id_list = []
    if ids_param:
        for val in ids_param.split(","):
            val = val.strip()
            if val.isdigit():
                id_list.append(int(val))

    products = []
    for pid in id_list[:4]:
        p = get_product_by_id(pid)
        if p:
            perf = rec_engine.calculate_performance_score(p, ["programming", "gaming"])
            val = rec_engine.calculate_value_score(perf, p["price"], p["rating"], p["category"])
            p_dict = dict(p)
            p_dict["performance_score"] = perf
            p_dict["value_score"] = val
            products.append(p_dict)

    # Generate comparative trade-off narrative if 2+ products compared
    ai_verdict = ""
    if len(products) >= 2:
        p1 = products[0]
        p2 = products[1]
        diff_price = abs(p1["price"] - p2["price"])
        cheaper = p1 if p1["price"] < p2["price"] else p2
        pricier = p2 if p1["price"] < p2["price"] else p1
        ai_verdict = (
            f"Comparing {p1['name']} against {p2['name']}: {cheaper['name']} provides stronger value for money, "
            f"saving ₹{diff_price:,.0f}, while {pricier['name']} commands a higher price tag with specialized "
            f"{pricier.get('processor', '')} architecture."
        )

    return render_template("compare.html", products=products, ai_verdict=ai_verdict)

@app.route("/analytics")
def analytics():
    """Interactive DWDM Analytics Dashboard powered by SQLite Star-Schema Data Warehouse."""
    summary = get_star_schema_summary(Config.DATABASE_PATH)
    mined_data = mining_engine.get_full_analytics_dataset()
    return render_template("analytics.html", warehouse_summary=summary, mined_data=mined_data)

@app.route("/about")
def about():
    """Academic architecture, system design, AI vs DWDM distinction, and star schema details."""
    return render_template("about.html")

@app.route("/download-zip")
def download_zip():
    """Packages the entire project into a clean, downloadable ZIP file."""
    memory_file = io.BytesIO()
    project_root = BASE_DIR

    with zipfile.ZipFile(memory_file, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(project_root):
            # Exclude cache and virtual environments
            dirs[:] = [d for d in dirs if d not in [
                "__pycache__", ".pytest_cache", "venv", ".venv", "env", "node_modules", ".git"
            ]]
            for file in files:
                if file.endswith((".pyc", ".pyo", ".DS_Store", ".zip")):
                    continue
                file_path = Path(root) / file
                archive_name = Path("AI_Intelligent_Product_Buying_System") / file_path.relative_to(project_root)
                zf.write(file_path, archive_name)

    memory_file.seek(0)
    return send_file(
        memory_file,
        mimetype="application/zip",
        as_attachment=True,
        download_name="AI_Intelligent_Product_Buying_System.zip"
    )

# ============================================================
# API ENDPOINTS
# ============================================================
@app.route("/api/parse-query", methods=["POST"])
def api_parse_query():
    """API endpoint to parse natural language queries."""
    data = request.get_json() or {}
    query_text = data.get("query", "")
    parsed = query_parser.parse(query_text)
    return jsonify(parsed)

@app.route("/api/recommend", methods=["POST"])
def api_recommend():
    """API endpoint to retrieve recommendations."""
    data = request.get_json() or {}
    query_text = data.get("query", "")
    user_req = query_parser.parse(query_text)
    recs = rec_engine.recommend(user_req, limit=int(data.get("limit", 6)))
    return jsonify({"requirements": user_req, "recommendations": recs})

@app.route("/api/worth-it", methods=["POST"])
def api_worth_it():
    """API endpoint for worth-it evaluation."""
    data = request.get_json() or {}
    prod_id = data.get("product_id")
    product = get_product_by_id(int(prod_id))
    if not product:
        return jsonify({"error": "Product not found"}), 404
    budget = float(data.get("budget", product["price"]))
    user_req = {
        "raw_query": f"API Evaluation of {product['name']}",
        "category": product["category"],
        "budget": budget,
        "use_cases": data.get("use_cases", ["programming"])
    }
    eval_result = worth_it_engine.evaluate_product(product, user_req)
    return jsonify(eval_result)

@app.errorhandler(404)
def not_found(e):
    return render_template("404.html"), 404

@app.errorhandler(500)
def server_error(e):
    return render_template("500.html"), 500

if __name__ == "__main__":
    port = int(os.environ.get("FLASK_PORT", 5000))
    debug = os.environ.get("FLASK_DEBUG", "False").lower() in ("true", "1")
    print(f"Starting SmartBuyer AI Flask App on http://127.0.0.1:{port} [Debug={debug}]")
    app.run(host="0.0.0.0", port=port, debug=debug)
